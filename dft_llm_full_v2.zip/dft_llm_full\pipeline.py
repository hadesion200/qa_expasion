﻿# -*- coding: utf-8 -*-
"""场景改写 → 两层复查 → 组装。

只替换 state 第一行【场景】；判定规则/故障逻辑/基本事件/选项/target 全部原样保留。
复查：
  ① 确定性：不新增数字、提到部件、不泄答案、长度、无标记
  ② 独立解题：模型当考生做题，答案必须等于 target，且逐字指出判据那一行
  ③ 一致性：solve 跑 SOLVE_ROUNDS 轮，每轮都要对，且指向同一判据行
"""
import hashlib
import json
import re
import sys
from collections import Counter

import config

NUM = re.compile(r"\d+(?:\.\d+)?")


def read_jsonl(p):
    with open(p, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                yield json.loads(line)


def norm(s):
    return re.sub(r"[\s，。、；：？！“”‘’（）()\[\]【】《》·…—\-_,.;:?!'\"<>/\\|]+", "", s or "")


def load_items():
    return list(read_jsonl(config.OUT / "items.jsonl"))


def split_state(state):
    i = state.find("\n")
    return (state, "") if i < 0 else (state[:i], state[i:])


def leaves_of(state):
    m = re.search(r"【基本事件】(.+)", state)
    return [x for x in re.split(r"[、，,]", m.group(1)) if x.strip()] if m else []


def top_of(state):
    m = re.search(r"【顶事件】(.+)", state)
    return m.group(1).strip() if m else ""


def job_id(it):
    raw = (it["meta"]["tree"] + "|" + it["kind"] + "|" + it["state"] + "|" + it["question"]
           + "|" + "||".join(it["options"]) + "|" + json.dumps(it["target"]))
    return hashlib.sha1(raw.encode("utf-8")).hexdigest()[:16]


def gold_answer(it):
    gi = max(range(len(it["target"])), key=it["target"].__getitem__)
    if it["kind"] == "noul":
        return "true" if gi == 1 else "false"
    if it["kind"] == "choice":
        return "ABCD"[gi]
    return str(gi)


# ---------------------------------------------------------------- 校验
def check_scenario(s, it):
    s = (s or "").strip()
    if not s:
        return "empty"
    if not (config.MIN_LEN <= len(s) <= config.MAX_LEN):
        return f"len:{len(s)}"
    if "【" in s or "】" in s or "```" in s:
        return "markup"
    if set(NUM.findall(s)) - set(NUM.findall(it["state"])):
        return "new_numbers"
    lv = leaves_of(it["state"])
    if lv and not any(l in s for l in lv):
        return "no_component"
    if s in it["state"]:
        return "copy_paste"
    if it["kind"] == "choice":
        gi = max(range(len(it["target"])), key=it["target"].__getitem__)
        g = re.sub(r"\s", "", it["options"][gi])
        if g and g in re.sub(r"\s", "", s):
            return "answer_leak"
    return "ok"


def _canon(it, ans):
    a = str(ans).strip().lower()
    if it["kind"] == "noul":
        if a in ("true", "是", "对", "1", "b"):
            return "true"
        if a in ("false", "否", "错", "0", "a"):
            return "false"
    elif it["kind"] == "choice":
        if re.fullmatch(r"[a-d]", a):
            return a.upper()
        for i, o in enumerate(it["options"]):
            if a == str(o).strip().lower():
                return "ABCD"[i]
    elif it["kind"] == "score":
        m = re.search(r"\d", a)
        if m:
            return m.group(0)
    return a


def check_solve(card, it):
    if not card:
        return "no_card"
    anchor = (card.get("anchor") or "").strip()
    if len(anchor) < 8:
        return "no_anchor"
    if norm(anchor) not in norm(it["state"]):
        return "anchor_not_in_state"
    if not card.get("confident", True):
        return "not_confident"
    if _canon(it, card.get("answer")) != gold_answer(it):
        return "answer_mismatch"
    return "ok"


def apply_scenario(it, scenario):
    head, rest = split_state(it["state"])
    new = dict(it)
    new["state"] = "【场景】" + scenario.strip() + rest
    new["llm_scenario"] = True
    return new


# ---------------------------------------------------------------- 组装
def assemble():
    items = load_items()
    by_id = {job_id(it): it for it in items}

    scen, sols = {}, {}
    p = config.OUT / "scenario.jsonl"
    if p.exists():
        for r in read_jsonl(p):
            scen[r["id"]] = r["card"]
    p = config.OUT / "solve.jsonl"
    if p.exists():
        for r in read_jsonl(p):
            base = r["id"].split("#")[0]           # 去掉 #r1 / #r2 轮次后缀
            sols.setdefault(base, []).append(r["card"])

    print(f"题目 {len(items)}｜场景 {len(scen)}｜解题记录 {sum(len(v) for v in sols.values())}")

    reasons, kept, rejected = Counter(), [], []
    for rid, it in by_id.items():
        card = scen.get(rid)
        if not card:
            reasons["no_scenario"] += 1
            continue
        why = check_scenario(card.get("scenario"), it)
        if why == "ok":
            rounds = sols.get(rid, [])
            if len(rounds) < config.SOLVE_ROUNDS:
                why = f"less_rounds:{len(rounds)}"
            else:
                answers = []
                for k, r in enumerate(rounds[: config.SOLVE_ROUNDS]):
                    w = check_solve(r, it)
                    if w != "ok":
                        why = f"round{k + 1}:{w}"
                        break
                    answers.append(norm(r.get("anchor", "")))
                else:
                    if len(set(answers)) > 1:
                        why = "anchor_disagree"       # 两轮指的判据不是同一行
        reasons[why] += 1
        if why == "ok":
            kept.append(apply_scenario(it, card["scenario"]))
        else:
            rejected.append({"id": rid, "why": why, "tree": it["meta"]["platform"]})

    print("校验:", dict(reasons))
    config.OUT.mkdir(parents=True, exist_ok=True)
    outs = {"train": [], "dev": [], "benchmark": []}
    for it in kept:
        outs[it["split"]].append(it)
    for s, rows in outs.items():
        with open(config.OUT / f"{s}.jsonl", "w", encoding="utf-8") as f:
            for it in rows:
                it["dataset"] = "galileo_dft_llm_full"
                f.write(json.dumps(it, ensure_ascii=False) + "\n")
    with open(config.OUT / "rejected.jsonl", "w", encoding="utf-8") as f:
        for r in rejected:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")

    rep = {"items": len(items), "kept": len(kept),
           "by_split": {s: len(v) for s, v in outs.items()},
           "by_kind": dict(Counter(x["kind"] for x in kept)),
           "by_domain": dict(Counter(x["meta"]["domain"] for x in kept)),
           "by_source": dict(Counter(x["tree_source"] for x in kept)),
           "checks": dict(reasons),
           "solve_rounds": config.SOLVE_ROUNDS}
    (config.OUT / "report.json").write_text(
        json.dumps(rep, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(rep, ensure_ascii=False, indent=1))
    return 0
