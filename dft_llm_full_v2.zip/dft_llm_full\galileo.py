# -*- coding: utf-8 -*-
"""Galileo 故障树/攻击树的最小解析器 + 静态语义。

只支持这批文件用到的门：or / and / csp / wsp / fdep / kofn。
动态门按静态近似处理（csp/wsp→AND，fdep→OR），这是做割集分析时的常规做法，
但不等于原模型的时序语义——出题时要写明"按静态逻辑判定"。
"""
import itertools
import re
from pathlib import Path

TOP = re.compile(r'^toplevel\s+"([^"]+)";')
BASIC = re.compile(r'^"([^"]+)"\s+(prob|lambda)\s*=')
GATE = re.compile(r'^"([^"]+)"\s+([A-Za-z0-9_]+)\s*(.*);\s*$')
NAME = re.compile(r'"([^"]+)"')

GATE_CN = {"or": "或", "and": "与", "csp": "冷备", "wsp": "温备",
           "fdep": "功能相关", "spare": "备件", "pand": "顺序与", "seq": "顺序与"}


class Tree:
    def __init__(self, path=None, top=None, gates=None, basics=None):
        if path is None:                      # 合成树：直接给结构
            self.path = None
            self.top = top
            self.gates = gates or {}
            self.basics = basics or {}
            return
        self.path = Path(path)
        self.top = None
        self.gates = {}      # name -> (kind, [kids])
        self.basics = {}     # name -> 原始行
        for raw in self.path.read_text(encoding="utf-8", errors="replace").splitlines():
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            m = TOP.match(line)
            if m:
                self.top = m.group(1)
                continue
            m = BASIC.match(line)
            if m:
                self.basics[m.group(1)] = line
                continue
            m = GATE.match(line)
            if m:
                self.gates[m.group(1)] = (m.group(2).lower(), NAME.findall(m.group(3)))
        if not self.top:
            raise ValueError(f"{path}: 没有 toplevel")

    # ---------- 结构 ----------
    def leaves(self):
        out, seen = set(), set()

        def walk(n):
            if n in seen:
                return
            seen.add(n)
            if n in self.gates:
                for k in self.gates[n][1]:
                    walk(k)
            else:
                out.add(n)

        walk(self.top)
        return out

    # ---------- 求值 ----------
    def fails(self, failed):
        """failed: 一组基本事件名。返回顶事件是否发生。"""
        memo = {}

        def ev(node):
            if node in memo:
                return memo[node]
            if node not in self.gates:
                val = node in failed
            else:
                kind, kids = self.gates[node]
                vals = [ev(k) for k in kids]
                if kind in ("or", "fdep") or not kids:
                    val = any(vals)
                elif kind in ("and", "csp", "wsp", "spare", "pand", "seq"):
                    val = all(vals)
                else:
                    m = re.fullmatch(r"(\d+)of(\d+)", kind)
                    val = sum(vals) >= int(m.group(1)) if m else any(vals)
            memo[node] = val
            return val

        return ev(self.top)

    def is_mcs(self, s):
        s = set(s)
        if not s or not self.fails(s):
            return False
        return all(not self.fails(s - {x}) for x in s)

    # ---------- 割集 ----------
    def mcs(self):
        cache = {}

        def go(node, depth=0):
            if node in cache:
                return cache[node]
            if depth > 60:
                return [()]
            if node not in self.gates:
                cache[node] = [(node,)]
                return cache[node]
            kind, kids = self.gates[node]
            if not kids:
                res = [(node,)]
            elif kind in ("or", "fdep"):
                res = _min([s for k in kids for s in go(k, depth + 1)])
            elif re.fullmatch(r"\d+of\d+", kind):
                need = int(re.fullmatch(r"(\d+)of(\d+)", kind).group(1))
                acc = []
                for combo in itertools.combinations(kids, need):
                    part = [()]
                    for k in combo:
                        part = _min([tuple(sorted(set(a) | set(b)))
                                     for a in part for b in go(k, depth + 1)])
                    acc.extend(part)
                res = _min(acc)
            else:  # and / csp / wsp / spare / pand / seq
                acc = [()]
                for k in kids:
                    acc = _min([tuple(sorted(set(a) | set(b)))
                                for a in acc for b in go(k, depth + 1)])
                res = acc
            cache[node] = res
            return res

        return sorted(go(self.top), key=lambda s: (len(s), s))

    # ---------- 渲染 ----------
    def render(self):
        """紧凑文本：一行一个门，叶子不列（叶子在【基本事件】里）。"""
        lines, seen = [], set()
        order = []

        def walk(n):
            if n in seen or n not in self.gates:
                return
            seen.add(n)
            order.append(n)
            for k in self.gates[n][1]:
                walk(k)

        walk(self.top)
        for i, n in enumerate(order, 1):
            kind, kids = self.gates[n]
            m = re.fullmatch(r"(\d+)of(\d+)", kind)
            if m:
                need = int(m.group(1))
                total = len(kids)                 # 以实际输入数为准，避免"4 取 2"却列 3 个
                need = min(need, total)
                lines.append(f"{i}. {n} = 在 {total} 个中需 {need} 个同时失效（"
                             + "、".join(kids) + "）")
                continue
            op = GATE_CN.get(kind, kind.upper())
            lines.append(f"{i}. {n} = " + f" {op} ".join(kids))
        return "\n".join(lines)

    def basic_events(self):
        return sorted(self.leaves())


def _min(sets):
    uniq = sorted({tuple(sorted(s)) for s in sets if s}, key=len)
    out = []
    for s in uniq:
        ss = set(s)
        if not any(set(o) <= ss for o in out):
            out.append(s)
    return out
