﻿# -*- coding: utf-8 -*-
"""自检：build → gen(mock) → 回填"会做的模型" → solve(mock) → assemble。

验证：
  1. 结构段/选项/题干/target 与 build 产物完全一致，只换了【场景】行；
  2. 注入 1 条错答、1 条假锚点、1 条两轮锚点不一致，都会被拦下；
  3. 切分按树：同一棵树的所有题目在同一侧。
"""
import json
import re
import shutil
import subprocess
import sys
from collections import defaultdict
from pathlib import Path

BASE = Path(__file__).resolve().parent
OUT = BASE / "out"
LIMIT = 30


def run(*args):
    r = subprocess.run([sys.executable, "run.py", *args],
                       cwd=BASE, capture_output=True, text=True, encoding="utf-8")
    if r.returncode != 0:
        print(r.stdout[-1500:])
        print(r.stderr[-1500:])
        raise SystemExit(f"命令失败: run.py {' '.join(args)}")
    return r.stdout


def logic_line(state):
    m = re.search(r"【故障逻辑】[^\n]*\n([^\n]+)", state)
    return m.group(1).strip() if m else ""


def main():
    import config
    import pipeline

    for p in (OUT, BASE / ".cache"):
        if p.exists():
            shutil.rmtree(p)

    run("build")
    run("gen", "--limit", str(LIMIT), "--mock")
    run("solve", "--limit", str(LIMIT * 2), "--mock")   # 2 轮

    items = {pipeline.job_id(it): it for it in pipeline.load_items()}
    scen = {r["id"]: r["card"] for r in pipeline.read_jsonl(OUT / "scenario.jsonl")}

    # 只对"场景通过确定性校验"的题回填（模拟一个会做对的模型）
    valid = [(rid, items[rid]) for rid, c in scen.items()
             if pipeline.check_scenario(c["scenario"], items[rid]) == "ok"]
    print(f"[debug] 场景 {len(scen)} 条，通过确定性校验的 {len(valid)} 条")
    assert len(valid) >= 4, "mock 场景通过率太低"

    rows = []
    for k, (rid, it) in enumerate(valid):
        new_it = pipeline.apply_scenario(it, scen[rid]["scenario"])
        ans, anchor = pipeline.gold_answer(it), logic_line(new_it["state"])
        mode = {0: "wrong_answer", 1: "bad_anchor", 2: "disagree"}.get(k)
        if mode == "wrong_answer":
            ans = "Z"
        elif mode == "bad_anchor":
            anchor = "99. 中间事件X = 部件Y 与 部件Z"
        for r in range(config.SOLVE_ROUNDS):
            a = anchor
            if mode == "disagree" and r == 1:
                lines = [x for x in new_it["state"].split("\n") if x[:2] in ("1.", "2.", "3.", "4.", "5.")]
                a = lines[-1] if lines else anchor      # 换一行判据 → 两轮不一致
            rows.append({"id": f"{rid}#r{r + 1}",
                         "card": {"anchor": a, "answer": ans,
                                  "confident": True, "reason": "selftest"}})
    with open(OUT / "solve.jsonl", "w", encoding="utf-8") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")

    run("assemble")
    rep = json.loads((OUT / "report.json").read_text(encoding="utf-8"))
    print(f"[ok] 题目 {rep['items']}｜保留 {rep['kept']}｜{rep['by_split']}")
    print(f"[ok] 校验分布 {rep['checks']}")
    assert rep["kept"] > 0
    assert rep["checks"].get("round1:answer_mismatch", 0) >= 1, "错答没被拦下"
    assert rep["checks"].get("round1:anchor_not_in_state", 0) >= 1, "假锚点没被拦下"
    assert rep["checks"].get("anchor_disagree", 0) >= 1, "两轮不一致没被拦下"

    # 结构与切分
    src = {(pipeline.split_state(it["state"])[1], it["question"], tuple(it["options"]), tuple(it["target"])): it
           for it in pipeline.load_items()}
    seen_tree_split = {}
    n = 0
    for s in ("train", "dev", "benchmark"):
        p = OUT / f"{s}.jsonl"
        if not p.exists():
            continue
        for line in p.open(encoding="utf-8"):
            it = json.loads(line)
            head, rest = pipeline.split_state(it["state"])
            assert head.startswith("【场景】")
            orig = src.get((rest, it["question"], tuple(it["options"]), tuple(it["target"])))
            assert orig is not None, "结构段对不上"
            assert it["target"] == orig["target"] and it["options"] == orig["options"]
            assert it["question"] == orig["question"]
            t = it["meta"]["tree"]
            assert seen_tree_split.setdefault(t, s) == s, f"{t} 跨侧"
            n += 1
    print(f"[ok] {n} 条：只换场景行，标签/选项/题干不变；同一棵树未跨侧")
    print("\n全部通过。")


if __name__ == "__main__":
    main()
