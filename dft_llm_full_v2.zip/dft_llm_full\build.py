# -*- coding: utf-8 -*-
"""从 trees.jsonl 直接生成"每题上限"下的全部题目（不依赖 dft_gen/out）。

产物 out/items.jsonl：每条含 kind/state/question/options/target/meta/split/tree_source。
这里的 state 还是确定性渲染，后续 rewrite.py 会把【场景】一行换成模型写的。
"""
import hashlib
import json
import random
import re
import sys
from collections import Counter
from pathlib import Path

import config
import gen_items as G
from galileo import Tree


def read_jsonl(p):
    with open(p, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                yield json.loads(line)


def split_for(tree_name, source, domain):
    """按树切分：同一棵树的所有题目必在同一侧。"""
    h = int(hashlib.md5(tree_name.encode("utf-8")).hexdigest()[:8], 16) % 100
    if source == "real" and domain == "space" and config.SPACE_REAL_TO_BENCH:
        return "benchmark"
    if source in ("real", "borrowed"):
        return "benchmark" if h < 20 else "dev" if h < 35 else "train"
    if domain == "space":
        return "benchmark" if h < 30 else "dev" if h < 50 else "train"
    return "dev" if h < 10 else "train"


def load_trees():
    out = []
    for d in read_jsonl(config.TREES):
        gates = {k: (v[0], v[1]) for k, v in d["gates"].items()}
        tree = Tree(top=d["top"], gates=gates, basics={})
        out.append({
            "file": d["name"], "tree": tree, "mcs": tree.mcs(),
            "leaves": tree.leaves(), "platform": d["platform"],
            "domain": d["domain"], "source": d["source"],
        })
    return out


def gold_of(it):
    return max(range(len(it["target"])), key=it["target"].__getitem__)


def select(items, rng):
    """精选：每棵树每题型只留少量代表题，且同树内不重复同一逻辑点。

    - mcs   : 按"正确割集"去重，最多 SELECT_MCS 条
    - action: 按"被查询的部件"去重，最多 SELECT_ACTION 条
    - noul  : 按 state（观测集合）去重，并尽量平衡 true/false，最多 SELECT_NOUL
    - score : 按 state 去重，每个档位至多一条，最多 SELECT_SCORE
    """
    cap = {"mcs": config.SELECT_MCS, "action": config.SELECT_ACTION,
           "noul": config.SELECT_NOUL, "score": config.SELECT_SCORE}
    buckets = {}
    for it in items:
        buckets.setdefault((it["meta"]["tree"], it["meta"]["gen"]), []).append(it)

    out = []
    for (tree, gen), rows in buckets.items():
        rng.shuffle(rows)
        limit = cap.get(gen, 4)
        picked, seen_key, seen_lvl = [], set(), set()

        if gen == "noul":                      # 先保证正负都有
            for want in (1, 0):
                for r in rows:
                    if r["meta"]["label"] == want and r["state"] not in seen_key:
                        picked.append(r)
                        seen_key.add(r["state"])
                        break

        for r in rows:
            if len(picked) >= limit:
                break
            if gen in ("mcs", "action"):
                k = tuple(r["meta"]["gold"])
            else:
                k = r["state"]
            if k in seen_key:
                continue
            if gen == "score":
                lv = r["meta"]["level"]
                if lv in seen_lvl:
                    continue
                seen_lvl.add(lv)
            seen_key.add(k)
            picked.append(r)
        out += picked[:limit]
    return out


def main():
    rng = random.Random(20261105)
    trees = load_trees()
    print(f"载入 {len(trees)} 棵树")

    items = []
    for info in trees:
        info["_split"] = split_for(info["file"], info["source"], info["domain"])
        got = []
        got += G.gen_mcs_choice(info, rng)[: config.CAP_MCS]
        got += G.gen_action_choice(info, rng, k=config.CAP_ACTION)
        got += G.gen_noul(info, rng, k=config.CAP_NOUL)
        got += G.gen_score(info, rng, k=config.CAP_SCORE)
        for it in got:
            it["split"] = info["_split"]
            it["tree_source"] = info["source"]
        items += got

    # 去重（同树同题型同选项）
    seen, kept = set(), []
    for it in items:
        key = (it["meta"]["tree"], it["kind"], it["state"], tuple(it["options"]))
        if key in seen:
            continue
        seen.add(key)
        kept.append(it)

    full_n = len(kept)
    kept = select(kept, rng)
    print(f"满配 {full_n} 条 → 精选 {len(kept)} 条")

    config.OUT.mkdir(parents=True, exist_ok=True)
    with open(config.OUT / "items.jsonl", "w", encoding="utf-8") as f:
        for it in kept:
            f.write(json.dumps(it, ensure_ascii=False) + "\n")

    per = Counter(i["meta"]["tree"] for i in kept)
    rep = {
        "trees": len(trees),
        "items": len(kept),
        "by_split": dict(Counter(i["split"] for i in kept)),
        "by_kind": dict(Counter(i["kind"] for i in kept)),
        "by_gen": dict(Counter(i["meta"]["gen"] for i in kept)),
        "by_domain": dict(Counter(i["meta"]["domain"] for i in kept)),
        "by_source": dict(Counter(i["tree_source"] for i in kept)),
        "per_tree_max": max(per.values()) if per else 0,
        "per_tree_median": sorted(per.values())[len(per) // 2] if per else 0,
    }
    (config.OUT / "build_report.json").write_text(
        json.dumps(rep, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(rep, ensure_ascii=False, indent=1))
    return 0


if __name__ == "__main__":
    sys.exit(main())
