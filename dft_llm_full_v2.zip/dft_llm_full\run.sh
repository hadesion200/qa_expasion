#!/usr/bin/env bash
# dft_llm_full — 按树满配出题 + 模型写场景 + 两轮复查
set -euo pipefail
cd "$(dirname "$0")"

PY="${PY:-python3}"
export PYTHONIOENCODING=utf-8

case "${1:-help}" in
  help|-h|--help)
    cat <<'EOF'
用法: ./run.sh <command> [--limit N] [--mock]

  check     自检（mock，不联网）
  build     从 trees.jsonl 出题（不调模型）
  gen       模型写【场景】
  solve     模型独立解题（复查，默认 2 轮）
  assemble  三层校验 + 出数据集
  report    打印统计

环境变量:
  DFT_TREES             trees.jsonl 路径（默认指向 dft_gen/out/trees.jsonl）
  DFT_OUT               输出目录（默认 ./out）
  TEACHER_BASE_URL / TEACHER_MODEL / TEACHER_API_KEY / TEACHER_CONCURRENCY
  CAP_MCS / CAP_ACTION / CAP_NOUL / CAP_SCORE   每棵树出题上限
  SOLVE_ROUNDS          复查轮数（默认 2）

建议:
  ./run.sh check
  ./run.sh build
  ./run.sh gen --limit 50 && ./run.sh solve --limit 100 && ./run.sh assemble
  ./run.sh gen && ./run.sh solve
EOF
    ;;
  check)
    "$PY" selftest.py ;;
  build|gen|solve|assemble|report)
    "$PY" run.py "$@" ;;
  *)
    echo "未知命令: $1" >&2; exit 1 ;;
esac
