# -*- coding: utf-8 -*-
"""命令行入口。

  python3 run.py build      从 trees.jsonl 生成全部题目（不调模型）
  python3 run.py gen        模型写【场景】
  python3 run.py solve      模型独立解题（复查，跑 SOLVE_ROUNDS 轮）
  python3 run.py assemble   两层校验 + 出数据集
  python3 run.py report     统计
  python3 run.py check      自检（mock）
"""
import argparse
import asyncio
import sys

import build
import config
import pipeline
import prompts
from llm import Teacher, run_batch


def gen_jobs(limit=None):
    jobs = []
    for it in pipeline.load_items():
        head, _ = pipeline.split_state(it["state"])
        text = prompts.SCENARIO.format(
            platform=it["meta"]["platform"], top=pipeline.top_of(it["state"]),
            leaves="、".join(pipeline.leaves_of(it["state"])),
            old=head.replace("【场景】", "").strip(),
            lo=config.MIN_LEN, hi=config.MAX_LEN)
        jobs.append((pipeline.job_id(it), text))
    return jobs[:limit] if limit else jobs


async def cmd_gen(args):
    jobs = gen_jobs(args.limit)
    print(f"待生成 {len(jobs)} 条场景")
    async with Teacher(mock=args.mock) as t:
        await run_batch(t, jobs, config.OUT / "scenario.jsonl",
                        lambda t, rid, text: t.ask("scenario", prompts.SYSTEM, text))


def solve_jobs(limit=None):
    """只有场景通过确定性校验的题才送去做题复查。"""
    scen = {r["id"]: r["card"] for r in pipeline.read_jsonl(config.OUT / "scenario.jsonl")}
    jobs = []
    for it in pipeline.load_items():
        rid = pipeline.job_id(it)
        card = scen.get(rid)
        if not card:
            continue
        if pipeline.check_scenario(card.get("scenario"), it) != "ok":
            continue
        new_it = pipeline.apply_scenario(it, card["scenario"])
        if new_it["kind"] == "score":
            opts = "、".join(f"{i}={o}" for i, o in enumerate(new_it["options"]))
        else:
            opts = "\n".join(f"{chr(65 + i)}. {o}" for i, o in enumerate(new_it["options"]))
        text = prompts.SOLVE.format(state=new_it["state"],
                                    question=new_it["question"], options=opts)
        for r in range(config.SOLVE_ROUNDS):
            jobs.append((f"{rid}#r{r + 1}", text))
    return jobs[:limit] if limit else jobs


async def cmd_solve(args):
    jobs = solve_jobs(args.limit)
    print(f"待独立解题 {len(jobs)} 条（{config.SOLVE_ROUNDS} 轮）")
    async with Teacher(mock=args.mock) as t:
        await run_batch(t, jobs, config.OUT / "solve.jsonl",
                        lambda t, rid, text: t.ask("solve", prompts.SYSTEM, text))


def cmd_report(_args):
    p = config.OUT / "report.json"
    if not p.exists():
        print("还没有 report.json，先跑 assemble")
        return 1
    print(p.read_text(encoding="utf-8"))
    return 0


def main():
    KNOWN = ("build", "gen", "solve", "assemble", "report", "check")
    if len(sys.argv) > 1 and sys.argv[1] not in KNOWN + ("-h", "--help"):
        print(f"[error] 未知子命令 {sys.argv[1]!r}，可选：{', '.join(KNOWN)}")
        return 2
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    for name in KNOWN:
        p = sub.add_parser(name)
        p.add_argument("--limit", type=int, default=None)
        p.add_argument("--mock", action="store_true")
    args = ap.parse_args()

    if args.cmd == "build":
        return build.main()
    if args.cmd == "gen":
        asyncio.run(cmd_gen(args))
        return 0
    if args.cmd == "solve":
        asyncio.run(cmd_solve(args))
        return 0
    if args.cmd == "assemble":
        return pipeline.assemble()
    if args.cmd == "report":
        return cmd_report(args)
    # check = mock 全流程
    build.main()
    args.mock = True
    asyncio.run(cmd_gen(args))
    asyncio.run(cmd_solve(args))
    return pipeline.assemble()


if __name__ == "__main__":
    sys.exit(main())
