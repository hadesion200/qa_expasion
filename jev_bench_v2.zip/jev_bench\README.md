# jev 决策服务 · 基准压测包 v2

一个 `config.ini` 配 API，分步跑，跑完自动出一份 `REPORT.md` 短报告。
纯 Python 标准库，无 pip 依赖。

## 快速开始

```bash
# 1. 改 config.ini 的 [api] 段（base / endpoint / model / api_key）
# 2. 确认协议通
python bench.py check

# 3. 分步跑
python bench.py smoke    # 单流基线
python bench.py short    # 短文本并发梯度
python bench.py long     # 长上下文
python bench.py open     # 开环到达率
python bench.py all      # 四步全跑 + 生成 REPORT.md
```

结果在 `runs/<时间戳>-<步骤>/`；`all` 还会在 `runs/REPORT.md` 出一份可直接转发的短报告。

临时覆盖（不改文件）：

```bash
python bench.py short --concurrency 1,8,32 --duration 10
python bench.py short --base http://10.0.0.5:9900 --api-key $KEY
python bench.py short --metrics-url http://10.0.0.5:18000/metrics
python bench.py short --pid 12345          # 显存按这个进程归属
```

## v2 改了什么

| 问题 | v1 | v2 |
|---|---|---|
| 显存口径 | 整卡 `memory.used` | 先看**本进程**占用，再看整卡；同卡多进程时明确标注 |
| 引擎预算 | 按 90% 整卡估 | 按 `gpu_memory_utilization`（如 0.3）算，这才是模型真正能用的 |
| 并行度 | 只能靠延迟推断 | 采 `/metrics` 的 `num_requests_running/waiting`，直接看引擎一次算几个 |
| GPU 利用率 | 无 | `nvidia-smi utilization.gpu`，和 running 交叉验证 |
| 结论 | 自己看表 | `REPORT.md` 自动给瓶颈判定与可承诺容量 |

## 配置要点

```ini
[gpu]
gpu_memory_utilization = 0.30     # 必须和服务端启动参数一致
server_pid = auto                 # 自动从端口找 pid；也可填数字
proc_cmd = nvidia-smi --query-compute-apps=pid,used_memory --format=csv,noheader,nounits

[engine]
metrics_url = http://127.0.0.1:18000/metrics   # 填了才能判定并行度
```

**`gpu_memory_utilization` 不是整卡比例。** 0.3 意味着模型只锁 0.3×总显存；
如果同卡还有别的进程，"整卡已用"会是两者之和，用它算容量会得出完全错误的结论。

## 指标口径

| 指标 | 含义 |
|---|---|
| req/s | 每秒完成请求数 |
| dec/s | 每秒完成 question 数（一请求多问时 ≠ req/s） |
| tok/s | 每秒输入 token 数，决策模型无 decode，即 prefill 吞吐 |
| p50/p95/p99 | 端到端延迟（含排队） |
| run | `num_requests_running` 峰值，**引擎同时算了几个请求** |
| wait | `num_requests_waiting` 峰值，排队长度 |
| GPU% | 采样期 GPU 利用率均值 |
| mem | 本进程显存（拿不到则回落整卡） |

## REPORT.md 怎么读

判瓶颈看第 5 节的三行证据：

| `run` 峰值 | `GPU%` 峰值 | 结论 | 该做什么 |
|---|---|---|---|
| ≈1 | 任何 | **引擎未并行**，并发只排队 | 查 `--max-num-seqs`、业务层是否串行调用 |
| >1 | >85 | **算力饱和** | 加卡 / 换小模型 / 降上下文 |
| >1 | <40 | **调度受限**，GPU 有空转 | 查 chunked prefill、批大小、readout 开销 |
| >1 | 40~85 | 正常但未吃满 | 多半是固定开销占比高 |

第 6 节给的是**可承诺容量**：SLO 内能扛的最大 req/s，直接拿去对外报数。

## 数据集

`data/jev_bench_v1.jsonl` 共 300 条，从本地卫星定轨语料（`out/jev_suites`，994 条真实样本）分层生成：

| 桶 | 条数 | state 字符 | 约 token | 用途 |
|---|---|---|---|---|
| short | 120 | 150~533 | ~200 | 典型网关判定 |
| mid | 80 | 894~1625 | ~800 | 中等上下文 |
| long | 60 | 6537~8460 | ~4700 | 贴 8k 上限 |
| multi | 40 | 161~585 | ~200 × 4 问 | 一次调用多问 |

> mid/long 是多条真实 state 拼接（只为拉长 token 数）；multi 的 4 问来自不同样本。
> `manifest.json` 里标了 `synthetic`。重新生成：`python tools/build_dataset.py --src <语料目录>`。

## 离线自检

```bash
python tools/mock_server.py --port 18082 --serial   # 串行引擎，run 恒为 1
python bench.py all --base http://127.0.0.1:18082 \
  --metrics-url http://127.0.0.1:18082/metrics --duration 5
```

用来验证安装、参数和报告链路，不需要 GPU。

## 注意

- 客户端别和 GPU 服务同机；同机时高并发段客户端抢 CPU，报告里会打提示。
- 每档至少 20 秒；正式结论重复 3 次取中位数。
- 服务端启动参数（`--max-num-seqs` / `--max-model-len` / `--gpu-memory-utilization`）要和报告一起存档，否则数字不可复现。
