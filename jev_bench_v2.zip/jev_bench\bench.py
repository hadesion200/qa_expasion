#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
bench.py v2 —— Jev / System One 决策服务：基准吞吐 · 并发 · 显存 压测

与 v1 的差别
    1. 显存按【进程】归属，不再看整卡。
       gpu_memory_utilization=0.3 时模型只锁 0.3×总显存，同卡还有别的进程，
       "整卡 used" 是两者之和，用它算容量会得出完全错误的结论。
    2. 采 vLLM /metrics 的 num_requests_running / waiting。
       running 恒为 1 → 引擎一次只算一个请求，并发只是排队；
       running 上得去且 GPU 打满 → 是真的算力饱和。这是区分两者的唯一硬证据。
    3. 采 GPU 利用率（nvidia-smi utilization.gpu），和 running 交叉验证。
    4. `all` 跑完自动生成一份短报告 REPORT.md（基准现状），不用自己汇总。

用法
    python bench.py check     # 协议/契约检查
    python bench.py probe     # 探测 metrics 地址（缺 metrics 时先跑这个）
    python bench.py smoke     # 单流基线
    python bench.py short     # 短文本并发梯度（含 running/wait/util）
    python bench.py long      # 长上下文（显存/算力边界）
    python bench.py open      # 开环到达率 → SLO 达成率
    python bench.py all       # 四步全跑 + 生成 REPORT.md

配置全部在 config.ini。命令行可临时覆盖：--base/--model/--api-key/--concurrency/--duration。

版本  v2.2  2026-11-09  自动推导 metrics 地址；新增 env（容器/启动参数/同卡进程）；报告带环境快照
"""

import argparse
import collections
import configparser
import http.client
import json
import os
import random
import re
import statistics
import subprocess
import sys
import threading
import time
import urllib.parse
import urllib.request
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:  # noqa: BLE001
    pass

HERE = os.path.dirname(os.path.abspath(__file__))
SEP = "=" * 78
VERSION = "v2.2"


# ================================================================ 配置

DEFAULTS = {
    "api": {"base": "http://127.0.0.1:18080", "endpoint": "/v1/systemone",
            "model": "", "api_key": "", "timeout": "120"},
    "run": {"dataset": "data/jev_bench_v1.jsonl", "out_dir": "runs",
            "duration": "20", "warmup": "5", "slo_p95_ms": "300", "max_err": "0.001"},
    "steps": {"smoke_concurrency": "1", "smoke_duration": "8", "smoke_buckets": "short",
              "short_concurrency": "1,2,4,8,16,32", "short_buckets": "short,multi",
              "long_concurrency": "1,2,4,8", "long_buckets": "long",
              "long_slo_p95_ms": "2500", "open_rates": "5,10,20,40",
              "open_duration": "30"},
    "gpu": {"enabled": "true",
            "gpu_memory_utilization": "0.30",
            "mem_cmd": "nvidia-smi --query-gpu=memory.used,memory.total,utilization.gpu "
                       "--format=csv,noheader,nounits",
            "proc_cmd": "nvidia-smi --query-compute-apps=pid,used_memory "
                        "--format=csv,noheader,nounits",
            "server_pid": "",
            "vram_total_mb": ""},
    "engine": {"metrics_url": "http://127.0.0.1:18000/metrics"},
}


class Cfg:
    def __init__(self, path):
        cp = configparser.ConfigParser(interpolation=None)
        if path and os.path.exists(path):
            cp.read(path, encoding="utf-8")
        else:
            print(f"! 找不到配置 {path}，使用内置默认值")
        self.cp, self.path = cp, path

    def get(self, sec, key):
        v = self.cp.get(sec, key, fallback=None)
        return DEFAULTS[sec][key] if v is None else v

    def f(self, sec, key):
        return float(self.get(sec, key))

    def i(self, sec, key):
        return int(self.get(sec, key))

    def b(self, sec, key):
        return self.get(sec, key).strip().lower() in ("1", "true", "yes", "on")

    def lst(self, sec, key):
        return [x.strip() for x in self.get(sec, key).split(",") if x.strip()]

    def pathof(self, p):
        return p if os.path.isabs(p) else os.path.join(HERE, p)


# ================================================================ 数据集

class Sample:
    __slots__ = ("sid", "body", "nq", "bucket", "est_tokens")

    def __init__(self, sid, body, nq, bucket, est_tokens):
        self.sid, self.body, self.nq = sid, body, nq
        self.bucket, self.est_tokens = bucket, est_tokens


def load_dataset(path, model, buckets, limit=0):
    rows = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            d = json.loads(line)
            b = (d.get("meta") or {}).get("bucket") or "all"
            if buckets and b not in buckets:
                continue
            payload = {"model": model, "state": d["state"], "questions": d["questions"]}
            rows.append(Sample(d.get("id") or f"row{len(rows)}",
                               json.dumps(payload, ensure_ascii=False).encode("utf-8"),
                               len(d["questions"]), b,
                               max(8, int(len(d["state"]) / 1.6))))
    if not rows:
        raise SystemExit(f"按桶 {buckets} 过滤后数据集为空：{path}")
    return rows[:limit] if limit else rows


# ================================================================ 响应契约

def inspect(raw, verify=True):
    try:
        j = json.loads(raw)
    except Exception:  # noqa: BLE001
        return 0, 0, ["bad_json"]
    tin = int((j.get("usage") or {}).get("input_tokens") or 0)
    answers = j.get("answers")
    if not isinstance(answers, dict):
        return 0, tin, ["no_answers"]
    if not verify:
        return len(answers), tin, []
    bad = []
    for qid, a in answers.items():
        p = a.get("probabilities")
        vals = [float(v) for v in p.values()] if isinstance(p, dict) else \
               ([float(v) for v in p] if isinstance(p, list) else None)
        if not vals or len(vals) < 2:
            bad.append(f"{qid}:no_probs")
            continue
        s = sum(vals)
        if abs(s - 1.0) > 0.01:
            bad.append(f"{qid}:sum={s:.3f}")
        c = a.get("confidence")
        if isinstance(c, (int, float)) and abs(c - max(vals)) > 2e-3:
            bad.append(f"{qid}:conf_ne_max")
    for qid, d in ((j.get("diagnostics") or {}).items()
                   if isinstance(j.get("diagnostics"), dict) else []):
        if not isinstance(d, dict):
            continue
        lm = d.get("label_mass")
        if isinstance(lm, (int, float)) and abs(lm - 1.0) > 0.01:
            bad.append(f"{qid}:label_mass")
        if d.get("argmax_is_label") is False:
            bad.append(f"{qid}:argmax_not_label")
    return len(answers), tin, bad


# ================================================================ HTTP

class Client:
    def __init__(self, host, port, path, headers, timeout):
        self.host, self.port, self.path = host, port, path
        self.headers, self.timeout = headers, timeout
        self.conn = None

    def post(self, body):
        if self.conn is None:
            self.conn = http.client.HTTPConnection(self.host, self.port, timeout=self.timeout)
        for attempt in (0, 1):
            try:
                self.conn.request("POST", self.path, body=body, headers=self.headers)
                r = self.conn.getresponse()
                return r.status, r.read()
            except Exception:  # noqa: BLE001
                try:
                    if self.conn:
                        self.conn.close()
                except Exception:  # noqa: BLE001
                    pass
                self.conn = None
                if attempt:
                    raise
                self.conn = http.client.HTTPConnection(self.host, self.port,
                                                       timeout=self.timeout)


class Pool:
    def __init__(self, *args):
        self.args = args
        self._tls = threading.local()

    def get(self):
        c = getattr(self._tls, "c", None)
        if c is None:
            c = Client(*self.args)
            self._tls.c = c
        return c


# ================================================================ 采样器

def _sh(cmd):
    return subprocess.run(cmd, shell=True, capture_output=True,
                          text=True, timeout=10).stdout


# ================================================================ 环境探测（docker / GPU 归属）

DOCKER_FMT = "{{.ID}}|{{.Names}}|{{.Image}}|{{.Status}}|{{.Ports}}"
INTERESTING = ("--max-num-seqs", "--max-num-batched-tokens", "--gpu-memory-utilization",
               "--max-model-len", "--dtype", "--enable-chunked-prefill", "--enforce-eager",
               "--tensor-parallel-size", "--served-model-name", "--block-size")


def docker_containers():
    out = _sh(f'docker ps -a --format "{DOCKER_FMT}" 2>/dev/null')
    res = []
    for line in out.splitlines():
        p = line.split("|")
        if len(p) < 5:
            continue
        res.append({"id": p[0], "name": p[1], "image": p[2],
                    "status": p[3], "ports": p[4]})
    return res


def container_for_port(containers, port):
    for c in containers:
        for m in re.finditer(r"(?:([\d.:]+):)?(\d+)->(\d+)/tcp", c["ports"]):
            if int(m.group(2)) == port:
                return c
    return None


def container_args(name):
    args = []
    for field in ("Entrypoint", "Cmd"):
        blob = _sh(f'docker inspect --format "{{{{json .Config.{field}}}}}" '
                   f'{name} 2>/dev/null').strip()
        try:
            v = json.loads(blob)
            if isinstance(v, list):
                args += [str(x) for x in v]
        except Exception:  # noqa: BLE001
            pass
    return args


def interesting_flags(args):
    out = {}
    for i, a in enumerate(args):
        key = a.split("=")[0]
        if key not in INTERESTING:
            continue
        if "=" in a:
            out[key] = a.split("=", 1)[1]
        elif i + 1 < len(args) and not args[i + 1].startswith("-"):
            out[key] = args[i + 1]
        else:
            out[key] = "on"          # 布尔开关，如 --enable-chunked-prefill
    return out


def pid_container(pid, containers):
    try:
        with open(f"/proc/{pid}/cgroup", "r", encoding="utf-8") as f:
            txt = f.read()
    except Exception:  # noqa: BLE001
        return None
    m = re.search(r"([0-9a-f]{64})", txt)
    if not m:
        return None
    for c in containers:
        if m.group(1).startswith(c["id"]):
            return c["name"]
    return None


def collect_env(c):
    """容器、端口映射、启动参数、GPU 归属 —— 一次采集，写进报告。"""
    env = {"available": False}
    containers = docker_containers()
    if containers:
        env["available"] = True
        env["containers"] = containers
        ctn = container_for_port(containers, c["port"])
        if ctn:
            env["container"] = ctn
            env["flags"] = interesting_flags(container_args(ctn["name"]))
    return env


class GpuSampler(threading.Thread):
    """整卡 used/total/util + 按 pid 归属的显存。"""

    def __init__(self, mem_cmd, proc_cmd, interval=0.5, server_pid=None):
        super().__init__(daemon=True)
        self.mem_cmd, self.proc_cmd = mem_cmd, proc_cmd
        self.interval = interval
        self.server_pid = server_pid
        self.dev, self.util, self.procs = [], [], []
        self.total = None
        self._halt = threading.Event()

    def _sample(self):
        out = _sh(self.mem_cmd)
        for line in out.splitlines():
            nums = []
            for part in line.replace("MiB", "").replace("MB", "").split(","):
                part = part.strip().split()[0] if part.strip() else ""
                try:
                    nums.append(float(part))
                except ValueError:
                    pass
            if nums:
                self.dev.append(nums[0])
                if len(nums) > 1:
                    self.total = self.total or nums[1]
                if len(nums) > 2:
                    self.util.append(nums[2])
                break
        if self.proc_cmd:
            m = {}
            for line in _sh(self.proc_cmd).splitlines():
                parts = [p.strip() for p in line.split(",")]
                if len(parts) >= 2:
                    try:
                        m[int(parts[0])] = float(parts[1])
                    except ValueError:
                        pass
            if m:
                self.procs.append(m)

    def run(self):
        while not self._halt.is_set():
            try:
                self._sample()
            except Exception:  # noqa: BLE001
                pass
            self._halt.wait(self.interval)

    def stop(self):
        self._halt.set()
        try:
            self.join(timeout=5)
        except Exception as e:  # noqa: BLE001
            print(f"! GPU 采样线程收尾异常（不影响结果）：{e}")

    def summary(self):
        if not self.dev:
            return {}
        out = {"dev_avg": round(statistics.fmean(self.dev), 1),
               "dev_peak": round(max(self.dev), 1),
               "total": self.total,
               "util_avg": round(statistics.fmean(self.util), 1) if self.util else None}
        if self.procs:
            last = self.procs[-1]
            n_procs = len(last)
            out["n_procs"] = n_procs
            if self.server_pid and self.server_pid in last:
                out["proc_avg"] = round(last[self.server_pid], 1)
            elif n_procs == 1:
                out["proc_avg"] = round(list(last.values())[0], 1)
            out["procs"] = {str(k): round(v, 1) for k, v in last.items()}
        return out


class EngineSampler(threading.Thread):
    """/metrics 里的 running / waiting，判断引擎到底有没有并行。

    不绑死 vLLM 的指标名：兼容带 label / 不带 label、SGLang 的
    num_running_reqs / queue_reqs，以及各版本前缀差异。
    """

    LINE = re.compile(r"^([a-zA-Z_:][\w:.]*)(?:\{[^}]*\})?\s+([-+0-9.eE]+)$")

    def __init__(self, url, interval=0.5):
        super().__init__(daemon=True)
        self.url, self.interval = url, interval
        self.running, self.waiting = [], []
        self.http_ok = False
        self.err = None
        self.names = set()
        self._halt = threading.Event()

    @classmethod
    def parse(cls, txt):
        run = wait = 0.0
        f_run = f_wait = False
        names = set()
        for line in txt.splitlines():
            s = line.strip()
            if not s or s.startswith("#"):
                continue
            m = cls.LINE.match(s)
            if not m:
                continue
            name, val = m.group(1).lower(), float(m.group(2))
            names.add(name)
            if ("num_requests_running" in name or "num_running" in name
                    or name.endswith("running_reqs") or name.endswith("running_requests")):
                run += val
                f_run = True
            elif ("num_requests_waiting" in name or "num_queue" in name
                  or name.endswith("waiting_reqs") or name.endswith("queue_reqs")
                  or name.endswith("queued_requests")):
                wait += val
                f_wait = True
        return run, f_run, wait, f_wait, names

    def run(self):
        while not self._halt.is_set():
            try:
                with urllib.request.urlopen(self.url, timeout=5) as r:
                    txt = r.read().decode("utf-8", "replace")
                self.http_ok = True
                run, f_run, wait, f_wait, names = self.parse(txt)
                if names:
                    self.names = names
                if f_run:
                    self.running.append(run)
                if f_wait:
                    self.waiting.append(wait)
            except Exception as e:  # noqa: BLE001
                self.err = f"{type(e).__name__}: {e}"
            self._halt.wait(self.interval)

    def stop(self):
        self._halt.set()
        try:
            self.join(timeout=5)
        except Exception as e:  # noqa: BLE001
            print(f"! metrics 采样线程收尾异常（不影响结果）：{e}")

    def status(self):
        if self.running:
            return "ok"
        if not self.http_ok:
            return f"连不上 {self.url}（{self.err or '无响应'}）"
        if not self.names:
            return f"{self.url} 可访问但没有解析到指标行（可能不是 Prometheus 文本格式）"
        sample = ", ".join(sorted(self.names)[:4])
        return f"{self.url} 可访问，但没找到 running 指标（已有 {len(self.names)} 个，如 {sample}）"

    def summary(self):
        if not self.running:
            return {"status": self.status()}
        out = {}
        if self.running:
            out["run_avg"] = round(statistics.fmean(self.running), 2)
            out["run_max"] = round(max(self.running), 1)
        if self.waiting:
            out["wait_avg"] = round(statistics.fmean(self.waiting), 2)
            out["wait_max"] = round(max(self.waiting), 1)
        return out


# ================================================================ 统计

def pct(vals, p):
    if not vals:
        return 0.0
    s = sorted(vals)
    if len(s) == 1:
        return s[0]
    k = (len(s) - 1) * p
    lo, hi = int(k), min(int(k) + 1, len(s) - 1)
    return s[lo] + (s[hi] - s[lo]) * (k - lo)


def stats_of(lat):
    if not lat:
        return {"mean": 0, "p50": 0, "p90": 0, "p95": 0, "p99": 0, "max": 0}
    return {"mean": statistics.fmean(lat), "p50": pct(lat, .5), "p90": pct(lat, .9),
            "p95": pct(lat, .95), "p99": pct(lat, .99), "max": max(lat)}


class Level:
    def __init__(self, label, conc=None, rate=None):
        self.label, self.conc, self.rate = label, conc, rate
        self.ok = self.err = 0
        self.lat, self.bad, self.errors = [], collections.Counter(), collections.Counter()
        self.decisions = self.tokens = 0
        self.elapsed = 0.0
        self.gpu, self.eng = {}, {}
        self.by_bucket = collections.defaultdict(lambda: {"n": 0, "lat": [], "tok": 0})

    @property
    def rps(self):
        return self.ok / self.elapsed if self.elapsed else 0.0

    @property
    def dps(self):
        return self.decisions / self.elapsed if self.elapsed else 0.0

    @property
    def tps(self):
        return self.tokens / self.elapsed if self.elapsed else 0.0

    @property
    def err_rate(self):
        t = self.ok + self.err
        return self.err / t if t else 0.0

    def add(self, ok, code, dt, raw, s, verify=True):
        if not ok:
            self.err += 1
            self.errors[code] += 1
            return
        self.ok += 1
        self.lat.append(dt)
        nq, tin, bad = inspect(raw, verify)
        self.decisions += nq or s.nq
        self.tokens += tin or s.est_tokens
        bk = self.by_bucket[s.bucket]
        bk["n"] += 1
        bk["lat"].append(dt)
        bk["tok"] += tin or s.est_tokens
        for why in bad:
            self.bad[why.split(":")[0] if ":" in why else why] += 1

    def as_dict(self):
        st = stats_of(self.lat)
        return {
            "label": self.label, "concurrency": self.conc, "target_rate": self.rate,
            "ok": self.ok, "err": self.err, "err_rate": round(self.err_rate, 6),
            "bad": sum(self.bad.values()), "bad_kinds": dict(self.bad),
            "errors": dict(self.errors),
            "req_per_s": round(self.rps, 2), "decisions_per_s": round(self.dps, 2),
            "input_tokens_per_s": round(self.tps, 1),
            "tokens_per_req": round(self.tokens / self.ok, 1) if self.ok else 0,
            "lat_ms": {k: round(v, 1) for k, v in st.items()},
            "elapsed_s": round(self.elapsed, 3),
            "gpu": self.gpu, "engine": self.eng,
            "by_bucket": {k: {"n": v["n"],
                              "req_per_s": round(v["n"] / self.elapsed, 2) if self.elapsed else 0,
                              "p50_ms": round(pct(v["lat"], .5), 1),
                              "p95_ms": round(pct(v["lat"], .95), 1)}
                          for k, v in self.by_bucket.items()},
        }


# ================================================================ 执行

def run_closed(pool, samples, n, duration, verify=True):
    lv = Level(f"c{n}", conc=n)
    stop = time.perf_counter() + duration
    buf, lock, idx = [], threading.Lock(), [0]
    t0 = time.perf_counter()

    def worker():
        local, c = [], pool.get()
        while time.perf_counter() < stop:
            with lock:
                i = idx[0]
                idx[0] += 1
            s = samples[i % len(samples)]
            t = time.perf_counter()
            try:
                st, raw = c.post(s.body)
                ok, code = (200 <= st < 300), str(st)
            except Exception as e:  # noqa: BLE001
                ok, code, raw = False, type(e).__name__, b""
            local.append((ok, code, (time.perf_counter() - t) * 1000.0, raw, s))
        with lock:
            buf.extend(local)

    ths = [threading.Thread(target=worker, daemon=True) for _ in range(n)]
    for t in ths:
        t.start()
    for t in ths:
        t.join()
    lv.elapsed = time.perf_counter() - t0
    for ok, code, dt, raw, s in buf:
        lv.add(ok, code, dt, raw, s, verify)
    return lv


def run_open(pool, samples, rate, duration, verify=True):
    lv = Level(f"r{rate:g}", rate=rate)
    cap = max(64, int(rate * 20))
    lock, idx = threading.Lock(), [0]
    t_end = time.perf_counter() + duration
    t0 = time.perf_counter()

    def one():
        with lock:
            i = idx[0]
            idx[0] += 1
        s = samples[i % len(samples)]
        t = time.perf_counter()
        try:
            st, raw = pool.get().post(s.body)
            ok, code = (200 <= st < 300), str(st)
        except Exception as e:  # noqa: BLE001
            ok, code, raw = False, type(e).__name__, b""
        lv.add(ok, code, (time.perf_counter() - t) * 1000.0, raw, s, verify)

    ex = ThreadPoolExecutor(max_workers=cap)
    now = time.perf_counter()
    while now < t_end and rate > 0:
        ex.submit(one)
        now += 1.0 / rate
        d = now - time.perf_counter()
        if d > 0:
            time.sleep(d)
    ex.shutdown(wait=True)
    lv.elapsed = time.perf_counter() - t0
    return lv


# ================================================================ 主流程

def resolve_pid(port):
    """尽力找出监听该端口的进程 pid；取不到返回 None。"""
    try:
        out = _sh(f"ss -ltnp 2>/dev/null | grep ':{port} '")
        m = re.search(r"pid=(\d+)", out)
        if m:
            return int(m.group(1))
    except Exception:  # noqa: BLE001
        pass
    try:
        out = _sh(f"lsof -ti:{port} 2>/dev/null | head -1").strip()
        return int(out) if out.isdigit() else None
    except Exception:  # noqa: BLE001
        return None


def detect_model(base):
    try:
        with urllib.request.urlopen(f"{base}/v1/models", timeout=8) as r:
            j = json.loads(r.read().decode("utf-8", "replace"))
        items = j.get("data") or j.get("models") or []
        if items:
            return items[0].get("id") or items[0].get("name") or ""
    except Exception:  # noqa: BLE001
        pass
    return ""


def build_ctx(cfg, over):
    base = over.base or cfg.get("api", "base")
    u = urllib.parse.urlparse(base)
    if not u.hostname:
        raise SystemExit(f"base 不合法：{base}")
    base_netloc = f"{u.scheme}://{u.netloc}"
    model = over.model or cfg.get("api", "model") or detect_model(base)
    key = over.api_key or os.environ.get("JEV_API_KEY") or cfg.get("api", "api_key")
    headers = {"Content-Type": "application/json", "Connection": "keep-alive"}
    if key:
        headers["Authorization"] = f"Bearer {key}"

    pid = None
    sp = cfg.get("gpu", "server_pid").strip()
    if sp.isdigit():
        pid = int(sp)
    elif sp.lower() == "auto":
        pid = resolve_pid(u.port or 8000)

    total = cfg.get("gpu", "vram_total_mb").strip()
    mu = cfg.get("engine", "metrics_url").strip()
    if mu.lower() in ("", "auto"):
        mu = f"{base_netloc}/metrics"   # 单容器部署：metrics 与 API 同端口
    return {
        "base": f"{u.scheme}://{u.netloc}", "host": u.hostname, "port": u.port or 8000,
        "endpoint": cfg.get("api", "endpoint"), "model": model, "headers": headers,
        "timeout": cfg.f("api", "timeout"),
        "dataset": cfg.pathof(cfg.get("run", "dataset")),
        "out_dir": cfg.pathof(cfg.get("run", "out_dir")),
        "warmup": over.warmup if over.warmup is not None else cfg.f("run", "warmup"),
        "slo": over.slo or cfg.f("run", "slo_p95_ms"),
        "long_slo": cfg.f("steps", "long_slo_p95_ms"),
        "max_err": cfg.f("run", "max_err"),
        "gpu_on": cfg.b("gpu", "enabled") and not over.no_mem,
        "mem_cmd": cfg.get("gpu", "mem_cmd"),
        "proc_cmd": cfg.get("gpu", "proc_cmd"),
        "server_pid": pid,
        "util": cfg.f("gpu", "gpu_memory_utilization"),
        "vram_total": float(total) if total else None,
        "metrics_url": mu,
        "local": (u.hostname in ("127.0.0.1", "localhost", "0.0.0.0", "::1")),
    }


def run_step(c, name, spec, buckets, duration, verify=True):
    samples = load_dataset(c["dataset"], c["model"], buckets)
    pool = Pool(c["host"], c["port"], c["endpoint"], c["headers"], c["timeout"])

    idle = {}
    if c["gpu_on"]:
        g = GpuSampler(c["mem_cmd"], c["proc_cmd"], server_pid=c["server_pid"])
        g.start()
        time.sleep(2)
        g.stop()
        idle = g.summary()
        if idle:
            msg = f"[基线] 整卡 {idle.get('dev_avg', '?')}/{idle.get('total', '?')} MB"
            if idle.get("proc_avg"):
                msg += f"  本进程 {idle['proc_avg']:.0f} MB"
            if idle.get("n_procs", 1) > 1:
                msg += f"  同卡进程 {idle['n_procs']} 个"
            print(msg)

    levels = []
    for kind, val in spec:
        if c["warmup"] > 0:
            (run_closed if kind == "c" else run_open)(
                pool, samples, val, c["warmup"], False)
            print(f"[warmup] {kind}{val}")
        gs = GpuSampler(c["mem_cmd"], c["proc_cmd"], server_pid=c["server_pid"]) \
            if c["gpu_on"] else None
        es = EngineSampler(c["metrics_url"]) if c["metrics_url"] else None
        if gs:
            gs.start()
        if es:
            es.start()
        lv = (run_closed if kind == "c" else run_open)(pool, samples, val, duration, verify)
        if gs:
            gs.stop()
            lv.gpu = gs.summary()
        if es:
            es.stop()
            lv.eng = es.summary()
        levels.append(lv)
        st = stats_of(lv.lat)
        run_s = lv.eng.get("run_max", "-")
        util = lv.gpu.get("util_avg", "-")
        print(f"[{lv.label:<8}] {lv.rps:7.1f} req/s {lv.dps:7.1f} dec/s {lv.tps:8.0f} tok/s "
              f"p50={st['p50']:5.0f} p95={st['p95']:5.0f} err={lv.err_rate*100:.2f}% "
              f"run_max={run_s} util={util}")

    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    outdir = os.path.join(c["out_dir"], f"{ts}-{name}")
    return outdir, levels, idle


# ================================================================ 报告

def _cell(v, nd=1):
    """没有数据显示成 '-'：0 和 缺数据 含义完全不同。"""
    return "-" if v is None else f"{v:.{nd}f}"


def fmt_table(levels):
    head = (f"{'档位':<7}{'并发/速率':>9}{'req/s':>9}{'dec/s':>9}{'tok/s':>9}"
            f"{'p50':>7}{'p95':>7}{'err%':>7}{'mem':>7}{'gpu%':>6}{'run':>6}{'wait':>6}")
    out = [head, "-" * len(head)]
    for lv in levels:
        st = stats_of(lv.lat)
        tag = lv.conc if lv.conc is not None else f"{lv.rate:g}/s"
        mem = lv.gpu.get("proc_avg") or lv.gpu.get("dev_avg") or 0
        out.append(
            f"{lv.label:<7}{str(tag):>9}{lv.rps:>9.1f}{lv.dps:>9.1f}{lv.tps:>9.0f}"
            f"{st['p50']:>7.0f}{st['p95']:>7.0f}{lv.err_rate*100:>7.2f}"
            f"{mem:>7.0f}{lv.gpu.get('util_avg', 0) or 0:>6.0f}"
            f"{_cell(lv.eng.get('run_max')):>6}{_cell(lv.eng.get('wait_max')):>6}")
    return "\n".join(out)


def diagnose(levels_short, levels_long, c):
    """返回 (瓶颈类型, 证据列表)。"""
    ev = []
    runs = [lv.eng.get("run_max") for lv in levels_short + levels_long
            if lv.eng.get("run_max") is not None]
    utils = [lv.gpu.get("util_avg") for lv in levels_short + levels_long
             if lv.gpu.get("util_avg") is not None]
    if not runs:
        why = next((lv.eng.get("status") for lv in levels_short + levels_long
                    if lv.eng.get("status")),
                   f"连不上 {c.get('metrics_url') or '(未配置 metrics_url)'}")
        return "unknown", [f"未采集到 running 指标：{why}",
                           "这不代表引擎没有并行，只代表采样端没读到；先跑 python bench.py probe"]

    rmax = max(runs)
    umax = max(utils) if utils else None
    ev.append(f"num_requests_running 峰值 {rmax:g}")
    if umax is not None:
        ev.append(f"GPU 利用率峰值 {umax:g}%")
    np = next((lv.gpu.get("n_procs") for lv in levels_short + levels_long
               if lv.gpu.get("n_procs")), None)
    if np and np > 1:
        ev.append(f"同卡共 {np} 个进程：算力与显存是分摊后的结果")

    gain = 0.0
    if len(levels_short) >= 2:
        base = levels_short[0]
        if base.rps > 0:
            gain = levels_short[-1].rps / base.rps
            ev.append(f"并发 {base.conc}→{levels_short[-1].conc}，吞吐 ×{gain:.2f}")

    if rmax <= 1.5:
        return "serial", ev + ["running≈1：引擎一次只执行一个请求，并发只增加排队"]
    if umax is not None and umax >= 85:
        return "gpu_bound", ev + ["GPU 已接近打满，属于算力饱和"]
    if gain < 1.3:
        return "sched", ev + ["running>1 但吞吐几乎不涨：调度/业务层未有效利用 GPU"]
    return "ok", ev


def capacity(levels, slo):
    good = [lv for lv in levels if lv.ok and lv.err_rate <= 0.001
            and stats_of(lv.lat)["p95"] <= slo]
    if not good:
        return None
    return max(good, key=lambda lv: (lv.conc or 0, lv.rate or 0))


def write_report(outdir, c, step, levels, idle):
    os.makedirs(outdir, exist_ok=True)
    data = {"version": VERSION, "step": step, "time": datetime.now().isoformat(),
            "model": c["model"], "base": c["base"] + c["endpoint"],
            "idle": idle, "levels": [lv.as_dict() for lv in levels]}
    json.dump(data, open(os.path.join(outdir, "points.json"), "w", encoding="utf-8"),
              ensure_ascii=False, indent=2)

    head = (f"{'档位':<7}{'并发/速率':>9}{'req/s':>9}{'dec/s':>9}{'tok/s':>9}"
            f"{'p50':>7}{'p95':>7}{'p99':>7}{'err%':>7}{'bad':>5}{'mem':>7}{'gpu%':>6}")
    lines = [head, "-" * (len(head) + 4)]
    for lv in levels:
        st = stats_of(lv.lat)
        tag = lv.conc if lv.conc is not None else f"{lv.rate:g}/s"
        mem = lv.gpu.get("proc_avg") or lv.gpu.get("dev_avg") or 0
        lines.append(f"{lv.label:<7}{str(tag):>9}{lv.rps:>9.1f}{lv.dps:>9.1f}{lv.tps:>9.0f}"
                     f"{st['p50']:>7.0f}{st['p95']:>7.0f}{st['p99']:>7.0f}"
                     f"{lv.err_rate*100:>7.2f}{sum(lv.bad.values()):>5}{mem:>7.0f}"
                     f"{lv.gpu.get('util_avg', 0) or 0:>6.0f}")
    md = [f"# 压测 · {step}", "",
          f"- 模型：`{c['model']}`",
          f"- 目标：`{c['base']}{c['endpoint']}`",
          f"- 时间：{datetime.now().isoformat(timespec='seconds')}",
          f"- 显存口径：本进程 {idle.get('proc_avg', '?')} MB / 整卡 "
          f"{idle.get('dev_avg', '?')} MB（共 {idle.get('n_procs', '?')} 进程）"
          if idle else "- 显存：未采集",
          "", "## 结果", "", "| " + " | ".join(
              ["档位", "并发", "req/s", "dec/s", "tok/s", "p50", "p95", "p99", "err%", "bad",
               "mem MB", "GPU%", "run", "wait"]) + " |",
          "|" + "---|" * 14]
    for lv in levels:
        st = stats_of(lv.lat)
        tag = lv.conc if lv.conc is not None else f"{lv.rate:g}/s"
        mem = lv.gpu.get("proc_avg") or lv.gpu.get("dev_avg") or 0
        md.append(f"| {lv.label} | {tag} | {lv.rps:.1f} | {lv.dps:.1f} | {lv.tps:.0f} | "
                  f"{st['p50']:.0f} | {st['p95']:.0f} | {st['p99']:.0f} | "
                  f"{lv.err_rate*100:.2f} | {sum(lv.bad.values())} | {mem:.0f} | "
                  f"{lv.gpu.get('util_avg', 0) or 0:.0f} | {_cell(lv.eng.get('run_max'), 0)} | "
                  f"{_cell(lv.eng.get('wait_max'), 0)} |")
    open(os.path.join(outdir, "report.md"), "w", encoding="utf-8").write("\n".join(md) + "\n")
    return outdir


def env_lines(c, levels):
    """报告里的「环境」小节：GPU、容器、启动参数、同卡进程。"""
    env = c.get("env") or {}
    out = ["## 0. 环境", ""]
    gpu = _sh(c["mem_cmd"]).strip().splitlines()
    if gpu:
        out.append(f"- GPU：`{gpu[0]}`（已用 / 总量 / 利用率%）")
    ctn = env.get("container")
    if ctn:
        out.append(f"- 容器：`{ctn['name']}`（{ctn['image']}），端口 `{ctn['ports']}`")
    flags = env.get("flags") or {}
    if flags:
        out.append("- 启动参数：" + "；".join(f"`{k}` {v}" for k, v in flags.items()))
    procs = {}
    for lv in levels:
        if lv.gpu.get("procs"):
            procs = lv.gpu["procs"]
            break
    if procs:
        names = []
        for pid, mb in sorted(procs.items(), key=lambda x: -float(x[1])):
            nm = pid_container(int(pid), env.get("containers") or []) or "?"
            names.append(f"{nm} {float(mb):.0f}MB")
        out.append(f"- 同卡进程 {len(procs)} 个：" + "，".join(names))
        if len(procs) > 1:
            out.append("- ⚠ 吞吐与显存是同卡分摊后的结果，**不代表单模型裸能力**")
    if not procs and not ctn:
        out.append("- 容器信息不可用（docker 未安装/无权限），仅按端口与 GPU 采样")
    out.append("")
    return out


def write_summary(run_dir, c, results):
    """results: [(step, levels, idle)] → REPORT.md（短报告）"""
    steps = {}
    for step, levels, idle in results:
        steps[step] = (levels, idle)

    short = steps.get("short", ([], {}))[0]
    long_ = steps.get("long", ([], {}))[0]
    open_ = steps.get("open", ([], {}))[0]
    smoke = steps.get("smoke", ([], {}))[0]

    lines = [f"# 基准报告：{c['model'] or '未知模型'}", "",
             f"> 目标 `{c['base']}{c['endpoint']}` ｜ "
             f"{datetime.now().strftime('%Y-%m-%d %H:%M')} ｜ 引擎预算 "
             f"{c['util'] * 100:.0f}% 显存", ""]

    lines += env_lines(c, short + long_ + open_)

    # ---- 结论
    kind, ev = diagnose(short, long_, c)
    label = {"serial": "引擎未并行（batch≈1）：并发只增加排队，不增加吞吐",
             "gpu_bound": "GPU 算力饱和：已接近硬件上限",
             "sched": "调度受限：GPU 有空闲但吞吐上不去",
             "ok": "并发扩展正常", "unknown": "并行度未知（缺 metrics）"}[kind]

    s0 = short[0] if short else None
    if s0:
        st = stats_of(s0.lat)
        lines += [f"**结论**：单流 {st['p50']:.0f} ms（{s0.tps:.0f} tok/s）；"
                  f"并发 {s0.conc}→{short[-1].conc} 吞吐 ×{short[-1].rps / max(s0.rps, 1e-9):.2f}，"
                  f"p95 从 {st['p95']:.0f} ms 涨到 {stats_of(short[-1].lat)['p95']:.0f} ms。"
                  f"{label}。", ""]

    # ---- 1 单流
    lines += ["## 1. 单流基准（并发 1）", "",
              "| 场景 | 输入 token | p50 | p95 | tok/s |", "|---|---|---|---|---|"]
    base_lv = (smoke or short)[0] if (smoke or short) else None
    if base_lv:
        st = stats_of(base_lv.lat)
        lines.append(f"| 短文本 | {base_lv.tokens / max(base_lv.ok, 1):.0f} | {st['p50']:.0f} | "
                     f"{st['p95']:.0f} | {base_lv.tps:.0f} |")
    if long_:
        lv = long_[0]
        st = stats_of(lv.lat)
        lines.append(f"| 长文本 | {lv.tokens / max(lv.ok, 1):.0f} | {st['p50']:.0f} | "
                     f"{st['p95']:.0f} | {lv.tps:.0f} |")
    lines.append("")

    # ---- 2 并发扩展
    if short:
        lines += ["## 2. 并发扩展（短文本，闭环）", "",
                  "| 并发 | req/s | 吞吐增益 | p50 | p95 | GPU% | run |", "|---|---|---|---|---|---|---|"]
        b = short[0].rps or 1e-9
        for lv in short:
            st = stats_of(lv.lat)
            lines.append(f"| {lv.conc} | {lv.rps:.1f} | ×{lv.rps / b:.2f} | {st['p50']:.0f} | "
                         f"{st['p95']:.0f} | {lv.gpu.get('util_avg', 0) or 0:.0f} | "
                         f"{_cell(lv.eng.get('run_max'), 0)} |")
        lines.append("")

    # ---- 3 长上下文
    if long_:
        lines += ["## 3. 长上下文（4~6k token）", "",
                  "| 并发 | req/s | p50 | p95 | tok/s |", "|---|---|---|---|---|"]
        for lv in long_:
            st = stats_of(lv.lat)
            lines.append(f"| {lv.conc} | {lv.rps:.2f} | {st['p50']:.0f} | {st['p95']:.0f} | "
                         f"{lv.tps:.0f} |")
        lines.append("")

    # ---- 4 开环容量
    if open_:
        lines += ["## 4. 开环容量（短文本）", "",
                  "| 到达率 | 实际 | 达成率 | p95 | 判定 |", "|---|---|---|---|---|"]
        for lv in open_:
            st = stats_of(lv.lat)
            ok = st["p95"] <= c["slo"] and lv.err_rate <= c["max_err"]
            lines.append(f"| {lv.rate:g}/s | {lv.rps:.1f} | "
                         f"{lv.rps / max(lv.rate, 1e-9) * 100:.0f}% | {st['p95']:.0f} | "
                         f"{'✅ 达标' if ok else '❌ 超 SLO'} |")
        lines.append("")

    # ---- 5 瓶颈证据
    lines += ["## 5. 瓶颈证据", ""] + [f"- {e}" for e in ev]
    if c["gpu_on"]:
        idle = (short[0].gpu if short else {})
        if idle.get("n_procs", 1) > 1:
            lines.append(f"- 同卡共 {idle['n_procs']} 个进程，整卡 "
                         f"{idle.get('dev_avg', 0):.0f} MB 中本进程 "
                         f"{idle.get('proc_avg', 0):.0f} MB")
        if idle.get("total") and c["util"]:
            lines.append(f"- 引擎显存预算 {c['util'] * 100:.0f}% × {idle['total']:.0f} MB "
                         f"≈ {c['util'] * idle['total']:.0f} MB")
    lines.append("")

    # ---- 6 容量承诺
    lines += ["## 6. 可承诺容量", "", "| 场景 | SLO | 可承诺 |", "|---|---|---|"]
    k = capacity(short, c["slo"])
    if k:
        lines.append(f"| 短文本 | p95 ≤ {c['slo']:.0f} ms | {k.rps:.1f} req/s |")
    else:
        lines.append(f"| 短文本 | p95 ≤ {c['slo']:.0f} ms | 无（最低档已超） |")
    if long_:
        kl = capacity(long_, c["long_slo"])
        if kl:
            lines.append(f"| 长文本 | p95 ≤ {c['long_slo']:.0f} ms | {kl.rps:.2f} req/s |")
        else:
            lines.append(f"| 长文本 | p95 ≤ {c['long_slo']:.0f} ms | 无（单流已超） |")
    lines.append("")

    if c["local"]:
        lines += ["> 注意：压测客户端与服务同机（127.0.0.1），高并发段客户端会抢 CPU；"
                  "结论以 running/GPU 利用率为准。", ""]

    path = os.path.join(run_dir, "REPORT.md")
    open(path, "w", encoding="utf-8").write("\n".join(lines))
    return path


# ================================================================ main

def step_check(c):
    print(SEP)
    print(f"契约检查 → {c['base']}{c['endpoint']}  model={c['model']}")
    print(SEP)
    s = load_dataset(c["dataset"], c["model"], ["short"])[0]
    try:
        st, raw = Pool(c["host"], c["port"], c["endpoint"], c["headers"],
                       c["timeout"]).get().post(s.body)
    except Exception as e:  # noqa: BLE001
        print(f"! 连不上 {c['base']}{c['endpoint']}：{type(e).__name__}: {e}")
        print("  检查服务是否启动、base/port 是否写对。")
        return 2
    print(f"HTTP {st}  {len(raw)} B")
    try:
        j = json.loads(raw)
    except Exception:  # noqa: BLE001
        print("! 不是 JSON：", raw[:200])
        return 1
    print(json.dumps(j, ensure_ascii=False, indent=2)[:1200])
    nq, tin, bad = inspect(raw, True)
    print(f"\nanswers={nq}  input_tokens={tin}  contract={'OK' if not bad else bad}")
    return 0 if (st == 200 and nq and not bad) else 1


def step_env(c):
    """打印环境快照：容器、端口映射、启动参数、GPU 归属。"""
    print(SEP)
    print("环境快照")
    print(SEP)
    out = _sh(c["mem_cmd"])
    print(f"GPU: {out.strip() or '(读不到 nvidia-smi)'}")

    env = collect_env(c)
    if not env.get("available"):
        print("! docker 不可用（或当前用户无权限），跳过容器信息")
        return 0

    print(f"\n容器 {len(env['containers'])} 个：")
    for ct in env["containers"]:
        mark = " ← 当前目标" if (c["port"] and ct is env.get("container")) else ""
        print(f"  {ct['name']:<28} {ct['image']:<40} {ct['status']:<22} "
              f"{ct['ports']}{mark}")

    if env.get("container"):
        print(f"\n目标容器的启动参数：")
        flags = env.get("flags") or {}
        if flags:
            for k, v in flags.items():
                print(f"  {k} {v}")
        else:
            print("  （没解析到关键参数，可手动 docker inspect 看 Cmd）")

    procs = []
    for line in _sh(c["proc_cmd"]).splitlines():
        p = [x.strip() for x in line.split(",")]
        if len(p) >= 2 and p[0].isdigit():
            procs.append((int(p[0]), float(p[1])))
    if procs:
        print(f"\nGPU 上的进程 {len(procs)} 个：")
        for pid, mb in sorted(procs, key=lambda x: -x[1]):
            name = pid_container(pid, env["containers"]) or "?"
            print(f"  pid {pid:<8} {mb:>8.0f} MB   {name}")
        if len(procs) > 1:
            print("  ⚠ 同卡多进程：吞吐/显存是分摊后的结果，不是单模型的裸能力")
    return 0


def step_probe(c):
    """探测哪里能拿到 running / waiting 指标。"""
    u = urllib.parse.urlparse(c["base"])
    host = u.hostname
    cands = []
    if c.get("metrics_url"):
        cands.append(c["metrics_url"])
    cands.append(f"{c['base']}/metrics")
    for p in (18000, 8000, 8001, 8080, 30000):
        cands.append(f"{u.scheme}://{host}:{p}/metrics")

    seen, urls = set(), []
    for x in cands:
        if x and x not in seen:
            seen.add(x)
            urls.append(x)

    print(SEP)
    print("metrics 探测：找出哪个地址能读到 num_requests_running")
    print(SEP)
    hit = None
    for url in urls:
        try:
            with urllib.request.urlopen(url, timeout=4) as r:
                code, txt = r.status, r.read(40000).decode("utf-8", "replace")
        except urllib.error.HTTPError as e:
            print(f"{url:<50} HTTP {e.code}")
            continue
        except Exception as e:  # noqa: BLE001
            print(f"{url:<50} 连不上（{type(e).__name__}）")
            continue
        run, f_run, wait, f_wait, names = EngineSampler.parse(txt)
        if f_run:
            print(f"{url:<50} HTTP {code}  {len(names):>3} 个指标  "
                  f"✅ running={run:g} waiting={wait:g}")
            hit = hit or url
        else:
            print(f"{url:<50} HTTP {code}  {len(names):>3} 个指标  ⚠ 无 running")

    if hit:
        print(f"\n→ 写进 config.ini：\n  [engine]\n  metrics_url = {hit}")
    else:
        print("\n! 所有候选地址都拿不到 running 指标。按顺序排查：")
        print("  1) 引擎可能只监听容器内 127.0.0.1：docker exec <容器> curl -s localhost:8000/metrics | head")
        print("  2) 端口是否被映射：ss -ltnp | grep -E '8000|18000'")
        print("  3) 引擎换了 runtime（SGLang/TRT-LLM 指标名不同，本脚本已兼容常见别名）")
    out = _sh("docker ps --format '{{.Names}} {{.Ports}}' 2>/dev/null | head -5")
    if out.strip():
        print("\n本机容器 / 端口映射：")
        for line in out.strip().splitlines():
            print("  " + line)
    return 0 if hit else 1


def main():
    ap = argparse.ArgumentParser(description=f"jev 压测 {VERSION}")
    ap.add_argument("step", nargs="?", default="all",
                    choices=["check", "env", "probe", "smoke", "short", "long",
                             "open", "all"])
    ap.add_argument("--config", default=os.path.join(HERE, "config.ini"))
    ap.add_argument("--base")
    ap.add_argument("--model")
    ap.add_argument("--api-key")
    ap.add_argument("--duration", type=float)
    ap.add_argument("--warmup", type=float)
    ap.add_argument("--slo", type=float)
    ap.add_argument("--concurrency")
    ap.add_argument("--out-dir")
    ap.add_argument("--no-mem", action="store_true")
    ap.add_argument("--metrics-url", help="覆盖 config 里的 vLLM /metrics 地址")
    ap.add_argument("--pid", type=int, help="覆盖服务进程 pid（显存按进程归属）")
    over = ap.parse_args()

    cfg = Cfg(over.config)
    if over.metrics_url:
        if not cfg.cp.has_section("engine"):
            cfg.cp.add_section("engine")
        cfg.cp.set("engine", "metrics_url", over.metrics_url)
    if over.pid:
        if not cfg.cp.has_section("gpu"):
            cfg.cp.add_section("gpu")
        cfg.cp.set("gpu", "server_pid", str(over.pid))
    c = build_ctx(cfg, over)
    try:
        c["env"] = collect_env(c)
    except Exception:  # noqa: BLE001
        c["env"] = {}
    if over.concurrency:
        if not cfg.cp.has_section("steps"):
            cfg.cp.add_section("steps")
        cfg.cp.set("steps", "short_concurrency", over.concurrency)
    if over.out_dir:
        c["out_dir"] = os.path.abspath(over.out_dir)

    print(SEP)
    print(f"jev 压测 {VERSION}")
    print(f"  配置 : {over.config}")
    print(f"  目标 : {c['base']}{c['endpoint']}")
    print(f"  模型 : {c['model'] or '(未指定)'}")
    print(f"  数据 : {c['dataset']}")
    print(f"  显存 : 引擎预算 {c['util'] * 100:.0f}%"
          + (f"，本进程 pid={c['server_pid']}" if c["server_pid"] else "，按整卡口径"))
    print(f"  metrics: {c['metrics_url'] or '未配置'}")
    ctn = (c.get("env") or {}).get("container")
    if ctn:
        print(f"  容器 : {ctn['name']}（{ctn['image']}） 端口 {ctn['ports']}")
    elif (c.get("env") or {}).get("available"):
        print("  容器 : 未按端口匹配到容器（用 bench.py env 看全量）")
    print(f"  输出 : {c['out_dir']}")

    if over.step == "check":
        return step_check(c)
    if over.step == "env":
        return step_env(c)
    if over.step == "probe":
        return step_probe(c)

    plan = {
        "smoke": ([("c", cfg.i("steps", "smoke_concurrency"))],
                  cfg.lst("steps", "smoke_buckets"), cfg.f("steps", "smoke_duration")),
        "short": ([("c", int(x)) for x in cfg.lst("steps", "short_concurrency")],
                  cfg.lst("steps", "short_buckets"), cfg.f("run", "duration")),
        "long": ([("c", int(x)) for x in cfg.lst("steps", "long_concurrency")],
                 cfg.lst("steps", "long_buckets"), cfg.f("run", "duration")),
        "open": ([("r", float(x)) for x in cfg.lst("steps", "open_rates")],
                 cfg.lst("steps", "short_buckets"), cfg.f("steps", "open_duration")),
    }

    todo = list(plan) if over.step == "all" else [over.step]
    results, last_dir = [], c["out_dir"]
    for name in todo:
        spec, buckets, dur = plan[name]
        if over.duration:
            dur = over.duration
        print("\n" + SEP)
        print(f"步骤 {name}  桶={','.join(buckets)}  档位={len(spec)}  每档 {dur:g}s")
        print(SEP)
        outdir, levels, idle = run_step(c, name, spec, buckets, dur)
        write_report(outdir, c, name, levels, idle)
        print("\n" + fmt_table(levels))
        k = capacity(levels, c["slo"] if name != "long" else c["long_slo"])
        if k:
            print(f"\n→ 满足 SLO 的最高档：{k.label}  {k.rps:.1f} req/s")
        print(f"\n产物：{outdir}")
        results.append((name, levels, idle))
        last_dir = outdir

    if len(results) > 1:
        path = write_summary(c["out_dir"], c, results)
        print(f"\n{'=' * 78}\n短报告：{path}\n{'=' * 78}")
        print(open(path, encoding="utf-8").read())
    return 0


if __name__ == "__main__":
    sys.exit(main())
