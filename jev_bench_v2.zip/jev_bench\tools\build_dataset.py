#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
build_bench_dataset.py —— 从本地 jev_suites 生成压测数据集

为什么需要"造"数据
    现成的 out/jev_suites/*.jsonl 只有 150~585 字符的短 state、且基本一问一答。
    吞吐量对这种模型是 prefill 主导的，只测短文本会严重高估 QPS；
    必须按 state 长度分层，才能测出"长上下文下的真实容量"。

四个桶
    short  1 条真实样本，1 问         ≈ 200~400 token   典型网关判定
    mid    4 条真实 state 拼接，1 问   ≈ 800~1200 token  中等上下文
    long   24 条真实 state 拼接，1 问  ≈ 4k~6k token     贴近 8k 上限
    multi  1 条短 state，4 问          —— 测"一次调用多问"的吞吐杠杆

诚实声明
    mid / long 是把多条真实 state 首尾拼接，只为拉长 token 数，
    语义连贯性不作保证；multi 的 4 个问题来自不同样本，也可能与 state 不匹配。
    这些都只影响"内容是否合理"，不影响 token 数、延迟与显存占用。

用法（在包的上一级目录执行，或直接改 --src / --out）
    python tools/build_dataset.py                    # 读 ../out/jev_suites，写 ../data
    python tools/build_dataset.py --src D:\\corpus --out ../data --seed 20261109
"""

import argparse
import collections
import hashlib
import json
import os
import random
from datetime import datetime, timezone

# 桶名 -> (拼接样本数, 生成条数, 问题数)
BUCKETS = {
    "short": (1, 120, 1),
    "mid": (4, 80, 1),
    "long": (24, 60, 1),
    "multi": (1, 40, 4),
}

SRC_FILES = ["core.jsonl", "typeswap.jsonl", "order.jsonl", "merge.jsonl", "duplicate.jsonl"]
MAX_CHARS = 10000  # 长桶护栏，防止爆 8k token


def load_records(src_dir):
    recs = []
    for name in SRC_FILES:
        p = os.path.join(src_dir, name)
        if not os.path.exists(p):
            print(f"  ! 跳过（不存在）: {p}")
            continue
        with open(p, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                d = json.loads(line)
                if not d.get("state") or not d.get("questions"):
                    continue
                recs.append({
                    "id": d.get("id") or "",
                    "state": d["state"],
                    "questions": d["questions"],
                    "kind": (d.get("meta") or {}).get("kind") or "",
                })
    return recs


def qkeys(n):
    return [f"q{i}" for i in range(n)]


def build_one(recs, rng, bucket, k, nq):
    owners = rng.sample(range(len(recs)), k)
    if k == 1:
        state = recs[owners[0]]["state"]
    else:
        state = "\n\n".join(recs[i]["state"] for i in owners)
    if len(state) > MAX_CHARS:
        state = state[:MAX_CHARS]

    if nq == 1:
        src = recs[owners[0]]
        first_key = next(iter(src["questions"]))
        questions = {"q0": src["questions"][first_key]}
        kinds = [questions["q0"].get("type")]
        synth = k > 1
    else:
        qsrc = rng.sample(range(len(recs)), nq)
        questions, kinds = {}, []
        for j, qi in enumerate(qsrc):
            q = recs[qi]["questions"]
            questions[f"q{j}"] = q[next(iter(q))]
            kinds.append(questions[f"q{j}"].get("type"))
        synth = True

    return {
        "state": state,
        "questions": questions,
        "meta": {
            "bucket": bucket,
            "nq": len(questions),
            "state_chars": len(state),
            "kinds": kinds,
            "source_ids": [recs[i]["id"] for i in owners],
            "synthetic": synth,
        },
    }


def main():
    ap = argparse.ArgumentParser(description="生成 jev 压测数据集")
    ap.add_argument("--src", default=os.path.join("..", "out", "jev_suites"))
    ap.add_argument("--out", default=os.path.join("..", "data"))
    ap.add_argument("--seed", type=int, default=20261109)
    args = ap.parse_args()

    recs = load_records(args.src)
    if len(recs) < 30:
        raise SystemExit(f"源数据太少：{len(recs)} 条，检查 --src")
    print(f"源样本 {len(recs)} 条，来自 {args.src}")
    print("题型分布:", dict(collections.Counter(r["kind"] for r in recs)))

    rng = random.Random(args.seed)
    os.makedirs(args.out, exist_ok=True)

    rows = []
    for bucket, (k, n, nq) in BUCKETS.items():
        for i in range(n):
            row = build_one(recs, rng, bucket, k, nq)
            row["id"] = f"bench-{bucket}-{i:04d}"
            rows.append(row)

    out_jsonl = os.path.join(args.out, "jev_bench_v1.jsonl")
    with open(out_jsonl, "w", encoding="utf-8") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")

    smoke = []
    for bucket in BUCKETS:
        smoke += [r for r in rows if r["meta"]["bucket"] == bucket][:3]
    with open(os.path.join(args.out, "smoke.jsonl"), "w", encoding="utf-8") as f:
        for r in smoke:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")

    by_bucket = collections.Counter(r["meta"]["bucket"] for r in rows)
    chars = collections.defaultdict(list)
    for r in rows:
        chars[r["meta"]["bucket"]].append(r["meta"]["state_chars"])

    h = hashlib.sha256(open(out_jsonl, "rb").read()).hexdigest()
    manifest = {
        "created_at": datetime.now(timezone.utc).isoformat(),
        "source_dir": os.path.abspath(args.src),
        "source_count": len(recs),
        "seed": args.seed,
        "rows": len(rows),
        "sha256": h,
        "buckets": {
            b: {
                "count": by_bucket[b],
                "state_chars_avg": round(sum(v) / len(v)),
                "state_chars_min": min(v),
                "state_chars_max": max(v),
                "note": "mid/long 为多条真实 state 拼接；multi 的 4 问来自不同样本"
                        if b in ("mid", "long", "multi") else "单条真实样本",
            }
            for b, v in chars.items()
        },
    }
    with open(os.path.join(args.out, "manifest.json"), "w", encoding="utf-8") as f:
        json.dump(manifest, f, ensure_ascii=False, indent=2)

    print(f"\n写出 {len(rows)} 条 -> {os.path.abspath(out_jsonl)}")
    for b, v in chars.items():
        print(f"  {b:<6} {by_bucket[b]:>4} 条   state {min(v)}~{max(v)} 字符  "
              f"均 {round(sum(v)/len(v))}")
    print(f"\nmanifest: {os.path.abspath(os.path.join(args.out, 'manifest.json'))}")
    print(f"sha256  : {h[:16]}…")


if __name__ == "__main__":
    main()
