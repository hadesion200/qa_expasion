"""本地假服务：模拟 structured_decision 响应 + vLLM /metrics，用于离线验证压测链路。

    python tools/mock_server.py --port 18082            # 并发处理（正常引擎）
    python tools/mock_server.py --port 18082 --serial   # 串行处理（模拟 batch=1）

延迟按 input token 数线性放大（0.4ms / 100 tokens），模拟 prefill 成本。
--serial 时全局加锁、一次只算一个请求，running 永远 ≤1，用来验证报告里
"引擎未并行" 这条判定是否被正确触发。
"""
import argparse
import json
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

MS_PER_1K_TOKENS = 400.0
LOCK = threading.Lock()
COMPUTE = threading.Lock()
STATE = {"inflight": 0, "waiting": 0, "serial": False, "peak": 0}


class H(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, *a):
        pass

    def _send(self, obj, code=200, ctype="application/json"):
        b = (json.dumps(obj, ensure_ascii=False) if ctype == "application/json"
             else obj).encode()
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(b)))
        self.end_headers()
        self.wfile.write(b)

    def do_GET(self):
        if self.path.startswith("/health"):
            return self._send({"ok": True})
        if self.path.startswith("/v1/models"):
            return self._send({"data": [{"id": "mock-sdec-4b-8k"}]})
        if self.path.startswith("/metrics"):
            txt = ("# HELP vllm:num_requests_running\n"
                   f'vllm:num_requests_running{{model_name="mock"}} {STATE["inflight"]}\n'
                   f'vllm:num_requests_waiting{{model_name="mock"}} {STATE["waiting"]}\n')
            return self._send(txt, 200, "text/plain")
        return self._send({"err": "nf"}, 404)

    def do_POST(self):
        n = int(self.headers.get("Content-Length", 0))
        raw = self.rfile.read(n)
        try:
            body = json.loads(raw.decode("utf-8"))
        except Exception:
            return self._send({"err": "bad json"}, 400)

        state = body.get("state") or ""
        questions = body.get("questions") or {}
        toks = int(len(state) / 1.6) + 20
        delay = toks * MS_PER_1K_TOKENS / 1e6

        # running = 真正在算的；waiting = 排队等算的
        with LOCK:
            STATE["waiting"] += 1
        if STATE["serial"]:
            COMPUTE.acquire()
        with LOCK:
            STATE["waiting"] -= 1
            STATE["inflight"] += 1
            STATE["peak"] = max(STATE["peak"], STATE["inflight"])
        try:
            time.sleep(delay)
        finally:
            with LOCK:
                STATE["inflight"] -= 1
            if STATE["serial"]:
                COMPUTE.release()

        answers = {}
        for qid, q in questions.items():
            crit = q.get("criteria")
            labels = (list(crit.keys()) if isinstance(crit, dict)
                      else [str(x) for x in range(len(crit))] if isinstance(crit, list)
                      else ["false", "true"])
            w = [0.2 + 0.1 * i for i in range(len(labels))]
            s = sum(w)
            probs = {lab: round(x / s, 6) for lab, x in zip(labels, w)}
            top = max(probs, key=probs.get)
            answers[qid] = {"type": q.get("type", "choice"), "choice": top,
                            "probabilities": probs, "confidence": probs[top]}

        self._send({"id": "decision-mock", "object": "structured_decision",
                    "created": int(time.time()), "model": body.get("model", "mock"),
                    "answers": answers,
                    "usage": {"input_tokens": toks, "output_tokens": 0},
                    "diagnostics": {k: {"label_mass": 1.0, "argmax_is_label": True}
                                    for k in answers},
                    "joint": None})


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--port", type=int, default=18082)
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--serial", action="store_true", help="一次只处理一个请求")
    a = ap.parse_args()
    STATE["serial"] = a.serial
    print(f"mock: http://{a.host}:{a.port}  serial={a.serial}")
    ThreadingHTTPServer((a.host, a.port), H).serve_forever()
