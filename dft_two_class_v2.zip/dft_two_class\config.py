# -*- coding: utf-8 -*-
"""配置：改这里或用环境变量覆盖。"""
import os
from pathlib import Path

BASE = Path(__file__).resolve().parent

TREES = BASE / "data" / "trees_pack.jsonl"
OUT = Path(os.environ.get("DFT_OUT", str(BASE / "out")))
CACHE = BASE / ".cache"

API = {
    "base_url": os.environ.get("TEACHER_BASE_URL", "http://10.0.1.15:12349/v1"),
    "model": os.environ.get("TEACHER_MODEL", "WM-Qwen3.8-27B"),
    "key": os.environ.get("TEACHER_API_KEY", "EMPTY"),
    "concurrency": int(os.environ.get("TEACHER_CONCURRENCY", "16")),
    "timeout": int(os.environ.get("TEACHER_TIMEOUT", "120")),
    "retries": int(os.environ.get("TEACHER_RETRIES", "3")),
    "max_tokens": int(os.environ.get("TEACHER_MAX_TOKENS", "300")),
}

# ---- 目标量 ----
TARGET = {1: int(os.environ.get("TARGET_C1", "5000")),
          2: int(os.environ.get("TARGET_C2", "14000"))}

# ---- 每棵树每题型上限 ----
# 第一类：工程结构树（真实/FFORT/借拓扑）多给，合成树少给，压低合成占比
CAP_ANCHOR = {"mcs": 40, "action": 20, "noul": 40, "score": 40}
CAP_SYNTH = {"mcs": 12, "action": 6, "noul": 10, "score": 10}
# 第二类：全部按工程结构树配额
CAP_C2 = {"mcs": 40, "action": 20, "noul": 40, "score": 40}

# ---- 切分：90% train ----
TRAIN_RATIO = float(os.environ.get("TRAIN_RATIO", "0.90"))
DEV_RATIO = float(os.environ.get("DEV_RATIO", "0.05"))
BENCH_RATIO = 1.0 - TRAIN_RATIO - DEV_RATIO

# ---- 场景改写 ----
MIN_LEN, MAX_LEN = 50, 600
SOLVE_ROUNDS = int(os.environ.get("SOLVE_ROUNDS", "2"))
