﻿# -*- coding: utf-8 -*-
"""异步调用教师模型：并发、重试、磁盘缓存、断点续跑、mock。"""
import asyncio
import hashlib
import json
import random
import re
import sys
import time

import config

URL = config.API["base_url"].rstrip("/")
if not URL.endswith("/chat/completions"):
    URL += "/chat/completions"


def key_of(*parts):
    return hashlib.sha1("||".join(parts).encode("utf-8")).hexdigest()[:24]


def parse_json(text):
    t = (text or "").strip()
    t = re.sub(r"^```(?:json)?\s*", "", t)
    t = re.sub(r"\s*```$", "", t)
    i, j = t.find("{"), t.rfind("}")
    if i < 0 or j <= i:
        return None
    for cand in (t[i:j + 1], re.sub(r",\s*([}\]])", r"\1", t[i:j + 1])):
        try:
            return json.loads(cand)
        except Exception:
            continue
    # 兜底：半截 JSON 时直接抠字段
    ans = re.search(r'"answer"\s*:\s*"?([^",}\s]+)', t)
    if ans:
        anc = re.search(r'"anchor"\s*:\s*"([^"]*)', t)
        return {"answer": ans.group(1), "anchor": anc.group(1) if anc else "",
                "confident": True, "reason": "regex-fallback"}
    return None


class Teacher:
    def __init__(self, mock=False):
        self.mock = mock
        self.session = None
        self.calls = 0
        self.hits = 0
        config.CACHE.mkdir(parents=True, exist_ok=True)

    async def __aenter__(self):
        if not self.mock:
            try:
                import aiohttp
                self.session = aiohttp.ClientSession(
                    timeout=aiohttp.ClientTimeout(total=config.API["timeout"]))
            except ImportError:
                self.session = None
                print("[warn] 未装 aiohttp，回退 urllib 线程池", file=sys.stderr)
        return self

    async def __aexit__(self, *exc):
        if self.session:
            await self.session.close()

    async def ask(self, tag, system, user):
        cf = config.CACHE / f"{tag}_{key_of(system, user)}.json"
        if cf.exists():
            self.hits += 1
            return json.loads(cf.read_text(encoding="utf-8"))
        card = _mock(user) if self.mock else await self._post(system, user)
        if card is not None:
            cf.write_text(json.dumps(card, ensure_ascii=False), encoding="utf-8")
        return card

    async def _post(self, system, user):
        body = {"model": config.API["model"], "temperature": 0.3,
                "max_tokens": config.API["max_tokens"],
                "messages": [{"role": "system", "content": system},
                             {"role": "user", "content": user}]}
        headers = {"Content-Type": "application/json",
                   "Authorization": f"Bearer {config.API['key']}"}
        last = None
        for i in range(config.API["retries"]):
            try:
                if self.session is None:
                    data = await asyncio.to_thread(_post_urllib, body, headers)
                else:
                    async with self.session.post(URL, json=body, headers=headers) as r:
                        if r.status != 200:
                            last = f"HTTP {r.status}: {(await r.text())[:100]}"
                            await asyncio.sleep(min(15, 2 ** i + random.random()))
                            continue
                        data = await r.json()
                self.calls += 1
                card = parse_json(data["choices"][0]["message"]["content"])
                if card is None:
                    last = "JSON 解析失败"
                    await asyncio.sleep(min(8, 1.5 ** i))
                    continue
                return card
            except asyncio.CancelledError:
                raise
            except Exception as e:
                last = f"{type(e).__name__}: {e}"
                await asyncio.sleep(min(15, 2 ** i + random.random()))
        print(f"[warn] 调用失败: {last}", file=sys.stderr)
        return None


def _post_urllib(body, headers):
    import urllib.request
    req = urllib.request.Request(
        URL, data=json.dumps(body, ensure_ascii=False).encode("utf-8"),
        headers=headers, method="POST")
    with urllib.request.urlopen(req, timeout=config.API["timeout"]) as r:
        return json.loads(r.read().decode("utf-8"))


def _mock(user):
    """自检用：从提示里抠出系统名和部件，拼一句合法场景。"""
    plat = re.search(r"【系统】(.+)", user)
    comp = re.search(r"【部件】(.+)", user)
    p = plat.group(1).strip() if plat else "某分系统"
    c = (comp.group(1).split("、")[0].strip() if comp else "主控单元")
    return {"scenario": f"{p}在一次在轨测试中出现异常，值班人员在检查 {c} 相关遥测时发现参数不符合预期，"
                        f"需要据此判断该现象是否会引发系统级故障，并给出处理意见。"}


async def run_batch(teacher, jobs, out_path, fn):
    """jobs: [(id, ...)]；按 id 续跑，结果 append 到 out_path。"""
    out_path.parent.mkdir(parents=True, exist_ok=True)
    done = set()
    if out_path.exists():
        for line in out_path.open(encoding="utf-8"):
            try:
                done.add(json.loads(line)["id"])
            except Exception:
                pass
    todo = [j for j in jobs if j[0] not in done]
    print(f"[{out_path.name}] 已完成 {len(done)}，待跑 {len(todo)}")
    if not todo:
        return

    sem = asyncio.Semaphore(config.API["concurrency"])
    f = out_path.open("a", encoding="utf-8")
    t0 = time.time()
    ok = fail = 0

    async def one(j):
        async with sem:
            try:
                return j[0], await fn(teacher, *j)
            except Exception as e:
                print(f"[warn] {j[0]} 异常 {type(e).__name__}: {e}", file=sys.stderr)
                return j[0], None

    tasks = [asyncio.create_task(one(j)) for j in todo]
    for i, fut in enumerate(asyncio.as_completed(tasks), 1):
        rid, card = await fut
        if card is None:
            fail += 1
        else:
            ok += 1
            f.write(json.dumps({"id": rid, "card": card}, ensure_ascii=False) + "\n")
            f.flush()
        if i % 50 == 0 or i == len(tasks):
            el = time.time() - t0
            print(f"  {i}/{len(tasks)}  ok={ok} fail={fail}  {i/max(el,1e-9):.1f} 条/s  cache={teacher.hits}",
                  flush=True)
    f.close()
