# -*- coding: utf-8 -*-
"""v2 命令行：build 走 build_v2.py，其余转发给 run.py（沿用同一套校验流程）。

  python run_v2.py build --class 1 [--max-trees N] [--no-balance] [--target N]
  python run_v2.py gen|solve|assemble|verify|report --class 1
"""
import argparse
import subprocess
import sys

BASE = __file__.rsplit("\\", 1)[0]


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        return 1
    cmd = sys.argv[1]
    rest = sys.argv[2:]
    if cmd == "build":
        return subprocess.call([sys.executable, "build_v2.py", *rest])
    if cmd in ("gen", "solve", "assemble", "verify", "report", "all"):
        return subprocess.call([sys.executable, "run.py", cmd, *rest])
    print(f"未知子命令 {cmd}")
    return 2


if __name__ == "__main__":
    sys.exit(main())
