# -*- coding: utf-8 -*-
"""单树出题 worker：给一个树文件里的序号，生成这棵树的全部题目并写 jsonl。

单独进程运行，父进程可超时杀掉，避免个别慢树拖死整体。
用法: python gen_worker.py <tree_index> <out.jsonl>
"""
import json
import random
import sys

import config
import gen_items as G
from galileo import Tree


def read_jsonl(p):
    with open(p, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                yield json.loads(line)


def caps_for(cls, source):
    if cls == 2:
        return config.CAP_C2
    return config.CAP_SYNTH if source == "synth" else config.CAP_ANCHOR


def main():
    if len(sys.argv) < 3:
        return 1
    idx, out = int(sys.argv[1]), sys.argv[2]
    d = None
    for i, row in enumerate(read_jsonl(config.TREES)):
        if i == idx:
            d = row
            break
    if d is None:
        return 2

    t = Tree(top=d["top"], gates={k: (v[0], v[1]) for k, v in d["gates"].items()}, basics={})
    mcs = d.get("mcs") or t.mcs()
    if len(mcs) >= 2:
        known = {frozenset(m) for m in mcs}
        t.is_mcs = lambda s, _k=known: frozenset(s) in _k

    info = {"file": d["name"], "tree": t, "mcs": mcs, "leaves": d["leaves"],
            "platform": d["platform"], "domain": d["domain"], "source": d["source"]}
    cap = caps_for(d["class"], d["source"])
    rng = random.Random(hash(d["name"]) & 0xFFFF)

    items = []
    items += G.gen_mcs_choice(info, rng)[: cap["mcs"]]
    items += G.gen_action_choice(info, rng, k=cap["action"])
    items += G.gen_noul(info, rng, k=cap["noul"])
    items += G.gen_score(info, rng, k=cap["score"])

    with open(out, "w", encoding="utf-8") as f:
        for it in items:
            it["class"] = d["class"]
            it["tree_source"] = d["source"]
            it["tree_split"] = d.get("split", "")
            f.write(json.dumps(it, ensure_ascii=False) + "\n")
    print(f"{d['name']}\t{len(items)}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
