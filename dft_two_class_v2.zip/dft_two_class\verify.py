﻿# -*- coding: utf-8 -*-
"""算法复算：不看生成过程的中间结果，只用树结构重算每条题的标签。

  python verify.py --class 1            # 校验 items.jsonl
  python verify.py --class 1 --final    # 校验最终的 train/dev/benchmark
"""
import argparse
import json
import sys
from collections import Counter
from pathlib import Path

import config
from galileo import Tree

BASE = Path(__file__).resolve().parent


def read_jsonl(p):
    with open(p, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                yield json.loads(line)


def load_trees():
    out = {}
    for d in read_jsonl(config.TREES):
        t = Tree(top=d["top"], gates={k: (v[0], v[1]) for k, v in d["gates"].items()},
                 basics={})
        mcs = d.get("mcs") or t.mcs()
        if len(mcs) >= 2:
            known = {frozenset(m) for m in mcs}
            t.is_mcs = lambda s, _k=known: frozenset(s) in _k
        out[d["name"]] = (t, mcs)
    return out


def opt_set(txt):
    return set(x.strip() for x in txt.split("+") if x.strip())


def check_mcs(tree, mcs, it):
    gold = it["meta"]["gold"]
    if not tree.is_mcs(set(gold)):
        return "gold_not_mcs"
    gi = max(range(len(it["target"])), key=it["target"].__getitem__)
    if opt_set(it["options"][gi]) != set(gold):
        return "target_mismatch"
    for i, o in enumerate(it["options"]):
        if i != gi and tree.is_mcs(opt_set(o)):
            return "distractor_is_mcs"
    return "ok"


def check_action(tree, mcs, it):
    obs = set(it["meta"].get("observed_ok") or [])
    kf = it["meta"].get("known_fail")
    rem = [m for m in mcs if not (set(m) & obs) and (kf is None or kf in m)]
    if not rem:
        return "empty_rem"
    gi = max(range(len(it["target"])), key=it["target"].__getitem__)
    picked = it["options"][gi].replace("query_status(", "").rstrip(")")
    if picked != it["meta"]["gold"]:
        return "target_mismatch"
    gains = {}
    for e in tree.leaves() - obs - ({kf} if kf else set()):
        n_in = sum(1 for m in rem if e in m)
        gains[e] = min(n_in, len(rem) - n_in)
    best = max(gains.values()) if gains else 0
    if gains.get(picked) != best:
        return "gold_not_best"
    rivals = [gains.get(o.replace("query_status(", "").rstrip(")"))
              for i, o in enumerate(it["options"]) if i != gi]
    if any(r is not None and r >= best for r in rivals):
        return "not_unique"
    return "ok"


def check_noul(tree, mcs, it):
    if bool(tree.fails(set(it["meta"]["failed"]))) != bool(it["meta"]["label"]):
        return "label_mismatch"
    gi = max(range(len(it["target"])), key=it["target"].__getitem__)
    if it["options"][gi] != ("true" if it["meta"]["label"] else "false"):
        return "target_mismatch"
    return "ok"


def check_score(tree, mcs, it):
    obs = set(it["meta"].get("observed_ok") or [])
    rem = [m for m in mcs if not (set(m) & obs)]
    cleared = 1 - len(rem) / len(mcs)
    lvl = 0 if cleared <= 0 else 1 if cleared < .25 else 2 if cleared < .5 \
        else 3 if cleared < .75 else 4
    if lvl != it["meta"]["level"]:
        return "level_mismatch"
    gi = max(range(len(it["target"])), key=it["target"].__getitem__)
    if str(gi) != str(lvl):
        return "target_mismatch"
    return "ok"


def check_multi(tree, mcs, it):
    """多故障溯源：正确项必须是割集且与已确认正常集合不相交。"""
    gold = set(it["meta"]["gold"])
    obs = set(it["meta"].get("observed_ok") or [])
    if gold & obs:
        return "gold_conflicts_observed"
    if not tree.is_mcs(gold):
        return "gold_not_mcs"
    gi = max(range(len(it["target"])), key=it["target"].__getitem__)
    if opt_set(it["options"][gi]) != gold:
        return "target_mismatch"
    for i, o in enumerate(it["options"]):
        if i == gi:
            continue
        s = opt_set(o)
        if not (s & obs) and tree.is_mcs(s):
            return "distractor_also_valid"
    return "ok"


CHECK = {"mcs": check_mcs, "action": check_action,
         "noul": check_noul, "score": check_score, "multi": check_multi}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--class", dest="cls", type=int, required=True, choices=[1, 2])
    ap.add_argument("--final", action="store_true")
    args = ap.parse_args()

    trees = load_trees()
    d = config.OUT / f"class{args.cls}"
    if args.final:
        items = [x for s in ("train", "dev", "benchmark")
                 for x in read_jsonl(d / f"{s}.jsonl")]
    else:
        items = list(read_jsonl(d / "items.jsonl"))

    bad = Counter()
    for it in items:
        name = it["meta"]["tree"]
        if name not in trees:
            bad["no_tree"] += 1
            continue
        tree, mcs = trees[name]
        why = CHECK[it["meta"]["gen"]](tree, mcs, it)
        if why != "ok":
            bad[f"{it['meta']['gen']}:{why}"] += 1

    total = len(items)
    ok = total - sum(bad.values())
    print(f"[class{args.cls}] 复核 {ok}/{total} ({ok/max(total,1)*100:.2f}%)")
    if bad:
        for k, v in bad.most_common():
            print(f"  {k}: {v}")
        return 1
    print("全部通过 ✓")
    return 0


if __name__ == "__main__":
    sys.exit(main())
