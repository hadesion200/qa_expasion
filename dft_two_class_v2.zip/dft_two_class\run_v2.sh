#!/usr/bin/env bash
# dft_two_class v2 — 第二版（扩量、补缺口、与 v1 不重合）
set -euo pipefail
cd "$(dirname "$0")"

PY="${PY:-python3}"
export PYTHONIOENCODING=utf-8
export DFT_OUT="${DFT_OUT:-$PWD/out_v2}"
export SOLVE_ROUNDS="${SOLVE_ROUNDS:-1}"

case "${1:-help}" in
  help|-h|--help)
    cat <<'EOF'
用法: ./run_v2.sh <command> --class <1|2> [选项]

  check            自检（mock，不联网）
  build            出题 v2（含 multi 题型，排除 v1 重合；约 7s / 130s）
  gen              模型写场景（并发、逐条追加、可续跑）
  solve            模型独立解题（默认 1 轮）
  assemble         校验 + 出 train/dev/benchmark
  verify           算法复算
  all              依次 build→gen→solve→assemble→verify
  report           打印统计

build 额外参数:
  --max-trees N    只跑前 N 棵树（试水）
  --no-balance     不做 1:1:1 均衡（第二类冲量用）
  --target N       抽样到 N 条

环境变量:
  DFT_OUT=out_v2            v2 输出目录（与 v1 的 out/ 隔离）
  SOLVE_ROUNDS=1            v2 默认 1 轮解题
  NOUL_K / SCORE_K          每树 noul/score 条数（第二类冲量用 100）
  TEACHER_BASE_URL / TEACHER_MODEL / TEACHER_API_KEY / TEACHER_CONCURRENCY

推荐顺序:
  ./run_v2.sh build --class 1
  ./run_v2.sh gen --class 1 && ./run_v2.sh solve --class 1
  ./run_v2.sh assemble --class 1 && ./run_v2.sh verify --class 1
  NOUL_K=100 SCORE_K=100 ./run_v2.sh build --class 2 --no-balance --target 20000
  ./run_v2.sh gen --class 2 && ./run_v2.sh solve --class 2
  ./run_v2.sh assemble --class 2 && ./run_v2.sh verify --class 2
EOF
    ;;
  check) "$PY" selftest.py ;;
  build|gen|solve|assemble|verify|all|report) "$PY" run_v2.py "$@" ;;
  *) echo "未知命令: $1" >&2; exit 1 ;;
esac
