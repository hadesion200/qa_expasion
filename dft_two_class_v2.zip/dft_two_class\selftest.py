# -*- coding: utf-8 -*-
"""自检：build → gen(mock) → 回填"会做的模型" → solve(mock) → assemble → verify。

验证四点：
  1. 只换【场景】行，结构段/选项/题干/标签不变；
  2. 注入的错答、假锚点、两轮不一致都会被拦下；
  3. 同一棵树不跨 split；
  4. 算法复算 100% 通过。
"""
import json
import re
import shutil
import subprocess
import sys
from pathlib import Path

BASE = Path(__file__).resolve().parent
TREES = 2


def run(*args):
    r = subprocess.run([sys.executable, "run.py", *args], cwd=BASE,
                       capture_output=True, text=True, encoding="utf-8")
    if r.returncode != 0:
        print(r.stdout[-1200:])
        print(r.stderr[-1200:])
        raise SystemExit(f"失败: run.py {' '.join(args)}")
    return r.stdout


def logic_line(state):
    m = re.search(r"【故障逻辑】[^\n]*\n([^\n]+)", state)
    return m.group(1).strip() if m else ""


def main():
    import config
    import pipeline

    for p in (config.OUT, BASE / ".cache"):
        if p.exists():
            shutil.rmtree(p)

    run("build", "--class", "1", "--max-trees", str(TREES))
    run("gen", "--class", "1", "--mock")
    run("solve", "--class", "1", "--mock")

    items = {it["id"]: it for it in pipeline.load_items(1)}
    scen = {r["id"]: r["card"] for r in pipeline.read_jsonl(pipeline.cls_dir(1) / "scenario.jsonl")}
    valid = [(rid, items[rid]) for rid, c in scen.items()
             if pipeline.check_scenario(c["scenario"], items[rid]) == "ok"]
    print(f"[debug] 场景 {len(scen)}，通过确定性校验 {len(valid)}")
    assert len(valid) >= 4

    rows = []
    for k, (rid, it) in enumerate(valid):
        new_it = pipeline.apply_scenario(it, scen[rid]["scenario"])
        ans, anchor = pipeline.gold_answer(it), logic_line(new_it["state"])
        mode = {0: "wrong", 1: "bad_anchor", 2: "disagree"}.get(k)
        if mode == "wrong":
            ans = "Z"
        if mode == "bad_anchor":
            anchor = "99. 中间事件X = 部件Y 与 部件Z"
        for r in range(config.SOLVE_ROUNDS):
            a = anchor
            if mode == "disagree" and r == 1:
                lines = [x for x in new_it["state"].split("\n") if x[:2] in ("1.", "2.", "3.", "4.", "5.")]
                a = lines[-1] if lines else anchor
            rows.append({"id": f"{rid}#r{r + 1}",
                         "card": {"anchor": a, "answer": ans, "confident": True}})
    with open(pipeline.cls_dir(1) / "solve.jsonl", "w", encoding="utf-8") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")

    run("assemble", "--class", "1")
    rep = json.loads((pipeline.cls_dir(1) / "report.json").read_text(encoding="utf-8"))
    print(f"[ok] items {rep['items']} → kept {rep['kept']} {rep['by_split']}")
    print(f"[ok] 校验分布 {rep['checks']}")
    assert rep["kept"] > 0
    assert rep["checks"].get("round1:answer_mismatch", 0) >= 1
    assert rep["checks"].get("round1:anchor_not_in_state", 0) >= 1
    assert rep["checks"].get("anchor_disagree", 0) >= 1

    n = 0
    for s in ("train", "dev", "benchmark"):
        p = pipeline.cls_dir(1) / f"{s}.jsonl"
        if not p.exists():
            continue
        for line in p.open(encoding="utf-8"):
            it = json.loads(line)
            head, rest = pipeline.split_state(it["state"])
            assert head.startswith("【场景】")
            assert it["target"] and it["options"]
            n += 1
    print(f"[ok] {n} 条产出结构完整")

    out = run("verify", "--class", "1")
    assert "全部通过" in out, out[-500:]
    print("[ok] 算法复算通过")
    print("\n全部通过。")


if __name__ == "__main__":
    main()
