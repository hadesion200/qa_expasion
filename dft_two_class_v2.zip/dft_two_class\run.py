# -*- coding: utf-8 -*-
"""命令行入口。

  python run.py build   [--class 1|2] [--max-trees N]   出题（不调模型）
  python run.py gen     --class 1                       模型写场景
  python run.py solve   --class 1                       模型独立解题（2 轮）
  python run.py assemble --class 1                      三层校验 + 出数据集
  python run.py verify  --class 1 [--final]             算法复算标签
  python run.py report  --class 1
  python run.py all     --class 1                       依次跑完并校验
"""
import argparse
import asyncio
import subprocess
import sys

import config
import pipeline
import prompts
from llm import Teacher, run_batch


def gen_jobs(cls, limit=None):
    jobs = []
    for it in pipeline.load_items(cls):
        head, _ = pipeline.split_state(it["state"])
        text = prompts.SCENARIO.format(
            platform=it["meta"]["platform"], top=pipeline.top_of(it["state"]),
            leaves="、".join(pipeline.leaves_of(it["state"])),
            old=head.replace("【场景】", "").strip(),
            lo=config.MIN_LEN, hi=config.MAX_LEN)
        jobs.append((it["id"], text))
    return jobs[:limit] if limit else jobs


async def cmd_gen(args):
    jobs = gen_jobs(args.cls, args.limit)
    print(f"[class{args.cls}] 待生成场景 {len(jobs)} 条")
    async with Teacher(mock=args.mock) as t:
        await run_batch(t, jobs, pipeline.cls_dir(args.cls) / "scenario.jsonl",
                        lambda t, rid, text: t.ask("scenario", prompts.SYSTEM, text))


def solve_jobs(cls, limit=None):
    scen = {r["id"]: r["card"]
            for r in pipeline.read_jsonl(pipeline.cls_dir(cls) / "scenario.jsonl")}
    jobs = []
    for it in pipeline.load_items(cls):
        card = scen.get(it["id"])
        if not card:
            continue
        if pipeline.check_scenario(card.get("scenario"), it) != "ok":
            continue
        new_it = pipeline.apply_scenario(it, card["scenario"])
        if new_it["kind"] == "score":
            opts = "、".join(f"{i}={o}" for i, o in enumerate(new_it["options"]))
        else:
            opts = "\n".join(f"{chr(65 + i)}. {o}" for i, o in enumerate(new_it["options"]))
        text = prompts.SOLVE.format(state=new_it["state"], question=new_it["question"],
                                    options=opts)
        for r in range(config.SOLVE_ROUNDS):
            jobs.append((f"{it['id']}#r{r + 1}", text))
    return jobs[:limit] if limit else jobs


async def cmd_solve(args):
    jobs = solve_jobs(args.cls, args.limit)
    print(f"[class{args.cls}] 待解题 {len(jobs)} 条（{config.SOLVE_ROUNDS} 轮）")
    async with Teacher(mock=args.mock) as t:
        await run_batch(t, jobs, pipeline.cls_dir(args.cls) / "solve.jsonl",
                        lambda t, rid, text: t.ask("solve", prompts.SYSTEM, text))


def cmd_build(args):
    cmd = [sys.executable, "build.py", "--class", str(args.cls)]
    if args.max_trees:
        cmd += ["--max-trees", str(args.max_trees)]
    return subprocess.call(cmd)


def cmd_verify(args):
    cmd = [sys.executable, "verify.py", "--class", str(args.cls)]
    if args.final:
        cmd.append("--final")
    return subprocess.call(cmd)


def main():
    KNOWN = ("build", "gen", "solve", "assemble", "verify", "report", "all")
    if len(sys.argv) > 1 and sys.argv[1] not in KNOWN + ("-h", "--help"):
        print(f"[error] 未知子命令 {sys.argv[1]!r}，可选：{', '.join(KNOWN)}")
        return 2
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    for name in KNOWN:
        p = sub.add_parser(name)
        p.add_argument("--class", dest="cls", type=int, required=True, choices=[1, 2])
        p.add_argument("--limit", type=int, default=None)
        p.add_argument("--max-trees", type=int, default=0, dest="max_trees")
        p.add_argument("--final", action="store_true")
        p.add_argument("--mock", action="store_true")
    args = ap.parse_args()

    if args.cmd == "build":
        return cmd_build(args)
    if args.cmd == "gen":
        asyncio.run(cmd_gen(args))
        return 0
    if args.cmd == "solve":
        asyncio.run(cmd_solve(args))
        return 0
    if args.cmd == "assemble":
        return pipeline.assemble(args.cls)
    if args.cmd == "verify":
        return cmd_verify(args)
    if args.cmd == "report":
        p = pipeline.cls_dir(args.cls) / "report.json"
        print(p.read_text(encoding="utf-8") if p.exists() else "还没有 report.json")
        return 0
    # all
    rc = cmd_build(args)
    if rc:
        return rc
    asyncio.run(cmd_gen(args))
    asyncio.run(cmd_solve(args))
    rc = pipeline.assemble(args.cls)
    return rc or cmd_verify(args)


if __name__ == "__main__":
    sys.exit(main())
