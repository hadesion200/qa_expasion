# -*- coding: utf-8 -*-
"""从 Galileo 故障树/攻击树生成 JEV 样本（choice / noul / score），标签全部可计算。

四类题：
  A. 最小割集识别（choice）
  B. 下一步诊断动作（choice，工具调用形态，按信息增益选）
  C. 顶事件是否发生（noul，完整状态赋值 → 布尔求值）
  D. 诊断进度分级（score，按已排除的割集比例）

用法：
  python3 gen_items.py            # 全量
  python3 gen_items.py --space-only   # 只保留航天平台
"""
import argparse
import json
import random
import sys
from collections import Counter
from itertools import combinations
from pathlib import Path

from galileo import Tree, GATE_CN

BASE = Path(__file__).resolve().parent
OUT = BASE / "out"
FALLBACK = Path(r"C:\Users\18227\Desktop\中继数据\dftbench")
DATA = Path(__import__("os").environ.get("DFT_ROOT", str(FALLBACK)))
SEED = 20261104

PLATFORM = {
    "eps": ("某 CubeSat 电源分系统", "space", "电源分系统"),
    "hscom": ("某 CubeSat 高速通信分系统", "space", "通信分系统"),
    # 文件名前缀 -> (平台描述, 领域, 系统名)
    "mps": ("某卫星主推进系统", "space", "推进系统"),
    "csd": ("某航天器密封连接组件", "space", "密封组件"),
    "ahrs": ("某飞行器航姿参考系统", "space", "航姿系统"),
    "cubesat": ("某 CubeSat 攻击树", "attack", "攻击树"),
    "hecs": ("某机载发动机控制系统", "air", "发动机控制系统"),
    "mas": ("某模块化航电系统", "air", "航电系统"),
    "pt": ("某示例系统", "generic", "示例系统"),
}
PRIORITY = {"A": 3, "A-": 2, "B": 1}


def onehot(n, idx, smooth=0.02):
    rest = round(smooth / max(n - 1, 1), 4)
    t = [rest] * n
    t[idx] = round(1 - smooth, 4)
    s = sum(t)
    return [round(x / s, 4) for x in t]


def load_trees(space_only=False):
    out = []
    dirs = [DATA, Path(__file__).resolve().parent / "data" / "real"]
    files = [p for d in dirs if d.exists() for p in sorted(d.glob("*"))
             if p.suffix.lower() in (".dft", ".galileo")]
    for p in files:
        key = p.name.split(".")[0].lower().replace("_1_1", "").replace("-1", "")
        key = key.split("_")[0]
        plat = PLATFORM.get(key, ("某系统", "generic", "系统"))
        if space_only and plat[1] != "space":
            continue
        t = Tree(p)
        cn = plat[0] + "失效"
        if t.top in t.gates and t.top != cn:      # 顶事件名统一成本文可读的
            t = Tree(top=cn, gates={cn if k == t.top else k: v for k, v in t.gates.items()},
                     basics={})
        t = _decorate(t)                           # 给短符号加中性前缀
        out.append({"key": key, "file": p.name, "tree": t,
                    "platform": plat[0], "domain": plat[1], "name": plat[2],
                    "mcs": t.mcs(), "leaves": t.leaves()})
    return out


def _decorate(t, maxlen=12):
    """Emission：真实树里的短符号（A1、P1、power1、AFailure）读者看不出是什么类别，
    加中性前缀「部件」「中间事件」说明它是哪一类节点——**不猜它具体是什么**。
    长名字（PrimaryFailureOfIV3ToCloseAfterCutoff）本身可读，不动。
    """
    ren = {}
    for leaf in t.leaves():
        if len(leaf) <= maxlen:
            ren[leaf] = "部件" + leaf
    for g in t.gates:
        if g != t.top and len(g) <= maxlen and g not in ren:
            ren[g] = "中间事件" + g
    if not ren:
        return t
    gates = {ren.get(k, k): (v[0], [ren.get(c, c) for c in v[1]]) for k, v in t.gates.items()}
    return Tree(top=t.top, gates=gates, basics={})


# ---------------------------------------------------------------- 渲染
def render_structure(tree, mcs_hint=False):
    body = ("【判定规则】故障沿「与或」逻辑向上传播：或门＝任一输入发生则输出发生；"
            "与门＝全部输入同时发生才输出；冷备/温备＝主件失效后备用件再失效才算输出（按串联处理）。\n"
            "【故障逻辑】（自上而下读，等号左边由右边决定）\n" + tree.render())
    body += "\n【基本事件】" + "、".join(tree.basic_events())
    return body


def base_meta(info):
    return {"pool": "dft", "dataset": "galileo_dft", "domain": info["domain"],
            "tree": info["file"], "platform": info["platform"]}


def state_head(info, task):
    t = info["tree"]
    return (f"【场景】{info['platform']}共 {len(t.leaves())} 个部件，各部件失效相互独立；"
            f"系统当前的顶事件是「{t.top}」。{task}")


# ---------------------------------------------------------------- A. 最小割集
def gen_mcs_choice(info, rng):
    tree, mcs, leaves = info["tree"], info["mcs"], info["leaves"]
    items = []
    for m in mcs:
        cands = []
        # 1) 超集：真割集 + 一个无关事件（不满足"去掉任一个都不成立"）
        extra = [x for x in leaves if x not in m]
        if extra:
            cands.append(tuple(sorted(set(m) | {rng.choice(extra)})))
        # 2) 换一个：去掉一个再补一个
        if len(m) >= 2:
            for _ in range(12):
                x = rng.choice(list(m))
                y = rng.choice([z for z in leaves if z not in m])
                cands.append(tuple(sorted((set(m) - {x}) | {y})))
        # 3) 跨割集混搭：两个不同割集各取一个
        for _ in range(20):
            a, b = rng.sample(mcs, 2) if len(mcs) >= 2 else (m, m)
            s = tuple(sorted({rng.choice(list(a)), rng.choice(list(b))}))
            cands.append(s)
        # 4) 随机小集合
        for _ in range(10):
            k = max(1, len(m))
            cands.append(tuple(sorted(rng.sample(sorted(leaves), min(k, len(leaves))))))

        opts, seen = [], set()
        for c in cands:
            if not c or c in seen:
                continue
            if tree.is_mcs(c):
                continue
            seen.add(c)
            opts.append(c)
            if len(opts) == 3:
                break
        if len(opts) < 3:
            continue

        all_opts = [tuple(sorted(m))] + opts
        order = list(range(4))
        rng.shuffle(order)
        shuffled = [all_opts[i] for i in order]
        gold = order.index(0)
        if not (sum(1 for s in shuffled if tree.is_mcs(s)) == 1):
            continue

        st = (state_head(info, "顶事件已发生，需要定位导致失效的最小组合。") + "\n"
              + render_structure(tree) + "\n"
              + f"【顶事件】{tree.top}")
        q = ("下列哪一组基本事件同时失效会导致顶事件发生，且去掉其中任意一个都不会导致顶事件"
             "（即最小割集）？")
        it = {"kind": "choice", "state": st, "question": q,
              "options": [" + ".join(s) for s in shuffled], "target": onehot(4, gold),
              "grade": "A", "meta": {**base_meta(info), "gen": "mcs",
                                     "gold": sorted(m), "n_mcs": len(mcs)}}
        items.append(it)
    return items


# ---------------------------------------------------------------- B. 诊断动作
def remaining_mcs(tree, mcs, observed_ok):
    return [m for m in mcs if not (set(m) & observed_ok)]


def gen_action_choice(info, rng, k=3):
    tree, mcs, leaves = info["tree"], info["mcs"], info["leaves"]
    if len(mcs) < 2 or len(leaves) < 5:
        return []
    items = []
    pool = sorted(leaves)
    for _ in range(k * 25):
        if len(items) >= k:
            break
        # 观测：0~2 个已确认正常 + 可选 1 个已确认失效（失效会把范围收得很紧，出题更多样）
        obs_ok = set(rng.sample(pool, rng.randint(0, min(2, len(pool) - 3))))
        known_fail = rng.choice([e for e in pool if e not in obs_ok]) if rng.random() < 0.75 else None
        rem = [m for m in mcs
               if not (set(m) & obs_ok) and (known_fail is None or known_fail in m)]
        if len(rem) < 3:
            continue
        cands = [e for e in pool if e not in obs_ok and e != known_fail]
        if len(cands) < 4:
            continue
        gains = {}
        for e in cands:
            n_in = sum(1 for m in rem if e in m)
            n_not = len(rem) - n_in
            # 主键：最坏情况下能保证排除的路径数；次键：越均衡越好
            gains[e] = (min(n_in, n_not), -abs(n_in - n_not), n_in)
        best = max(gains.values())
        if best[0] <= 0:
            continue
        winners = [e for e, g in gains.items() if g == best]
        # 允许并列：只要 4 个选项里只有一个是最大值即可（其余并列者不进选项）
        gold = rng.choice(winners)
        distract = [e for e, g in gains.items() if g[0] < best[0]]
        if len(distract) < 3:
            continue
        opts = [gold] + rng.sample(distract, 3)
        rng.shuffle(opts)
        obs_txt = []
        if known_fail:
            obs_txt.append(f"{known_fail} 已确认失效")
        obs_txt += [f"{e} 已确认正常" for e in sorted(obs_ok)]
        st = (state_head(info, "顶事件已发生，正在按顺序定位失效部件。") + "\n"
              + render_structure(tree) + "\n"
              + f"【顶事件】{tree.top}\n"
              + "【已确认】" + ("；".join(obs_txt) if obs_txt else "（尚无）"))
        q = ("当前可调用动作只有「查询某部件的状态」。下列哪个查询**无论结果如何**都能排除最多条"
             "仍可能的失效路径（最坏情况最优）？")
        it = {"kind": "choice", "state": st, "question": q,
              "options": [f"query_status({e})" for e in opts],
              "target": onehot(4, opts.index(gold)),
              "grade": "A", "meta": {**base_meta(info), "gen": "action",
                                     "gold": gold, "observed_ok": sorted(obs_ok),
                                     "known_fail": known_fail,
                                     "guarantee": best[0], "remaining_before": len(rem)}}
        items.append(it)
    return items


# ---------------------------------------------------------------- C. noul
def gen_noul(info, rng, k=4):
    tree, leaves = info["tree"], info["leaves"]
    pool = sorted(leaves)
    items, tried = [], 0
    while len(items) < k and tried < 400:
        tried += 1
        # 一半用"真实割集 + 少量噪声"造正例，一半随机造（多为反例），保证正负均衡
        if info["mcs"] and rng.random() < 0.5:
            base = set(rng.choice(info["mcs"]))
            rest = [e for e in pool if e not in base]
            extra = set(rng.sample(rest, rng.randint(0, min(2, len(rest))))) if rest else set()
            failed = base | extra
        else:
            n = rng.randint(1, min(4, len(pool)))
            failed = set(rng.sample(pool, n))
        label = tree.fails(failed)
        # 只保留"看起来不像显然"的样本：失效事件数 1~4，且结果有正有负
        st = (state_head(info, "已获得全部部件的状态，需要判断顶事件是否已经发生。") + "\n"
              + render_structure(tree) + "\n"
              + f"【顶事件】{tree.top}\n"
              + "【部件状态】" + "；".join(
                  f"{e}：{'失效' if e in failed else '正常'}" for e in pool) + "\n"
              + f"【待审结论】顶事件 {tree.top} 已发生。")
        q = "上述结论是否正确？只依据给定的部件状态与结构逻辑判断。"
        it = {"kind": "noul", "state": st, "question": q,
              "options": ["false", "true"],
              "target": [0.02, 0.98] if label else [0.98, 0.02],
              "grade": "A-", "meta": {**base_meta(info), "gen": "noul",
                                      "failed": sorted(failed), "label": label}}
        items.append(it)
    return items


# ---------------------------------------------------------------- D. score
SCORE_Q = (
    "按「当前证据已排除多少条失效路径」分级（0–4，0 起始索引）：\n"
    "0：一条都没排除；\n"
    "1：排除了不到 25%；\n"
    "2：排除了 25%–50%；\n"
    "3：排除了 50%–75%；\n"
    "4：排除了 75% 以上（或全部排除）。"
)


def gen_score(info, rng, k=4):
    tree, mcs, leaves = info["tree"], info["mcs"], info["leaves"]
    if len(mcs) < 2:
        return []
    pool = sorted(leaves)
    items, used = [], set()
    while len(items) < k and len(used) < 40:
        size = rng.randint(0, min(4, len(pool) - 1))
        obs = tuple(sorted(rng.sample(pool, size)))
        if (size, obs) in used:
            continue
        used.add((size, obs))
        rem = remaining_mcs(tree, mcs, set(obs))
        cleared = 1 - len(rem) / len(mcs)
        level = 0 if cleared <= 0 else 1 if cleared < 0.25 else 2 if cleared < 0.5 \
            else 3 if cleared < 0.75 else 4
        st = (state_head(info, "评估当前证据对故障路径的排除程度。") + "\n"
              + render_structure(tree) + "\n"
              + f"【顶事件】{tree.top}\n"
              + "【已确认正常】" + ("、".join(obs) if obs else "（无）"))
        it = {"kind": "score", "state": st, "question": SCORE_Q,
              "options": ["0", "1", "2", "3", "4"], "target": onehot(5, level),
              "grade": "A-", "meta": {**base_meta(info), "gen": "score",
                                      "observed_ok": list(obs), "level": level,
                                      "remaining": len(rem), "total_mcs": len(mcs)}}
        items.append(it)
    return items


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--space-only", action="store_true")
    args = ap.parse_args()
    if not DATA.exists():
        print(f"[error] 找不到 {DATA}，设置 DFT_ROOT")
        return 1

    rng = random.Random(SEED)
    infos = load_trees(args.space_only)
    print(f"载入 {len(infos)} 棵树：")
    for i in infos:
        print(f"  {i['file']:18s} 门{len(i['tree'].gates):3d} 叶子{len(i['leaves']):3d} MCS{len(i['mcs']):3d}  {i['platform']}")

    items = []
    for info in infos:
        a = gen_mcs_choice(info, rng)
        b = gen_action_choice(info, rng)
        c = gen_noul(info, rng)
        d = gen_score(info, rng)
        print(f"  {info['file']:18s} MCS题{len(a):3d} 动作题{len(b):2d} noul{len(c):2d} score{len(d):2d}")
        items += a + b + c + d

    OUT.mkdir(parents=True, exist_ok=True)
    with open(OUT / "items.jsonl", "w", encoding="utf-8") as f:
        for it in items:
            f.write(json.dumps(it, ensure_ascii=False) + "\n")

    print(f"\n合计 {len(items)} 条：{dict(Counter(i['kind'] for i in items))}")
    print(f"生成器：{dict(Counter(i['meta']['gen'] for i in items))}")
    print(f"领域：{dict(Counter(i['meta']['domain'] for i in items))}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
