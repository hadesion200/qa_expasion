#!/usr/bin/env bash
# dft_two_class — 双类故障树数据集（航天/航空 + 通用工业）
set -euo pipefail
cd "$(dirname "$0")"

PY="${PY:-python3}"
export PYTHONIOENCODING=utf-8

usage() {
  cat <<'EOF'
用法: ./run.sh <command> --class <1|2> [选项]

  check            自检（mock，不联网）
  build            出题（不调模型，子进程隔离+超时，约 5 秒/类）
  gen              模型写【场景】（并发，逐条追加，可续跑）
  solve            模型独立解题（2 轮，可续跑）
  assemble         三层校验 + 出 train/dev/benchmark
  verify [--final] 算法复算标签
  all              依次 build→gen→solve→assemble→verify
  report           打印统计

  --class 1        太空 + 航空
  --class 2        通用工业
  --limit N        只跑前 N 条（试水）
  --max-trees N    只用前 N 棵树（build 调试）

环境变量:
  TEACHER_BASE_URL / TEACHER_MODEL / TEACHER_API_KEY
  TEACHER_CONCURRENCY   并发数（默认 16）
  DFT_OUT               输出目录（默认 ./out）

建议顺序（先航天、后通用）:
  ./run.sh check
  ./run.sh all --class 1
  ./run.sh all --class 2
EOF
}

case "${1:-help}" in
  help|-h|--help) usage ;;
  check)  "$PY" selftest.py ;;
  build|gen|solve|assemble|verify|all|report)
    "$PY" run.py "$@" ;;
  *) echo "未知命令: $1" >&2; usage; exit 1 ;;
esac
