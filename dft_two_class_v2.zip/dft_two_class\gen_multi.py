# -*- coding: utf-8 -*-
"""新增题型：多故障同时溯源（choice）。

场景：顶事件已发生，且已确认若干部件「正常」。
问：哪一组部件同时失效可以解释该顶事件（且不与已确认的正常状态矛盾）。

标签判定（可算法复核）：
  正确选项 = 一组最小割集，且与已确认正常集合不相交；
  干扰项 = 该割集去掉一个（不充分）/ 混入一个已确认正常的部件（矛盾）/ 另一割集去掉一个。
"""
import random


def gen_multi(info, rng, k=20):
    tree, mcs, leaves = info["tree"], info["mcs"], info["leaves"]
    if len(mcs) < 2 or len(leaves) < 6:
        return []
    items, tried = [], 0
    pool = sorted(leaves)
    while len(items) < k and tried < k * 30:
        tried += 1
        obs_ok = set(rng.sample(pool, rng.randint(1, min(2, len(pool) - 3))))
        cands = [m for m in mcs if len(m) >= 2 and not (set(m) & obs_ok)]
        if len(cands) < 2:
            continue
        gold = set(rng.choice(cands))
        others = [m for m in cands if set(m) != gold]
        if not others:
            continue

        distract = []
        # a) 去掉一个 → 不充分
        g = sorted(gold)
        distract.append(set(g[:-1]))
        # b) 混入一个已确认正常的部件 → 与观测矛盾
        distract.append(set(g) | {rng.choice(sorted(obs_ok))})
        # c) 另一割集去掉一个 → 不充分
        m2 = sorted(rng.choice(others))
        if len(m2) >= 2:
            distract.append(set(m2[:-1]))
        distract = [d for d in distract if d and d != gold]

        opts, seen = [tuple(sorted(gold))], {tuple(sorted(gold))}
        for d in distract:
            t = tuple(sorted(d))
            if t in seen:
                continue
            seen.add(t)
            opts.append(t)
        if len(opts) < 4:
            for m in mcs:
                t = tuple(sorted(set(m) | {rng.choice(sorted(obs_ok))}))
                if t not in seen and len(t) > len(gold):
                    seen.add(t)
                    opts.append(t)
                if len(opts) >= 4:
                    break
        if len(opts) < 4:
            continue

        order = opts[:4]
        rng.shuffle(order)
        gi = order.index(tuple(sorted(gold)))

        state = (f"【场景】{info['platform']}在生产运行中出现顶事件「{tree.top}」。"
                 f"现场已确认 " + "、".join(sorted(obs_ok)) + " 工作正常。\n"
                 + "【判定规则】故障沿「与或」逻辑向上传播：或门＝任一输入发生则输出发生；"
                   "与门＝全部输入同时发生才输出；冷备/温备＝主件失效后备用件再失效才算输出。\n"
                 + "【故障逻辑】（自上而下读，等号左边由右边决定）\n" + tree.render() + "\n"
                 + "【基本事件】" + "、".join(tree.basic_events()) + "\n"
                 + f"【顶事件】{tree.top}\n"
                 + "【已确认】" + "、".join(sorted(obs_ok)) + " 工作正常")

        items.append({
            "kind": "choice",
            "state": state,
            "question": "下列哪一组部件同时失效可以解释该顶事件，且不与已确认的正常状态矛盾？",
            "options": [" + ".join(o) for o in order],
            "target": [0.02 / 3] * 4,
            "grade": "A",
            "meta": {"pool": "dft", "dataset": "galileo_dft", "domain": info["domain"],
                     "tree": info["file"], "platform": info["platform"], "gen": "multi",
                     "gold": sorted(gold), "observed_ok": sorted(obs_ok)},
        })
        items[-1]["target"][gi] = 0.98
    return items
