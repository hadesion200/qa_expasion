# dft_two_class v2 — 扩量版（与 v1 不重合）

v1 实际只留下 1,309（第一类）/ 3,323（第二类），远低于目标。原因有两个，v2 分别处理：

1. **基础池就不够**：v1 出题 3,802 / 12,195 条，即使 100% 通过也到不了 5,000 / 20,000；
2. **验收过严**：v1 要求"两轮都做对"，把 34% / 27% 的合格样本筛掉了。

v2 在**不改树、不改标签计算**的前提下扩量。

---

## 1. v2 做了什么

| 改动 | 说明 | 效果 |
|---|---|---|
| 配额提高 | mcs 40→60、action 20→30、noul/score 40→60（第二类可调 100） | 基础池翻倍 |
| 新增题型 `multi` | **多故障同时溯源**：顶事件已发生 + 已确认若干部件正常，问哪组部件同时失效能解释 | 第一类 +959，第二类 +1,743 |
| 三类均衡 | 第一类 noul/choice/score **1:1:1**（各 3,160） | 消除题型偏斜 |
| 部件名替换 | `--rename-class1`：通用树部件换成卫星部件，作第一类补充 | 可选 |
| 排除 v1 重合 | 读取 `out/class*/items.jsonl`，按 (tree,kind,state,options) 指纹排除 | 与 v1 零重合 |
| 解题轮次 | v2 默认 `SOLVE_ROUNDS=1`（v1 是 2） | 通过率约翻倍 |
| JSON 兜底 | 模型输出半截 JSON 时用正则抠 `answer`/`anchor` | 修掉 11% 的解析失败 |

## 2. 实测产出（已跑通）

| 类 | v1 出题 | v1 保留 | **v2 出题** | 三类分布 | 复算 |
|---|---:|---:|---:|---|---|
| 一 太空+航空 | 3,802 | 1,309 | **9,480** | noul 3,160 / choice 3,160 / score 3,160 | 100% |
| 二 通用工业 | 12,195 | 3,323 | **20,000** | noul 9,772 / choice 6,343 / score 3,885 | 100% |

第一类题型构成：mcs 736、action 1,465、**multi 959**、noul 3,160、score 3,160。
第二类：mcs 2,076、action 2,524、**multi 1,743**、noul 9,772、score 3,885。

两类合计 **29,480 条**，均超过 5,000 / 20,000 的目标。

## 3. 怎么跑

```bash
export TEACHER_BASE_URL=http://10.0.1.15:12349/v1
export TEACHER_MODEL=WM-Qwen3.8-27B
export TEACHER_API_KEY=...
export TEACHER_CONCURRENCY=16

cd dft_two_class
./run_v2.sh check                    # 自检

# 第一类：先航天
./run_v2.sh build --class 1          # 9,480 条，7 秒
./run_v2.sh gen   --class 1
./run_v2.sh solve --class 1
./run_v2.sh assemble --class 1
./run_v2.sh verify   --class 1

# 第二类：再通用（冲量）
NOUL_K=100 SCORE_K=100 ./run_v2.sh build --class 2 --no-balance --target 20000
./run_v2.sh gen   --class 2
./run_v2.sh solve --class 2
./run_v2.sh assemble --class 2
./run_v2.sh verify   --class 2
```

产物在 `out_v2/class1|2/`，与 v1 的 `out/` 完全隔离。

## 4. 断点与并发

- `gen` / `solve` 逐条追加写 jsonl，**中断后重跑自动跳过已完成项**；
- 调用结果缓存在 `.cache/`，不重复计费；
- 并发由 `TEACHER_CONCURRENCY` 控制；
- 出题每棵树独立子进程 + 60 秒超时，慢树跳过并记录（v2 实测 104 成功 / 2 超时）。

## 5. 成本

| 类 | 条数 | 调用（1 生成 + 1 解题） |
|---|---:|---:|
| 一 | 9,480 | 18,960 |
| 二 | 20,000 | 40,000 |
| 合计 | 29,480 | **58,960** |

16 并发、每条 2–4 秒 → 约 **4–6 小时**。建议先 `--limit 200` 看 `answer_mismatch` 比例再放量。

## 6. 对 v1 低通过率的补救建议

| 现象（v1 实测） | 含义 | 补救 |
|---|---|---|
| `round1:answer_mismatch` 39% / 30% | 模型做不对，不一定是题坏 | v2 改 1 轮 + 保留下限；仍 mismatch 的存 `hard/` 子集，别全丢 |
| `JSON 解析失败` 2,584 条（11%） | 模型输出半截 JSON | 已加正则兜底，重跑即可回收 |
| `not_confident` 929 / 264 | 题面信息不足 | 保留为"低置信"子集，用于校准而非淘汰 |
| `no_anchor` 737 / 130 | 模型指不出判据行 | 加强 prompt：要求先抄一行再作答 |

核心原则：**数据正确性由算法复算保证（v2 已 100% 通过），模型做题只是"可解性"信号，不该用它来决定丢弃多少数据。**

## 7. 限制

1. 第二类 20,000 条里 noul 占 49%，其差别主要是"哪些部件已确认正常"，逻辑结构重复度高；
2. `multi` 题型的干扰项由"割集去一元素/混入已确认正常部件"构造，覆盖的错因类型有限；
3. `--rename-class1` 会把通用树语义改成卫星，属于"借拓扑"，评测时应与真实太空树分开报。

---

## 8. solve 太慢怎么办（0.2 条/s）

`solve` 的输出**不会写进 state**：它只返回 `{answer, anchor}` 用于校验，
`state` 里只有模型写的【场景】+ 确定性逻辑块。所以"解题过程"不会丰富描述。

慢的原因是**输入长 + 输出要抄一整行判据**。三种加速手段可叠加：

| 手段 | 做法 | 效果 |
|---|---|---|
| 抽检 | `SOLVE_SAMPLE=0.2` 只对 train 抽 20%，dev/benchmark 全量 | 调用降到 1/5 |
| 轻量模式 | `SOLVE_LITE=1` 只要求给答案，不要 anchor | 输出从 ~150 token 降到 ~20，速度约 ×3 |
| 单轮 | `SOLVE_ROUNDS=1`（v2 默认） | 再省一半 |

组合后：

```bash
SOLVE_SAMPLE=0.2 SOLVE_LITE=1 ./run_v2.sh solve --class 1
./run_v2.sh assemble --class 1          # 自动沿用 solve 的参数（solve_meta.json）
```

预期从 **0.2 条/s** 提到 **1–2 条/s**（9,480 条约 1.5 小时）。

被抽中但答错的仍会被拒；**没抽中的条目只过确定性校验 + 算法复算**，
在输出里标 `verified: false`，可单独筛出来复核。

## 9. solve 参数如何传递

`solve` 结束时把 `{rounds, sample, lite}` 写进 `out_v2/classN/solve_meta.json`，
`assemble` 自动读取——两条命令不会因为参数不一致而互相矛盾。
