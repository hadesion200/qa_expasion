﻿# -*- coding: utf-8 -*-
"""场景改写 + 校验 + 组装（按类）。

流程（每类独立）：
  build   → out/classN/items.jsonl
  gen     → out/classN/scenario.jsonl   （并发调用模型，逐条追加，可续跑）
  solve   → out/classN/solve.jsonl      （模型独立解题，2 轮，可续跑）
  assemble→ out/classN/{train,dev,benchmark}.jsonl + report.json

模型只重写 state 第一行【场景】，判定规则/故障逻辑/基本事件/选项/target 全部原样保留。
校验三层：
  ① 确定性：长度、无标记、不新增数字、沾到本系统、不泄答案、不是复制原文
  ② 独立解题 ×2：答案 == 标签，判据行逐字出现在 state 里，两轮一致
  ③ 算法复算：verify.py 用树重算标签
"""
import json
import re
from collections import Counter

import config

NUM = re.compile(r"\d+(?:\.\d+)?")


def read_jsonl(p):
    with open(p, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                yield json.loads(line)


def norm(s):
    return re.sub(r"[\s，。、；：？！“”‘’（）()\[\]【】《》·…—\-_,.;:?!'\"<>/\\|]+", "", s or "")


def cls_dir(cls):
    return config.OUT / f"class{cls}"


def load_items(cls):
    p = cls_dir(cls) / "items.jsonl"
    return list(read_jsonl(p)) if p.exists() else []


def split_state(state):
    i = state.find("\n")
    return (state, "") if i < 0 else (state[:i], state[i:])


def leaves_of(state):
    m = re.search(r"【基本事件】(.+)", state)
    return [x for x in re.split(r"[、，,]", m.group(1)) if x.strip()] if m else []


def top_of(state):
    m = re.search(r"【顶事件】(.+)", state)
    return m.group(1).strip() if m else ""


def gold_answer(it):
    gi = max(range(len(it["target"])), key=it["target"].__getitem__)
    if it["kind"] == "noul":
        return "true" if gi == 1 else "false"
    if it["kind"] == "choice":
        return "ABCD"[gi]
    return str(gi)


def check_scenario(s, it):
    s = (s or "").strip()
    if not s:
        return "empty"
    if len(s) < config.MIN_LEN:
        return "len_short"
    if len(s) > config.MAX_LEN:
        return "len_long"
    if "【" in s or "】" in s or "```" in s:
        return "markup"
    if set(NUM.findall(s)) - set(NUM.findall(it["state"])):
        return "new_numbers"
    lv, plat = leaves_of(it["state"]), it["meta"]["platform"]
    if lv and not any(x in s for x in lv) and plat not in s:
        return "off_topic"
    if s in it["state"]:
        return "copy_paste"
    if it["kind"] == "choice":
        gi = max(range(len(it["target"])), key=it["target"].__getitem__)
        g = re.sub(r"\s", "", it["options"][gi])
        if g and g in re.sub(r"\s", "", s):
            return "answer_leak"
    return "ok"


def _canon(it, ans):
    a = str(ans).strip().lower()
    if it["kind"] == "noul":
        if a in ("true", "是", "对", "1", "b"):
            return "true"
        if a in ("false", "否", "错", "0", "a"):
            return "false"
    elif it["kind"] == "choice":
        if re.fullmatch(r"[a-d]", a):
            return a.upper()
        for i, o in enumerate(it["options"]):
            if a == str(o).strip().lower():
                return "ABCD"[i]
    elif it["kind"] == "score":
        m = re.search(r"\d", a)
        if m:
            return m.group(0)
    return a


def check_solve(card, it):
    if not card:
        return "no_card"
    lite = getattr(config, "SOLVE_LITE", False)
    if not lite:
        anchor = (card.get("anchor") or "").strip()
        if len(anchor) < 8:
            return "no_anchor"
        if norm(anchor) not in norm(it["state"]):
            return "anchor_not_in_state"
        if not card.get("confident", True):
            return "not_confident"
    if _canon(it, card.get("answer")) != gold_answer(it):
        return "answer_mismatch"
    return "ok"


def apply_scenario(it, scenario):
    _h, rest = split_state(it["state"])
    new = dict(it)
    new["state"] = "【场景】" + scenario.strip() + rest
    new["llm_scenario"] = True
    return new


def assemble(cls):
    # 沿用 solve 阶段记录的参数（轮数/抽检/轻量）
    mp = cls_dir(cls) / "solve_meta.json"
    if mp.exists():
        m = json.loads(mp.read_text(encoding="utf-8"))
        config.SOLVE_ROUNDS = m.get("rounds", config.SOLVE_ROUNDS)
        config.SOLVE_SAMPLE = m.get("sample", 1.0)
        config.SOLVE_LITE = m.get("lite", False)
    items = load_items(cls)
    if not items:
        print(f"[class{cls}] 没有 items.jsonl，先跑 build")
        return 1
    scen = {r["id"]: r["card"] for r in read_jsonl(cls_dir(cls) / "scenario.jsonl")} \
        if (cls_dir(cls) / "scenario.jsonl").exists() else {}
    sols = {}
    p = cls_dir(cls) / "solve.jsonl"
    if p.exists():
        for r in read_jsonl(p):
            sols.setdefault(r["id"].split("#")[0], []).append(r["card"])

    reasons, kept, rejected = Counter(), [], []
    allow_unsolved = getattr(config, "SOLVE_SAMPLE", 1.0) < 1.0
    for it in items:
        rid = it["id"]
        card = scen.get(rid)
        if not card:
            reasons["no_scenario"] += 1
            continue
        why = check_scenario(card.get("scenario"), it)
        verified = False
        if why == "ok":
            rounds = sols.get(rid, [])
            if not rounds and allow_unsolved:
                why = "ok"                 # 抽检模式：没抽到的题只过确定性校验
            elif len(rounds) < config.SOLVE_ROUNDS:
                why = f"less_rounds:{len(rounds)}"
            else:
                answers = []
                for k, r in enumerate(rounds[: config.SOLVE_ROUNDS]):
                    w = check_solve(r, it)
                    if w != "ok":
                        why = f"round{k + 1}:{w}"
                        break
                    answers.append(norm(r.get("anchor", "")))
                else:
                    if len(set(answers)) > 1:
                        why = "anchor_disagree"
                    else:
                        verified = True
        reasons[why] += 1
        if why == "ok":
            new_it = apply_scenario(it, card["scenario"])
            new_it["verified"] = verified
            kept.append(new_it)
        else:
            rejected.append({"id": rid, "why": why, "tree": it["meta"]["platform"]})

    print(f"[class{cls}] 校验:", dict(reasons))
    outs = {"train": [], "dev": [], "benchmark": []}
    for it in kept:
        outs[it.get("split", "train")].append(it)
    d = cls_dir(cls)
    d.mkdir(parents=True, exist_ok=True)
    for s, rows in outs.items():
        with open(d / f"{s}.jsonl", "w", encoding="utf-8") as f:
            for it in rows:
                it["dataset"] = f"dft_two_class_c{cls}"
                f.write(json.dumps(it, ensure_ascii=False) + "\n")
    with open(d / "rejected.jsonl", "w", encoding="utf-8") as f:
        for r in rejected:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
    rep = {"class": cls, "items": len(items), "kept": len(kept),
           "by_split": {s: len(v) for s, v in outs.items()},
           "by_kind": dict(Counter(x["kind"] for x in kept)),
           "by_domain": dict(Counter(x["meta"]["domain"] for x in kept)),
           "checks": dict(reasons)}
    (d / "report.json").write_text(json.dumps(rep, ensure_ascii=False, indent=2),
                                   encoding="utf-8")
    print(json.dumps({k: rep[k] for k in ("class", "items", "kept", "by_split")},
                     ensure_ascii=False))
    return 0
