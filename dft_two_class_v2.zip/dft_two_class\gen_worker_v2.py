﻿# -*- coding: utf-8 -*-
"""v2 单树 worker：出 v2 全部题型（含 multi），可选改名成卫星部件。

用法: python gen_worker_v2.py <tree_index> <out.jsonl> [--rename]
"""
import json
import random
import sys
from pathlib import Path

import config
import gen_items as G
from galileo import Tree
from gen_multi import gen_multi

import os
CAP = {"mcs": 60, "action": 30,
       "noul": int(os.environ.get("NOUL_K", "60")),
       "score": int(os.environ.get("SCORE_K", "60")),
       "multi": int(os.environ.get("MULTI_K", "20"))}
SAT_POOL = [["太阳翼", "蓄电池", "放电调节器", "母线", "配电单元"],
            ["陀螺", "星敏感器", "反作用飞轮", "推力器", "加速度计"],
            ["应答机", "天线", "低噪放", "功放", "基带"],
            ["热管", "加热器", "辐射器", "泵", "阀门"]]


def read_jsonl(p):
    with open(p, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                yield json.loads(line)


def rename_tree(tree, rng):
    ren = {}
    for i, leaf in enumerate(sorted(tree.leaves())):
        pool = SAT_POOL[i % len(SAT_POOL)]
        ren[leaf] = f"{pool[i % len(pool)]}{i + 1}"
    gates = {}
    for k, (kind, kids) in tree.gates.items():
        gates[ren.get(k, k)] = (kind, [ren.get(c, c) for c in kids])
    top = "卫星分系统失效" if tree.top in gates else tree.top
    if tree.top in gates:
        gates[top] = gates.pop(tree.top)
    return Tree(top=top, gates=gates, basics={})


def main():
    if len(sys.argv) < 3:
        return 1
    idx, out = int(sys.argv[1]), sys.argv[2]
    rename = "--rename" in sys.argv[4:] or "--rename" in sys.argv

    d = None
    for i, row in enumerate(read_jsonl(config.TREES)):
        if i == idx:
            d = row
            break
    if d is None:
        return 2

    t = Tree(top=d["top"], gates={k: (v[0], v[1]) for k, v in d["gates"].items()}, basics={})
    mcs = d.get("mcs") or t.mcs()
    platform, domain = d["platform"], d["domain"]

    if rename:
        t = rename_tree(t, None)
        mcs = None
        platform = "某卫星分系统"
        domain = "space"

    if mcs is None:
        mcs = t.mcs()
    if len(mcs) >= 2:
        known = {frozenset(m) for m in mcs}
        t.is_mcs = lambda s, _k=known: frozenset(s) in _k

    info = {"file": d["name"] + ("__sat" if rename else ""), "tree": t, "mcs": mcs,
            "leaves": t.leaves(), "platform": platform, "domain": domain,
            "source": "borrowed" if rename else d["source"]}

    rng = random.Random(abs(hash(d["name"] + ("sat" if rename else ""))) % 100000)
    items = []
    items += G.gen_mcs_choice(info, rng)[: CAP["mcs"]]
    items += G.gen_action_choice(info, rng, k=CAP["action"])
    items += G.gen_noul(info, rng, k=CAP["noul"])
    items += G.gen_score(info, rng, k=CAP["score"])
    items += gen_multi(info, rng, k=CAP["multi"])

    with open(out, "w", encoding="utf-8") as f:
        for it in items:
            it["tree_source"] = info["source"]
            f.write(json.dumps(it, ensure_ascii=False) + "\n")
    print(f"{info['file']}\t{len(items)}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
