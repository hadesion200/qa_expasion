﻿# -*- coding: utf-8 -*-
"""v2 出题：在 v1 基础上扩量，且与 v1 不重合。

与 v1 的差别：
  1. 配额提高：mcs 60 / action 30 / noul 60 / score 60（v1 是 40/20/40/40）
  2. 新增题型 `multi`（多故障同时溯源），每树 20 条
  3. noul / choice / score 三类按 1:1:1 平衡
  4. 排除 v1 已产出的条目（按 tree+kind+state+options 指纹）
  5. `--rename-class1`：把通用树的部件名替换成卫星部件，作为第一类补充（借拓扑）

用法：
  DFT_OUT=$PWD/out_v2 python build_v2.py --class 1
  DFT_OUT=$PWD/out_v2 python build_v2.py --class 2 --rename-class1
"""
import argparse
import hashlib
import json
import random
import subprocess
import sys
import tempfile
import os
from collections import Counter
from pathlib import Path

import config
import gen_items as G
from galileo import Tree
from gen_multi import gen_multi

BASE = Path(__file__).resolve().parent
V1_OUT = BASE / "out"

CAP_V2 = {"mcs": 60, "action": 30, "noul": 60, "score": 60, "multi": 20}
SAT_POOL = [["太阳翼", "蓄电池", "放电调节器", "母线", "配电单元"],
            ["陀螺", "星敏感器", "反作用飞轮", "推力器", "加速度计"],
            ["应答机", "天线", "低噪放", "功放", "基带"],
            ["热管", "加热器", "辐射器", "泵", "阀门"]]


def read_jsonl(p):
    with open(p, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                yield json.loads(line)


def v1_fingerprints():
    """v1 已产出条目的指纹，用于排除重合。"""
    fps = set()
    for cls in (1, 2):
        p = V1_OUT / f"class{cls}" / "items.jsonl"
        if not p.exists():
            continue
        for it in read_jsonl(p):
            fps.add((it["meta"]["tree"], it["kind"],
                     it["state"], tuple(it["options"])))
    return fps


def rename_leaves(tree, rng):
    """把部件名替换成卫星部件（借拓扑）。"""
    ren = {}
    for i, leaf in enumerate(sorted(tree.leaves())):
        pool = SAT_POOL[i % len(SAT_POOL)]
        ren[leaf] = f"{pool[i % len(pool)]}{i + 1}"
    gates = {}
    for k, (kind, kids) in tree.gates.items():
        gates[ren.get(k, k)] = (kind, [ren.get(c, c) for c in kids])
    top = "卫星分系统失效" if tree.top in gates else tree.top
    if tree.top in gates:
        gates[top] = gates.pop(tree.top)
    return Tree(top=top, gates=gates, basics={}), ren


def run_one(idx, rename=False, timeout=60):
    fd, tmp = tempfile.mkstemp(suffix=".jsonl")
    os.close(fd)
    try:
        cmd = [sys.executable, "gen_worker_v2.py", str(idx), tmp]
        if rename:
            cmd.append("--rename")
        subprocess.run(cmd, cwd=str(BASE), stdout=subprocess.DEVNULL,
                       stderr=subprocess.DEVNULL, timeout=timeout)
        return list(read_jsonl(tmp)), "ok"
    except subprocess.TimeoutExpired:
        return [], "timeout"
    except Exception:
        return [], "error"
    finally:
        try: os.remove(tmp)
        except OSError: pass


def balance_kinds(rows, rng):
    """noul / choice / score 三类取齐到最小类。"""
    by = {}
    for r in rows:
        by.setdefault(r["kind"], []).append(r)
    if len(by) < 3:
        return rows
    k = min(len(v) for v in by.values())
    out = []
    for kind, rs in by.items():
        rng.shuffle(rs)
        out += rs[:k]
    rng.shuffle(out)
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--class", dest="cls", type=int, required=True, choices=[1, 2])
    ap.add_argument("--max-trees", type=int, default=0)
    ap.add_argument("--rename-class1", action="store_true",
                    help="把通用树改名后并入第一类（借拓扑补量）")
    ap.add_argument("--target", type=int, default=0)
    ap.add_argument("--timeout", type=int, default=60)
    ap.add_argument("--no-balance", action="store_true",
                    help="不做 1:1:1 均衡（用于第二类冲量）")
    args = ap.parse_args()

    trees = list(read_jsonl(config.TREES))
    fps = v1_fingerprints()
    print(f"v1 指纹 {len(fps)} 条，将排除重合项")

    idxs = [i for i, d in enumerate(trees) if d["class"] == args.cls]
    if args.max_trees:
        idxs = idxs[: args.max_trees]
    print(f"第{args.cls}类 {len(idxs)} 棵树")

    rows, skipped = [], Counter()
    for n, i in enumerate(idxs, 1):
        got, why = run_one(i, rename=(args.cls == 1 and args.rename_class1), timeout=args.timeout)
        skipped[why] += 1
        rows += got
        if n % 20 == 0 or n == len(idxs):
            print(f"  {n}/{len(idxs)} 累计 {len(rows)}", flush=True)

    # 排除 v1 重合
    before = len(rows)
    rows = [r for r in rows if (r["meta"]["tree"], r["kind"],
                                r["state"], tuple(r["options"])) not in fps]
    print(f"去重：{before} → {len(rows)}（排除 {before - len(rows)}）")

    rng = random.Random(20261111)
    if not args.no_balance:
        rows = balance_kinds(rows, rng)
    if args.target and len(rows) > args.target:
        rng.shuffle(rows)
        rows = rows[: args.target]

    # 切分：90/5/5
    for it in rows:
        it["id"] = hashlib.sha1(
            (it["meta"]["tree"] + "|" + it["kind"] + "|" + it["state"] + "|"
             + "||".join(it["options"])).encode("utf-8")).hexdigest()[:16]
        r = rng.random()
        it["split"] = "train" if r < config.TRAIN_RATIO else (
            "dev" if r < config.TRAIN_RATIO + config.DEV_RATIO else "benchmark")

    out = config.OUT / f"class{args.cls}"
    out.mkdir(parents=True, exist_ok=True)
    with open(out / "items.jsonl", "w", encoding="utf-8") as f:
        for it in rows:
            f.write(json.dumps(it, ensure_ascii=False) + "\n")

    rep = {"class": args.cls, "trees": len(idxs), "kept": len(rows),
           "by_kind": dict(Counter(x["kind"] for x in rows)),
           "by_gen": dict(Counter(x["meta"]["gen"] for x in rows)),
           "by_source": dict(Counter(x["tree_source"] for x in rows)),
           "skipped": dict(skipped)}
    (out / "build_report.json").write_text(json.dumps(rep, ensure_ascii=False, indent=2),
                                           encoding="utf-8")
    print(json.dumps(rep, ensure_ascii=False, indent=1))
    return 0


if __name__ == "__main__":
    sys.exit(main())
