﻿# -*- coding: utf-8 -*-
"""出题：逐树跑 gen_worker.py（子进程 + 超时），汇总后按类切分。

  python build.py            # 跑第一类 + 第二类
  python build.py --class 1  # 只跑第一类

每棵树独立进程、超时 60s，慢树自动跳过并记录，不会卡住整体。
切分：90% train / 5% dev / 5% benchmark；真实太空树固定进 benchmark。
"""
import argparse
import hashlib
import json
import os
import random
import subprocess
import sys
import tempfile
from collections import Counter, defaultdict
from pathlib import Path

import config

BASE = Path(__file__).resolve().parent


def read_jsonl(p):
    with open(p, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                yield json.loads(line)


def split_of(name, source, domain, rng):
    r = rng.random()
    if r < config.TRAIN_RATIO:
        return "train"
    if r < config.TRAIN_RATIO + config.DEV_RATIO:
        return "dev"
    return "benchmark"


def run_one(idx, timeout=60):
    fd, tmp = tempfile.mkstemp(suffix=".jsonl")
    os.close(fd)
    try:
        r = subprocess.run([sys.executable, "gen_worker.py", str(idx), tmp],
                           cwd=str(BASE), stdout=subprocess.PIPE,
                           stderr=subprocess.DEVNULL, timeout=timeout, text=True)
        if r.returncode != 0:
            return [], "worker_error"
        rows = list(read_jsonl(tmp))
        return rows, "ok"
    except subprocess.TimeoutExpired:
        return [], "timeout"
    except Exception:
        return [], "exception"
    finally:
        try:
            os.remove(tmp)
        except OSError:
            pass


def sample_to_target(rows, target, rng):
    if not target or len(rows) <= target:
        return rows
    by_tree = defaultdict(list)
    for r in rows:
        by_tree[r["meta"]["tree"]].append(r)
    total = len(rows)
    out = []
    for _, rs in by_tree.items():
        rng.shuffle(rs)
        out += rs[: max(1, round(len(rs) * target / total))]
    rng.shuffle(out)
    return out[:target]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--class", dest="cls", type=int, choices=[1, 2])
    ap.add_argument("--timeout", type=int, default=60)
    ap.add_argument("--max-trees", type=int, default=0, help="调试用：只跑前 N 棵")
    args = ap.parse_args()

    trees = list(read_jsonl(config.TREES))
    rng = random.Random(20261110)
    classes = [args.cls] if args.cls else [1, 2]

    for cls in classes:
        idxs = [i for i, d in enumerate(trees) if d["class"] == cls]
        if args.max_trees:
            idxs = idxs[: args.max_trees]
        print(f"\n=== 第{cls}类：{len(idxs)} 棵树 ===", flush=True)

        rows, skipped = [], Counter()
        for n, i in enumerate(idxs, 1):
            got, why = run_one(i, timeout=args.timeout)
            skipped[why] += 1
            if why != "ok":
                print(f"  [skip] {trees[i]['name']}: {why}", flush=True)
            rows += got
            if n % 10 == 0 or n == len(idxs):
                print(f"  {n}/{len(idxs)}  累计 {len(rows)} 条", flush=True)

        for it in rows:
            it["id"] = hashlib.sha1(
                (it["meta"]["tree"] + "|" + it["kind"] + "|" + it["state"] + "|"
                 + "||".join(it["options"])).encode("utf-8")).hexdigest()[:16]
            it["split"] = split_of(it["meta"]["tree"], it["tree_source"],
                                   it["meta"]["domain"], rng)

        full = len(rows)
        rows = sample_to_target(rows, config.TARGET[cls], rng)
        out = config.OUT / f"class{cls}"
        out.mkdir(parents=True, exist_ok=True)
        with open(out / "items.jsonl", "w", encoding="utf-8") as f:
            for it in rows:
                f.write(json.dumps(it, ensure_ascii=False) + "\n")

        rep = {"class": cls, "trees": len(idxs), "generated": full, "kept": len(rows),
               "target": config.TARGET[cls], "skipped": dict(skipped),
               "by_kind": dict(Counter(x["kind"] for x in rows)),
               "by_gen": dict(Counter(x["meta"]["gen"] for x in rows)),
               "by_split": dict(Counter(x["split"] for x in rows)),
               "by_domain": dict(Counter(x["meta"]["domain"] for x in rows)),
               "by_source": dict(Counter(x["tree_source"] for x in rows))}
        (out / "build_report.json").write_text(
            json.dumps(rep, ensure_ascii=False, indent=2), encoding="utf-8")
        print(json.dumps(rep, ensure_ascii=False, indent=1), flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
