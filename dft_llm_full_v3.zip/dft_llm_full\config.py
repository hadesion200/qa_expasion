﻿# -*- coding: utf-8 -*-
"""配置：只改这里，或用环境变量覆盖。"""
import os
from pathlib import Path

BASE = Path(__file__).resolve().parent

# 只需要一份 trees.jsonl（dft_gen 产出，129 KB），不依赖 out/ 里的题目
TREES = Path(os.environ.get("DFT_TREES", str(BASE / "data" / "trees.jsonl")))
OUT = Path(os.environ.get("DFT_OUT", str(BASE / "out")))
CACHE = BASE / ".cache"

API = {
    "base_url": os.environ.get("TEACHER_BASE_URL", "http://10.0.1.15:12349/v1"),
    "model": os.environ.get("TEACHER_MODEL", "WM-Qwen3.8-27B"),
    "key": os.environ.get("TEACHER_API_KEY", "EMPTY"),
    "concurrency": int(os.environ.get("TEACHER_CONCURRENCY", "16")),
    "timeout": int(os.environ.get("TEACHER_TIMEOUT", "120")),
    "retries": int(os.environ.get("TEACHER_RETRIES", "3")),
    "max_tokens": int(os.environ.get("TEACHER_MAX_TOKENS", "300")),
}

# ---- 每棵树的出题上限（"最多能生成多少条"由这里决定）----
CAP_MCS = int(os.environ.get("CAP_MCS", "40"))       # 割集题：每棵树最多 40 条（受割集总数限制）
CAP_ACTION = int(os.environ.get("CAP_ACTION", "24"))  # 动作题：每棵树最多 24 条
CAP_NOUL = int(os.environ.get("CAP_NOUL", "20"))     # 是否发生：每棵树最多 20 条
CAP_SCORE = int(os.environ.get("CAP_SCORE", "20"))   # 分级：每棵树最多 20 条

# ---- 精选上限（每棵树每题型保留多少条）----
SELECT_MCS = int(os.environ.get("SELECT_MCS", "5"))
SELECT_ACTION = int(os.environ.get("SELECT_ACTION", "4"))
SELECT_NOUL = int(os.environ.get("SELECT_NOUL", "6"))
SELECT_SCORE = int(os.environ.get("SELECT_SCORE", "6"))

# ---- 复查机制 ----
SOLVE_ROUNDS = int(os.environ.get("SOLVE_ROUNDS", "2"))  # 独立解题跑几轮，全部一致才收
MIN_LEN, MAX_LEN = 50, 600                                # 场景长度（模型实测常写 300-450 字）

# ---- 切分（按树，不按条目）----
SPACE_REAL_TO_BENCH = True     # 真实太空树全部进 benchmark 当锚点
