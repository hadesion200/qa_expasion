#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
bench.py —— Jev / System One 决策服务压测入口（唯一入口）

所有参数都在 config.ini 里，这个文件只用命令行"选步骤"：

    python bench.py check    # 0. 单请求契约检查：通不通、分布对不对、token 多少
    python bench.py smoke    # 1. 1 并发跑 12 条，拿单请求延迟基线
    python bench.py short    # 2. 短文本并发阶梯 → knee / goodput
    python bench.py long     # 3. 长上下文阶梯  → 显存墙在哪
    python bench.py open     # 4. 开环到达率   → SLO 达成率
    python bench.py all      # 依次跑 1~4

临时覆盖（不改 config.ini）：
    python bench.py short --concurrency 1,8 --duration 10
    python bench.py short --base http://10.0.0.5:8000 --api-key $KEY

产物：runs/<时间戳>-<步骤>/ 下 points.json / points.csv / report.md
      python bench.py all 会额外汇总一份 runs/summary.md

指标口径：
    req/s         每秒完成请求数
    dec/s         每秒完成 question 数（一个请求可含多问）
    tok/s         每秒输入 token 数（决策模型无 decode，就是 prefill 吞吐）
    p50/p95/p99   端到端延迟，含排队
    bad           概率契约被破坏的响应数（和≠1 / conf≠max / argmax_is_label=false）
"""

import argparse
import collections
import configparser
import http.client
import json
import os
import random
import statistics
import subprocess
import sys
import threading
import time
import urllib.parse
import urllib.request
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:  # noqa: BLE001
    pass

HERE = os.path.dirname(os.path.abspath(__file__))
SEP = "=" * 78


# ================================================================ 配置

DEFAULTS = {
    "api": {
        "base": "http://127.0.0.1:18080",
        "endpoint": "/v1/systemone",
        "model": "",
        "api_key": "",
        "timeout": "120",
    },
    "run": {
        "dataset": "data/jev_bench_v1.jsonl",
        "out_dir": "runs",
        "duration": "20",
        "warmup": "5",
        "slo_p95_ms": "300",
        "max_err": "0.001",
    },
    "steps": {
        "smoke_concurrency": "1",
        "smoke_duration": "8",
        "smoke_buckets": "short",
        "short_concurrency": "1,2,4,8,16,32",
        "short_buckets": "short,multi",
        "long_concurrency": "1,2,4,8",
        "long_buckets": "long",
        "long_slo_p95_ms": "2500",
        "open_rates": "5,10,20,40",
        "open_duration": "30",
    },
    "gpu": {
        "enabled": "true",
        "mem_cmd": "nvidia-smi --query-gpu=memory.used,memory.total "
                   "--format=csv,noheader,nounits",
        "vram_budget_pct": "90",
    },
}


class Cfg:
    def __init__(self, path):
        cp = configparser.ConfigParser(interpolation=None)
        if path and os.path.exists(path):
            cp.read(path, encoding="utf-8")
        else:
            print(f"! 找不到配置文件 {path}，使用内置默认值")
        self.cp = cp
        self.path = path

    def get(self, sec, key):
        val = self.cp.get(sec, key, fallback=None)
        if val is None:
            return DEFAULTS[sec][key]
        return val

    def f(self, sec, key):
        return float(self.get(sec, key))

    def i(self, sec, key):
        return int(self.get(sec, key))

    def b(self, sec, key):
        return self.get(sec, key).strip().lower() in ("1", "true", "yes", "on")

    def lst(self, sec, key):
        return [x.strip() for x in self.get(sec, key).split(",") if x.strip()]

    def pathof(self, p):
        return p if os.path.isabs(p) else os.path.join(HERE, p)


# ================================================================ 数据集

class Sample:
    __slots__ = ("sid", "body", "nq", "bucket", "est_tokens")

    def __init__(self, sid, body, nq, bucket, est_tokens):
        self.sid, self.body, self.nq = sid, body, nq
        self.bucket, self.est_tokens = bucket, est_tokens


def load_dataset(path, model, buckets, limit=0, shuffle=False):
    rows = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            d = json.loads(line)
            b = (d.get("meta") or {}).get("bucket") or "all"
            if buckets and b not in buckets:
                continue
            payload = {"model": model, "state": d["state"], "questions": d["questions"]}
            rows.append(Sample(
                d.get("id") or f"row{len(rows)}",
                json.dumps(payload, ensure_ascii=False).encode("utf-8"),
                len(d["questions"]), b, max(8, int(len(d["state"]) / 1.6))))
    if not rows:
        raise SystemExit(f"数据集按桶 {buckets} 过滤后为空：{path}")
    if shuffle:
        random.Random(20261109).shuffle(rows)
    return rows[:limit] if limit else rows


# ================================================================ 响应契约

def inspect(raw, verify=True):
    """返回 (n_answers, in_tokens, bad_list)。bad 非空 = 概率契约被破坏。"""
    try:
        j = json.loads(raw)
    except Exception:  # noqa: BLE001
        return 0, 0, ["bad_json"]
    usage = j.get("usage") or {}
    tin = int(usage.get("input_tokens") or 0)
    answers = j.get("answers")
    if not isinstance(answers, dict):
        return 0, tin, ["no_answers"]
    if not verify:
        return len(answers), tin, []

    bad = []
    for qid, a in answers.items():
        p = a.get("probabilities")
        vals = None
        if isinstance(p, dict):
            vals = [float(v) for v in p.values()]
        elif isinstance(p, list):
            vals = [float(v) for v in p]
        if not vals or len(vals) < 2:
            bad.append(f"{qid}:no_probs")
            continue
        s = sum(vals)
        if abs(s - 1.0) > 0.01:
            bad.append(f"{qid}:sum={s:.3f}")
        conf = a.get("confidence")
        if isinstance(conf, (int, float)) and abs(conf - max(vals)) > 2e-3:
            bad.append(f"{qid}:conf_ne_max")
    diag = j.get("diagnostics") or {}
    for qid, d in (diag.items() if isinstance(diag, dict) else []):
        if not isinstance(d, dict):
            continue
        lm = d.get("label_mass")
        if isinstance(lm, (int, float)) and abs(lm - 1.0) > 0.01:
            bad.append(f"{qid}:label_mass")
        if d.get("argmax_is_label") is False:
            bad.append(f"{qid}:argmax_not_label")
    return len(answers), tin, bad


# ================================================================ HTTP

class Client:
    def __init__(self, host, port, path, headers, timeout):
        self.host, self.port, self.path = host, port, path
        self.headers, self.timeout = headers, timeout
        self.conn = None

    def post(self, body):
        if self.conn is None:
            self.conn = http.client.HTTPConnection(self.host, self.port, timeout=self.timeout)
        for attempt in (0, 1):
            try:
                self.conn.request("POST", self.path, body=body, headers=self.headers)
                r = self.conn.getresponse()
                return r.status, r.read()
            except Exception:  # noqa: BLE001
                try:
                    if self.conn:
                        self.conn.close()
                except Exception:  # noqa: BLE001
                    pass
                self.conn = None
                if attempt:
                    raise
                self.conn = http.client.HTTPConnection(self.host, self.port,
                                                       timeout=self.timeout)


class Pool:
    def __init__(self, host, port, path, headers, timeout):
        self.args = (host, port, path, headers, timeout)
        self._tls = threading.local()

    def get(self):
        c = getattr(self._tls, "c", None)
        if c is None:
            c = Client(*self.args)
            self._tls.c = c
        return c


# ================================================================ 显存

class MemSampler(threading.Thread):
    def __init__(self, cmd, interval=0.5):
        super().__init__(daemon=True)
        self.cmd, self.interval = cmd, interval
        self.vals, self.total = [], None
        self._stop = threading.Event()

    def _one(self):
        out = subprocess.run(self.cmd, shell=True, capture_output=True,
                             text=True, timeout=10).stdout
        for line in out.splitlines():
            nums = []
            for part in line.replace("MiB", "").replace("MB", "").split(","):
                part = part.strip().split()[0] if part.strip() else ""
                try:
                    nums.append(float(part))
                except ValueError:
                    pass
            if nums:
                return nums[0], (nums[1] if len(nums) > 1 else None)
        return None, None

    def run(self):
        while not self._stop.is_set():
            try:
                used, total = self._one()
                if used is not None:
                    self.vals.append(used)
                    self.total = self.total or total
            except Exception:  # noqa: BLE001
                pass
            self._stop.wait(self.interval)

    def stop(self):
        self._stop.set()
        self.join(timeout=5)

    def summary(self):
        if not self.vals:
            return {}
        return {"avg": round(statistics.fmean(self.vals), 1),
                "peak": round(max(self.vals), 1), "total": self.total}


# ================================================================ 统计

def pct(vals, p):
    if not vals:
        return 0.0
    s = sorted(vals)
    if len(s) == 1:
        return s[0]
    k = (len(s) - 1) * p
    lo, hi = int(k), min(int(k) + 1, len(s) - 1)
    return s[lo] + (s[hi] - s[lo]) * (k - lo)


def stats_of(lat):
    if not lat:
        return {"mean": 0, "p50": 0, "p90": 0, "p95": 0, "p99": 0, "max": 0}
    return {"mean": statistics.fmean(lat), "p50": pct(lat, .5), "p90": pct(lat, .9),
            "p95": pct(lat, .95), "p99": pct(lat, .99), "max": max(lat)}


class Level:
    def __init__(self, label, conc=None, rate=None):
        self.label, self.conc, self.rate = label, conc, rate
        self.ok = self.err = 0
        self.lat, self.bad, self.errors = [], collections.Counter(), collections.Counter()
        self.decisions = self.tokens = 0
        self.elapsed = 0.0
        self.mem = {}
        self.by_bucket = collections.defaultdict(lambda: {"n": 0, "lat": [], "tok": 0})

    @property
    def rps(self):
        return self.ok / self.elapsed if self.elapsed else 0.0

    @property
    def dps(self):
        return self.decisions / self.elapsed if self.elapsed else 0.0

    @property
    def tps(self):
        return self.tokens / self.elapsed if self.elapsed else 0.0

    @property
    def err_rate(self):
        tot = self.ok + self.err
        return self.err / tot if tot else 0.0

    def add(self, ok, code, dt, raw, s, q_ok=True, verify=True):
        if not ok:
            self.err += 1
            self.errors[code] += 1
            return
        self.ok += 1
        self.lat.append(dt)
        nq, tin, bad = inspect(raw, verify) if q_ok else (s.nq, 0, [])
        self.decisions += nq or s.nq
        self.tokens += tin or s.est_tokens
        bk = self.by_bucket[s.bucket]
        bk["n"] += 1
        bk["lat"].append(dt)
        bk["tok"] += tin or s.est_tokens
        for why in bad:
            self.bad[why.split(":")[0] if ":" in why else why] += 1

    def as_dict(self):
        st = stats_of(self.lat)
        return {
            "label": self.label, "concurrency": self.conc, "target_rate": self.rate,
            "ok": self.ok, "err": self.err, "err_rate": round(self.err_rate, 6),
            "bad": sum(self.bad.values()), "bad_kinds": dict(self.bad),
            "errors": dict(self.errors),
            "req_per_s": round(self.rps, 2), "decisions_per_s": round(self.dps, 2),
            "input_tokens_per_s": round(self.tps, 1),
            "tokens_per_req": round(self.tokens / self.ok, 1) if self.ok else 0,
            "lat_ms": {k: round(v, 1) for k, v in st.items()},
            "elapsed_s": round(self.elapsed, 3), "gpu_mem_mb": self.mem,
            "by_bucket": {k: {"n": v["n"],
                              "req_per_s": round(v["n"] / self.elapsed, 2) if self.elapsed else 0,
                              "p50_ms": round(pct(v["lat"], .5), 1),
                              "p95_ms": round(pct(v["lat"], .95), 1)}
                          for k, v in self.by_bucket.items()},
        }


# ================================================================ 执行

def run_closed(pool, samples, n, duration, verify=True):
    lv = Level(f"c{n}", conc=n)
    stop = time.perf_counter() + duration
    buf, lock, idx = [], threading.Lock(), [0]
    t0 = time.perf_counter()

    def worker():
        local, c = [], pool.get()
        while time.perf_counter() < stop:
            with lock:
                i = idx[0]
                idx[0] += 1
            s = samples[i % len(samples)]
            t = time.perf_counter()
            try:
                st, raw = c.post(s.body)
                ok, code = (200 <= st < 300), str(st)
            except Exception as e:  # noqa: BLE001
                ok, code, raw = False, type(e).__name__, b""
            local.append((ok, code, (time.perf_counter() - t) * 1000.0, raw, s))
        with lock:
            buf.extend(local)

    ths = [threading.Thread(target=worker, daemon=True) for _ in range(n)]
    for t in ths:
        t.start()
    for t in ths:
        t.join()
    lv.elapsed = time.perf_counter() - t0
    for ok, code, dt, raw, s in buf:
        lv.add(ok, code, dt, raw, s, True, verify)
    return lv


def run_open(pool, samples, rate, duration, verify=True):
    lv = Level(f"r{rate:g}", rate=rate)
    cap = max(64, int(rate * 20))
    lock, idx = threading.Lock(), [0]
    t_end = time.perf_counter() + duration
    t0 = time.perf_counter()

    def one():
        with lock:
            i = idx[0]
            idx[0] += 1
        s = samples[i % len(samples)]
        t = time.perf_counter()
        try:
            st, raw = pool.get().post(s.body)
            ok, code = (200 <= st < 300), str(st)
        except Exception as e:  # noqa: BLE001
            ok, code, raw = False, type(e).__name__, b""
        lv.add(ok, code, (time.perf_counter() - t) * 1000.0, raw, s, True, verify)

    ex = ThreadPoolExecutor(max_workers=cap)
    now = time.perf_counter()
    while now < t_end and rate > 0:
        ex.submit(one)
        now += 1.0 / rate
        delay = now - time.perf_counter()
        if delay > 0:
            time.sleep(delay)
    ex.shutdown(wait=True)
    lv.elapsed = time.perf_counter() - t0
    return lv


# ================================================================ 输出

def table(levels):
    head = (f"{'档位':<7}{'并发/速率':>9}{'req/s':>9}{'dec/s':>9}{'tok/s':>10}"
            f"{'p50':>7}{'p95':>7}{'p99':>7}{'err%':>7}{'bad':>6}{'memMB':>8}")
    out = [head, "-" * 78]
    for lv in levels:
        st = stats_of(lv.lat)
        tag = lv.conc if lv.conc is not None else f"{lv.rate:g}/s"
        out.append(f"{lv.label:<7}{str(tag):>9}{lv.rps:>9.1f}{lv.dps:>9.1f}"
                   f"{lv.tps:>10.0f}{st['p50']:>7.0f}{st['p95']:>7.0f}{st['p99']:>7.0f}"
                   f"{lv.err_rate * 100:>7.2f}{sum(lv.bad.values()):>6}"
                   f"{lv.mem.get('avg', 0):>8.0f}")
    return "\n".join(out)


def mem_fit(idle_mb, levels, budget_mb):
    pts = [(lv.conc, lv.mem.get("avg")) for lv in levels
           if lv.conc and lv.mem.get("avg") and lv.ok]
    if len(pts) < 2 or not idle_mb:
        return {}
    xs = [p[0] for p in pts]
    ys = [p[1] - idle_mb for p in pts]
    den = sum(x * x for x in xs)
    slope = sum(x * y for x, y in zip(xs, ys)) / den if den else 0
    if slope < 0.5:
        return {"idle_mb": round(idle_mb, 1), "mb_per_conc": 0,
                "note": "未观测到显存随并发增长（可能已被预分配，或采的不是目标机）"}
    res = {"idle_mb": round(idle_mb, 1), "mb_per_conc": round(slope, 1)}
    if budget_mb:
        res["budget_mb"] = round(budget_mb, 1)
        res["max_conc_est"] = int(max(0, (budget_mb - idle_mb) / slope))
    return res


def write_report(outdir, title, levels, idle, ma, slo, max_err, meta):
    os.makedirs(outdir, exist_ok=True)
    data = {"title": title, "meta": meta, "idle_mem": idle,
            "mem_analysis": ma, "levels": [lv.as_dict() for lv in levels]}
    json.dump(data, open(os.path.join(outdir, "points.json"), "w", encoding="utf-8"),
              ensure_ascii=False, indent=2)

    csv = ["label,concurrency,target_rate,ok,err,err_rate,bad,req_per_s,decisions_per_s,"
           "input_tokens_per_s,p50_ms,p90_ms,p95_ms,p99_ms,max_ms,mem_avg_mb,mem_peak_mb"]
    for lv in levels:
        st = stats_of(lv.lat)
        csv.append(f"{lv.label},{lv.conc or ''},{lv.rate or ''},{lv.ok},{lv.err},"
                   f"{lv.err_rate:.6f},{sum(lv.bad.values())},{lv.rps:.2f},{lv.dps:.2f},"
                   f"{lv.tps:.1f},{st['p50']:.1f},{st['p90']:.1f},{st['p95']:.1f},"
                   f"{st['p99']:.1f},{st['max']:.1f},"
                   f"{lv.mem.get('avg', 0)},{lv.mem.get('peak', 0)}")
    open(os.path.join(outdir, "points.csv"), "w", encoding="utf-8").write("\n".join(csv) + "\n")

    md = [f"# {title}", "",
          f"- 时间：{datetime.now().isoformat(timespec='seconds')}",
          f"- 目标：`{meta.get('base')}{meta.get('endpoint')}`",
          f"- 模型：`{meta.get('model')}`",
          f"- 数据：{meta.get('data')}",
          f"- 预热/测量：{meta.get('warmup')}s / {meta.get('duration')}s",
          f"- SLO：p95 ≤ {slo:g} ms，错误率 ≤ {max_err * 100:g}%", "",
          "## 阶梯", "",
          "| 档位 | 并发/速率 | req/s | dec/s | tok/s | p50 | p95 | p99 | err% | bad | mem MB |",
          "|---|---|---|---|---|---|---|---|---|---|---|"]
    for lv in levels:
        st = stats_of(lv.lat)
        tag = lv.conc if lv.conc is not None else f"{lv.rate:g}/s"
        md.append(f"| {lv.label} | {tag} | {lv.rps:.1f} | {lv.dps:.1f} | {lv.tps:.0f} | "
                  f"{st['p50']:.0f} | {st['p95']:.0f} | {st['p99']:.0f} | "
                  f"{lv.err_rate * 100:.2f} | {sum(lv.bad.values())} | "
                  f"{lv.mem.get('avg', 0):.0f} |")

    if any(lv.by_bucket for lv in levels):
        md += ["", "## 分桶", "", "| 档位 | 桶 | n | req/s | p50 | p95 |", "|---|---|---|---|---|---|"]
        for lv in levels:
            for bk, v in sorted(lv.by_bucket.items()):
                if v["n"]:
                    md.append(f"| {lv.label} | {bk} | {v['n']} | "
                              f"{v['n'] / lv.elapsed:.1f} | "
                              f"{pct(v['lat'], .5):.0f} | {pct(v['lat'], .95):.0f} |")

    good = [lv for lv in levels if lv.ok and lv.err_rate <= max_err
            and stats_of(lv.lat)["p95"] <= slo]
    md += [""]
    if good:
        knee = max(good, key=lambda lv: (lv.conc or 0, lv.rate or 0))
        md.append(f"**knee**：`{knee.label}`，{knee.rps:.1f} req/s，"
                  f"{knee.dps:.1f} dec/s，{knee.tps:.0f} in-tok/s")
    else:
        md.append("**没有档位满足 SLO**：全部超阈值或全部失败。")
    if ma:
        md.append("")
        md.append(f"**显存**：空载 {ma['idle_mb']:.0f} MB"
                  + (f"，每并发 {ma['mb_per_conc']:.0f} MB" if ma.get("mb_per_conc") else ""))
        if "max_conc_est" in ma:
            md.append(f"，预算 {ma['budget_mb']:.0f} MB → 预计上限约 {ma['max_conc_est']} 并发")
        if ma.get("note"):
            md.append(f"（{ma['note']}）")

    open(os.path.join(outdir, "report.md"), "w", encoding="utf-8").write("\n".join(md) + "\n")
    return good, md


# ================================================================ 主流程

def ctx(cfg, over):
    """把 config + 命令行覆盖合成运行上下文"""
    base = over.base or cfg.get("api", "base")
    u = urllib.parse.urlparse(base)
    if not u.hostname:
        raise SystemExit(f"base 不合法：{base}")
    model = over.model or cfg.get("api", "model") or detect_model(base)
    key = over.api_key or os.environ.get("JEV_API_KEY") or cfg.get("api", "api_key")
    headers = {"Content-Type": "application/json", "Connection": "keep-alive"}
    if key:
        headers["Authorization"] = f"Bearer {key}"
    return {
        "base": f"{u.scheme}://{u.netloc}",
        "host": u.hostname, "port": u.port or 8000,
        "endpoint": cfg.get("api", "endpoint"), "model": model,
        "headers": headers, "timeout": cfg.f("api", "timeout"),
        "dataset": cfg.pathof(cfg.get("run", "dataset")),
        "out_dir": cfg.pathof(cfg.get("run", "out_dir")),
        "duration": over.duration or cfg.f("run", "duration"),
        "warmup": over.warmup if over.warmup is not None else cfg.f("run", "warmup"),
        "slo": over.slo or cfg.f("run", "slo_p95_ms"),
        "max_err": cfg.f("run", "max_err"),
        "mem_on": cfg.b("gpu", "enabled") and not over.no_mem,
        "mem_cmd": cfg.get("gpu", "mem_cmd"),
        "budget_pct": cfg.f("gpu", "vram_budget_pct"),
    }


def detect_model(base):
    try:
        with urllib.request.urlopen(f"{base}/v1/models", timeout=8) as r:
            j = json.loads(r.read().decode("utf-8", "replace"))
        items = j.get("data") or j.get("models") or []
        if items:
            return items[0].get("id") or items[0].get("name") or ""
    except Exception:  # noqa: BLE001
        pass
    return ""


def run_levels(c, cfg, step, levels_spec, buckets, verify=True):
    samples = load_dataset(c["dataset"], c["model"], buckets)
    pool = Pool(c["host"], c["port"], c["endpoint"], c["headers"], c["timeout"])
    mem_cmd = c["mem_cmd"] if c["mem_on"] else ""

    idle = {}
    if mem_cmd:
        s = MemSampler(mem_cmd)
        s.start()
        time.sleep(2)
        s.stop()
        idle = s.summary()
        if idle.get("total"):
            print(f"[基线] 空载显存 {idle['avg']:.0f} / {idle['total']:.0f} MB")

    levels = []
    for spec in levels_spec:
        kind, val = spec
        if c["warmup"] > 0:
            if kind == "c":
                run_closed(pool, samples, val, c["warmup"], False)
            else:
                run_open(pool, samples, val, c["warmup"], False)
            print(f"[warmup] {kind}{val}")
        ms = MemSampler(mem_cmd) if mem_cmd else None
        if ms:
            ms.start()
        if kind == "c":
            lv = run_closed(pool, samples, val, c["duration"], verify)
        else:
            lv = run_open(pool, samples, val, c["duration"], verify)
        if ms:
            ms.stop()
            lv.mem = ms.summary()
        levels.append(lv)
        st = stats_of(lv.lat)
        print(f"[{lv.label:<8}] {lv.rps:7.1f} req/s {lv.dps:7.1f} dec/s "
              f"{lv.tps:8.0f} tok/s  p50={st['p50']:5.0f} p95={st['p95']:5.0f} "
              f"p99={st['p99']:5.0f}  err={lv.err_rate * 100:.2f}%  "
              f"bad={sum(lv.bad.values())}  mem={lv.mem.get('avg', 0):.0f}MB")

    total = idle.get("total") or 0
    ma = mem_fit(idle.get("avg") or 0, levels, total * c["budget_pct"] / 100.0)

    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    outdir = os.path.join(c["out_dir"], f"{ts}-{step}")
    meta = {"base": c["base"], "endpoint": c["endpoint"], "model": c["model"],
            "data": os.path.basename(c["dataset"]) + f" [{','.join(buckets) or 'all'}]",
            "warmup": c["warmup"], "duration": c["duration"]}
    good, md = write_report(outdir, f"jev 压测 · {step}", levels, idle, ma,
                            c["slo"], c["max_err"], meta)

    print("\n" + table(levels))
    if good:
        knee = max(good, key=lambda lv: (lv.conc or 0, lv.rate or 0))
        print(f"\n→ knee {knee.label}: {knee.rps:.1f} req/s, {knee.dps:.1f} dec/s, "
              f"{knee.tps:.0f} in-tok/s")
    else:
        print("\n→ 没有档位满足 SLO")
    if ma.get("mb_per_conc"):
        msg = f"→ 显存：空载 {ma['idle_mb']:.0f} MB，每并发 {ma['mb_per_conc']:.0f} MB"
        if "max_conc_est" in ma:
            msg += f"，预计上限约 {ma['max_conc_est']} 并发"
        print(msg)
    print(f"\n产物：{outdir}")
    return outdir, levels


def step_check(c):
    print(SEP)
    print(f"契约检查 → {c['base']}{c['endpoint']}  model={c['model']}")
    print(SEP)
    samples = load_dataset(c["dataset"], c["model"], ["short"])[:1]
    st, raw = Pool(c["host"], c["port"], c["endpoint"],
                   c["headers"], c["timeout"]).get().post(samples[0].body)
    print(f"HTTP {st}  {len(raw)} B")
    try:
        j = json.loads(raw)
    except Exception:  # noqa: BLE001
        print("! 响应不是 JSON：", raw[:200])
        return 1
    nq, tin, bad = inspect(raw, True)
    print(json.dumps(j, ensure_ascii=False, indent=2)[:1200])
    print(f"\nanswers={nq}  input_tokens={tin}  contract={'OK' if not bad else bad}")
    return 0 if (st == 200 and nq and not bad) else 1


def main():
    ap = argparse.ArgumentParser(description="jev 决策服务压测（config.ini 驱动）")
    ap.add_argument("step", nargs="?", default="all",
                    choices=["check", "smoke", "short", "long", "open", "all"])
    ap.add_argument("--config", default=os.path.join(HERE, "config.ini"))
    ap.add_argument("--base")
    ap.add_argument("--model")
    ap.add_argument("--api-key")
    ap.add_argument("--duration", type=float)
    ap.add_argument("--warmup", type=float)
    ap.add_argument("--slo", type=float)
    ap.add_argument("--concurrency", help="覆盖并联阶梯，如 1,8,32")
    ap.add_argument("--out-dir")
    ap.add_argument("--no-mem", action="store_true")
    over = ap.parse_args()

    cfg = Cfg(over.config)
    c = ctx(cfg, over)
    if over.concurrency:
        if not cfg.cp.has_section("steps"):
            cfg.cp.add_section("steps")
        cfg.cp.set("steps", "short_concurrency", over.concurrency)
    if over.out_dir:
        c["out_dir"] = os.path.abspath(over.out_dir)

    print(SEP)
    print(f"配置  : {over.config}")
    print(f"目标  : {c['base']}{c['endpoint']}")
    print(f"模型  : {c['model'] or '(未指定，可能 404)'}")
    print(f"数据  : {c['dataset']}")
    print(f"输出  : {c['out_dir']}")

    if over.step == "check":
        return step_check(c)

    steps = {
        "smoke": ("smoke", [("c", cfg.i("steps", "smoke_concurrency"))],
                  cfg.lst("steps", "smoke_buckets"), cfg.f("steps", "smoke_duration")),
        "short": ("short", [("c", int(x)) for x in cfg.lst("steps", "short_concurrency")],
                  cfg.lst("steps", "short_buckets"), c["duration"]),
        "long": ("long", [("c", int(x)) for x in cfg.lst("steps", "long_concurrency")],
                 cfg.lst("steps", "long_buckets"), c["duration"]),
        "open": ("open", [("r", float(x)) for x in cfg.lst("steps", "open_rates")],
                 cfg.lst("steps", "short_buckets"), cfg.f("steps", "open_duration")),
    }
    todo = list(steps) if over.step == "all" else [over.step]

    run_dirs = []
    for name in todo:
        title, spec, buckets, dur = steps[name]
        if over.duration:
            dur = over.duration
        c["duration"] = dur
        c["slo"] = cfg.f("steps", "long_slo_p95_ms") if name == "long" else c["slo"]
        print("\n" + SEP)
        print(f"步骤 {name}  桶={','.join(buckets)}  阶梯={len(spec)}  每档 {dur:g}s")
        print(SEP)
        d, _ = run_levels(c, cfg, name, spec, buckets)
        run_dirs.append((name, d))

    if len(run_dirs) > 1:
        path = os.path.join(c["out_dir"], "summary.md")
        with open(path, "w", encoding="utf-8") as f:
            f.write("# jev 压测汇总\n\n")
            for name, d in run_dirs:
                f.write(f"- **{name}** → `{os.path.relpath(d, c['out_dir'])}`\n")
        print(f"\n汇总：{path}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
