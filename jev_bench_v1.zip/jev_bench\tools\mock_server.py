"""本地假服务：模拟 structured_decision 响应，用于在没 GPU 的机器上先验证压测链路。

    python tools/mock_server.py --port 18082
    python bench.py check --base http://127.0.0.1:18082

延迟按 input token 数线性放大（0.4ms / 100 tokens），模拟 prefill 成本。
"""
import argparse
import json
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

MS_PER_1K_TOKENS = 400.0


class H(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, *a):
        pass

    def _send(self, obj, code=200):
        b = json.dumps(obj, ensure_ascii=False).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(b)))
        self.end_headers()
        self.wfile.write(b)

    def do_GET(self):
        if self.path.startswith("/health"):
            return self._send({"ok": True})
        if self.path.startswith("/v1/models"):
            return self._send({"data": [{"id": "mock-sdec-4b-8k"}]})
        self._send({"err": "nf"}, 404)

    def do_POST(self):
        n = int(self.headers.get("Content-Length", 0))
        raw = self.rfile.read(n)
        try:
            body = json.loads(raw.decode("utf-8"))
        except Exception:
            return self._send({"err": "bad json"}, 400)

        state = body.get("state") or ""
        questions = body.get("questions") or {}
        toks = int(len(state) / 1.6) + 20
        time.sleep(toks * MS_PER_1K_TOKENS / 1000.0 / 1000.0)

        answers = {}
        for qid, q in questions.items():
            crit = q.get("criteria")
            if isinstance(crit, dict):
                labels = list(crit.keys())
            elif isinstance(crit, list):
                labels = [str(x) for x in range(len(crit))]
            else:
                labels = ["false", "true"]
            # 造一个和为 1 的分布
            w = [0.2 + 0.1 * i for i in range(len(labels))]
            s = sum(w)
            probs = {lab: round(x / s, 6) for lab, x in zip(labels, w)}
            top = max(probs, key=probs.get)
            answers[qid] = {
                "type": q.get("type", "choice"),
                "choice": top,
                "probabilities": probs,
                "confidence": probs[top],
                "label_mass": 1.0,
            }

        self._send({
            "id": "decision-mock0001",
            "object": "structured_decision",
            "created": int(time.time()),
            "model": body.get("model", "mock"),
            "answers": answers,
            "usage": {"input_tokens": toks, "output_tokens": 0},
            "diagnostics": {k: {"label_mass": 1.0, "argmax_is_label": True}
                            for k in answers},
            "joint": None,
        })


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--port", type=int, default=18082)
    ap.add_argument("--host", default="127.0.0.1")
    a = ap.parse_args()
    print(f"mock 决策服务: http://{a.host}:{a.port}/v1/systemone")
    ThreadingHTTPServer((a.host, a.port), H).serve_forever()
