# jev 决策服务压测包

一个 `config.ini` 配置 API，其余分步跑。纯 Python 标准库，无 pip 依赖。

## 快速开始

```bash
# 1. 改 config.ini 里的 [api] 段
#    base / endpoint / model / api_key

# 2. 确认协议通（10 秒）
python bench.py check

# 3. 分步跑
python bench.py smoke    # 1 并发，单请求延迟基线
python bench.py short    # 短文本并发阶梯 → knee / goodput
python bench.py long     # 长上下文阶梯 → 显存墙
python bench.py open     # 开环到达率 → SLO 达成率
python bench.py all      # 依次跑 smoke→short→long→open
```

临时改参数（不动配置文件）：

```bash
python bench.py short --concurrency 1,8,32 --duration 10
python bench.py short --base http://10.0.0.5:8000 --api-key $KEY
python bench.py short --no-mem          # 不采显存
```

结果在 `runs/<时间戳>-<步骤>/`：`points.json` / `points.csv` / `report.md`。

## 指标口径

| 指标 | 含义 |
|---|---|
| req/s | 每秒完成请求数 |
| dec/s | 每秒完成 question 数（一个请求可含多问，跨模型比较用这个） |
| **tok/s** | 每秒输入 token 数。决策模型没有 decode，这就是 prefill 吞吐，是模型的硬上限 |
| p50/p95/p99 | 端到端延迟（含排队），客户端视角 |
| bad | 概率契约被破坏的响应数（和≠1 / conf≠max / argmax_is_label=false） |
| mem | 显存 used 均值，来自 `[gpu] mem_cmd` |

`knee` = 仍满足 SLO 的最大档位；`goodput` = 该档位的 req/s，对外承诺就用它。

## 数据集

`data/jev_bench_v1.jsonl` 共 300 条，从本地卫星定轨语料（`out/jev_suites`，994 条真实样本）分层生成：

| 桶 | 条数 | state 字符 | 约 token | 用途 |
|---|---|---|---|---|
| short | 120 | 150~533 | ~200 | 典型网关判定 |
| mid | 80 | 894~1625 | ~800 | 中等上下文 |
| long | 60 | 6537~8460 | ~4700 | 贴 8k 上限 |
| multi | 40 | 161~585 | ~200 × 4 问 | 一次调用多问 |

> mid/long 由多条真实 state 拼接（只为拉长 token 数，语义不保证连贯）；multi 的 4 个问来自不同样本。manifest.json 里都标了 `synthetic`。

需要重新生成：`python tools/build_dataset.py --src <语料目录>`（默认读 `../out/jev_suites`）。

## 怎么读结果

| 现象 | 结论 | 动作 |
|---|---|---|
| req/s 停滞、p95 线性涨 | 算力饱和 | 加并发无用，要加卡或减负载 |
| req/s 停滞、mem 逼近预算 | 显存墙 | 降 max-model-len / 拆长请求 / 加显存 |
| tok/s 恒定在某个值 | 模型的 prefill 上限 | 横向比模型只看它 |
| bad > 0 | 高并发下概率契约被破坏 | 不能放过，先修 |
| 5xx 且 body 含 out of memory | 显存打爆 | 降 `--max-num-seqs` |

显存那一段是拿各档实测均值做最小二乘反推的：`每并发 MB` 和 `预计最大并发`。
如果它显示“未观测到显存随并发增长”，通常是 `gpu_memory_utilization` 已把预算占满，
或者 `mem_cmd` 采的不是目标机器。

## 离线自检（没 GPU / 还没连内网时）

```bash
python tools/mock_server.py --port 18082       # 另开一个终端
python bench.py check --base http://127.0.0.1:18082
python bench.py short --base http://127.0.0.1:18082 --concurrency 1,4 --duration 5
```

mock 按 token 数模拟 prefill 延迟，链路和真实服务一致，用来确认参数、数据集、报告都正常。

## 注意

- 压测客户端别和 GPU 服务同机；Windows 上线程模型超过 ~64 并发自己会成瓶颈。
- 每档至少 20 秒，正式结论重复 3 次取中位数。
- 换 `--max-num-seqs` / `--gpu-memory-utilization` 后要重跑 `short` 和 `long` 才能对比。
- 服务端启动参数（max-num-seqs、max-model-len、gpu-memory-utilization）一定要和报告一起记，否则数字不可复现。
