#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
run_eval.py —— 唯一入口：OpenDecisions 官方口径 + 一致性补充

为什么只剩一套
    OpenDecisions 已经覆盖"准确性 + 校准"：Intelligence（相对随机基线的能力）、
    Calibration（分桶偏差）、Capability（两者均值），而且 scorer 是官方 pinned 版本、
    可复现、能和榜单横向比。自己再拼一个 100 分加权没有可比性，已删除。

    OpenDecisions 不覆盖"一致性"（换选项顺序、重复提问答案是否稳定），
    这一项仍由本脚本补：**只报原始统计量，不折算成分数**。
    判定沿用 JevBench 的阈值：TV ≤ 0.05 视为一致。

用法
    python run_eval.py                 # OD 全量 + 一致性 200 对
    python run_eval.py --od-limit 50 --pairs 40    # 冒烟
    python run_eval.py --skip-od       # 只补一致性
    python run_eval.py --fresh         # 忽略断点

产物（results/<模型名>/）
    <模型名>.md      合并报告：OD 三项分 + 一致性统计
    <模型名>.json     结构化结果
    od/              OpenDecisions 明细（predictions.jsonl 等）
"""

import argparse
import configparser
import http.client
import json
import os
import random
import re
import subprocess
import sys
import threading
import time
import urllib.parse
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
OD_DIR = os.path.join(HERE, "od")
SEP = "=" * 78

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:  # noqa: BLE001
    pass


def cget(cp, sec, key, default):
    v = cp.get(sec, key, fallback=None)
    return default if v is None else v


# ================================================================ HTTP

class Client:
    def __init__(self, host, port, headers, timeout):
        self.host, self.port, self.headers, self.timeout = host, port, headers, timeout
        self.conn = None

    def post(self, path, body):
        if self.conn is None:
            self.conn = http.client.HTTPConnection(self.host, self.port, timeout=self.timeout)
        for _ in (0, 1):
            try:
                self.conn.request("POST", path, body=body, headers=self.headers)
                r = self.conn.getresponse()
                return r.status, r.read()
            except Exception:  # noqa: BLE001
                try:
                    if self.conn:
                        self.conn.close()
                except Exception:  # noqa: BLE001
                    pass
                self.conn = None
                try:
                    self.conn = http.client.HTTPConnection(self.host, self.port,
                                                           timeout=self.timeout)
                except Exception:  # noqa: BLE001
                    raise


def ask(cli, endpoint, model, task, qid, criteria):
    body = json.dumps({"model": model, "state": task["state"],
                       "questions": {qid: {"type": task["question"]["type"],
                                           "instructions": task["question"].get("instructions", ""),
                                           "criteria": criteria}}},
                      ensure_ascii=False).encode()
    st, raw = cli.post(endpoint, body)
    if not (200 <= st < 300):
        return None
    ans = (json.loads(raw).get("answers") or {}).get(qid) or {}
    p = ans.get("probabilities")
    return {str(k): float(v) for k, v in p.items()} if isinstance(p, dict) and p else None


def tv(p, q):
    keys = set(p) & set(q)
    if not keys:
        return None
    return 0.5 * sum(abs(p[k] - q[k]) for k in keys)


# ================================================================ OD

def run_od(args, base, model, out_root, data_path=None):
    cmd = [sys.executable, os.path.join(OD_DIR, "run_od.py"),
           "--config", args.config, "--base", base, "--model", model,
           "--out-dir", out_root, "--concurrency", str(args.concurrency)]
    if data_path:
        cmd += ["--data", data_path]
    elif args.od_limit:
        cmd += ["--limit", str(args.od_limit)]
    if args.fresh:
        cmd += ["--fresh"]
    if args.api_key:
        cmd += ["--api-key", args.api_key]
    print(f"$ {' '.join(cmd)}")
    r = subprocess.run(cmd, cwd=HERE)
    if r.returncode != 0:
        raise SystemExit("od/run_od.py 失败")
    slug = re.sub(r"[^\w.\-]+", "_", model)[:60]
    p = os.path.join(out_root, slug, "od", f"{slug}.json")
    return json.load(open(p, encoding="utf-8"))


# ================================================================ 一致性

def consistency(tasks, base, model, endpoint, conc, n_pairs, rng, api_key):
    cand = [t for t in tasks if len(t.get("labels") or []) >= 3]
    rng.shuffle(cand)
    n_order = int(n_pairs * 0.75)
    n_repeat = n_pairs - n_order
    plan = []
    for t in cand[:n_order]:
        crit = t["question"]["criteria"]
        if isinstance(crit, dict):
            keys = list(crit.keys())
            perm = keys[:]
            for _ in range(5):
                rng.shuffle(perm)
                if perm != keys:
                    break
            vcrit = {k: crit[k] for k in perm}
        else:                                    # 少数题目的 criteria 是纯列表
            keys = [str(x) for x in crit]
            perm = keys[:]
            for _ in range(5):
                rng.shuffle(perm)
                if perm != keys:
                    break
            vcrit = perm
        plan.append(("order", t, vcrit))
    for t in cand[n_order:n_order + n_repeat]:
        plan.append(("repeat", t, t["question"]["criteria"]))

    u = urllib.parse.urlparse(base)
    headers = {"Content-Type": "application/json", "Connection": "keep-alive"}
    if api_key:
        headers["Authorization"] = f"Bearer {api_key}"
    out, lock = {}, threading.Lock()

    def work(start):
        cli = Client(u.hostname, u.port or 8000, headers, 120)
        for i in range(start, len(plan), conc):
            kind, t, crit = plan[i]
            qid = t["id"]
            try:
                a = ask(cli, endpoint, model, t, qid, t["question"]["criteria"])
                b = ask(cli, endpoint, model, t, qid, crit)
            except Exception:  # noqa: BLE001
                a = b = None
            with lock:
                out[i] = (a, b)

    ths = [threading.Thread(target=work, args=(k,), daemon=True) for k in range(conc)]
    for th in ths:
        th.start()
    for th in ths:
        th.join()

    rows = []
    for i, (kind, t, _c) in enumerate(plan):
        a, b = out.get(i, (None, None))
        if not a or not b:
            continue
        d = tv(a, b)
        if d is None:
            continue
        rows.append({"id": t["id"], "kind": kind, "tv": round(d, 4),
                     "flip": max(a, key=a.get) != max(b, key=b.get)})
    return rows


# ================================================================ main

def pick_subset(tasks, n, rng):
    """小样本时按题型分层，并保证 choice 里有 hard 档（Calibration 只统计 hard choice）。"""
    pool = list(tasks)
    rng.shuffle(pool)
    buckets = {t: [x for x in pool if x["question"]["type"] == t]
               for t in ("choice", "noul", "score")}
    hard = [x for x in buckets["choice"] if x.get("tier") == "hard"]
    soft = [x for x in buckets["choice"] if x.get("tier") != "hard"]
    buckets["choice"] = hard[: max(1, n // 4)] + soft + hard[max(1, n // 4):]

    out, i = [], 0
    while len(out) < min(n, len(tasks)):
        for t in ("choice", "noul", "score"):
            if i < len(buckets[t]) and len(out) < n:
                out.append(buckets[t][i])
        i += 1
        if i > len(tasks):
            break
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default=os.path.join(HERE, "config.ini"))
    ap.add_argument("--base")
    ap.add_argument("--model")
    ap.add_argument("--api-key")
    ap.add_argument("--od-limit", type=int, default=0)
    ap.add_argument("--pairs", type=int, default=200)
    ap.add_argument("--concurrency", type=int, default=0)
    ap.add_argument("--out-dir")
    ap.add_argument("--fresh", action="store_true")
    ap.add_argument("--skip-od", action="store_true")
    ap.add_argument("--skip-consistency", action="store_true")
    a = ap.parse_args()

    cp = configparser.ConfigParser(interpolation=None)
    if not os.path.exists(a.config):
        raise SystemExit(f"找不到配置：{a.config}")
    cp.read(a.config, encoding="utf-8")
    base = a.base or cget(cp, "api", "base", "http://127.0.0.1:9900")
    endpoint = cget(cp, "api", "endpoint", "/v1/systemone")
    model = a.model or cget(cp, "api", "model", "")
    key = a.api_key or os.environ.get("JEV_API_KEY") or cget(cp, "api", "api_key", "")
    conc = a.concurrency or int(cget(cp, "api", "concurrency", "8"))
    out_root = a.out_dir or os.path.join(HERE, "results")

    if not model:
        try:
            with urllib.request.urlopen(f"{base}/v1/models", timeout=8) as r:
                j = json.loads(r.read().decode("utf-8", "replace"))
            it = (j.get("data") or j.get("models") or [])
            model = (it[0].get("id") or it[0].get("name")) if it else ""
        except Exception:  # noqa: BLE001
            pass
    if not model:
        raise SystemExit("无法确定 model：请在 config.ini 的 [api] model 填写")

    slug = re.sub(r"[^\w.\-]+", "_", model)[:60]
    outdir = os.path.join(out_root, slug)
    os.makedirs(outdir, exist_ok=True)

    print(SEP)
    print("jev 决策模型评测")
    print(f"  模型 : {model}")
    print(f"  服务 : {base}{endpoint}   并发 {conc}")
    print(f"  输出 : {outdir}")
    print(SEP)

    od = None
    cons = None
    tasks_all = [json.loads(l) for l in open(os.path.join(OD_DIR, "opendecisions.jsonl"),
                                             encoding="utf-8") if l.strip()]
    subset = pick_subset(tasks_all, a.od_limit, random.Random(20261110)) if a.od_limit else None
    data_path = None
    if subset:
        data_path = os.path.join(outdir, "_od_subset.jsonl")
        with open(data_path, "w", encoding="utf-8") as f:
            for t in subset:
                f.write(json.dumps(t, ensure_ascii=False) + "\n")

    if not a.skip_od:
        print("\n[1/2] OpenDecisions（官方 scorer）")
        od = run_od(a, base, model, out_root, data_path)

    if not a.skip_consistency and a.pairs > 0:
        print(f"\n[2/2] 一致性：{a.pairs} 对（换序 75% + 重复 25%）")
        tasks = subset or tasks_all
        cons = consistency(tasks, base, model, endpoint, conc, a.pairs,
                           random.Random(20261110), key)
        tvs = [r["tv"] for r in cons]
        if tvs:
            print(f"      n={len(tvs)}  TV 均值 {sum(tvs)/len(tvs):.4f}  "
                  f"通过率 {sum(1 for x in tvs if x <= 0.05)/len(tvs):.1%}")

    # ---- 合并报告
    def f1(x):
        return "—" if x is None else f"{x:.1f}"

    md = [f"# {model} 评测报告", "",
          "> 准确性/校准 = OpenDecisions 官方 scorer v1.6；一致性 = 本包补充（原始统计量，不折分）", "",
          "## 1. 准确性 / 校准（OpenDecisions，"
          f"{od['items'] if od else 2352} 题）", ""]
    if od:
        md += ["| 指标 | 得分 |", "|---|---|",
               f"| **Capability** | **{f1(od['capability'])}** |",
               f"| Intelligence | {f1(od['intelligence'])} |",
               f"| Calibration | {f1(od['calibration'])} |", "",
               f"预测覆盖：{od['predicted']}/{od['items']}", "",
               "| 题型 | 准确率 | 能力 | 校准 |", "|---|---|---|---|"]
        for t in ("choice", "noul", "score"):
            if t in od["accuracy_per_type"]:
                md.append(f"| {t} | {od['accuracy_per_type'][t]:.1f}% | "
                          f"{f1(od['competence_per_type'].get(t))} | "
                          f"{f1(od['calibration_per_type'].get(t))} |")
        if od.get("calibration_items_tvd") is not None:
            md += ["", f"真概率题（{od['calibration_items']} 条）平均 TVD："
                       f"**{od['calibration_items_tvd']:.3f}**（0 = 完全一致）"]
    else:
        md += ["（本次跳过）"]

    md += ["", "## 2. 一致性（补充项）", ""]
    if cons:
        tvs = [r["tv"] for r in cons]
        if tvs:
            order = [r["tv"] for r in cons if r["kind"] == "order"]
            rep = [r["tv"] for r in cons if r["kind"] == "repeat"]
            flip = sum(1 for r in cons if r["flip"]) / len(cons)
            md += ["| 变体 | 对数 | TV 均值 | 通过率(TV≤0.05) |", "|---|---|---|---|"]
            if order:
                md.append(f"| 换序 | {len(order)} | {sum(order)/len(order):.4f} | "
                          f"{sum(1 for x in order if x <= 0.05)/len(order):.1%} |")
            if rep:
                md.append(f"| 重复 | {len(rep)} | {sum(rep)/len(rep):.4f} | "
                          f"{sum(1 for x in rep if x <= 0.05)/len(rep):.1%} |")
            md += ["", f"- 整体 TV 均值 **{sum(tvs)/len(tvs):.4f}**，"
                       f"答案翻转率 {flip:.1%}"]
        else:
            md += ["（没有拿到有效的成对响应）"]
    else:
        md += ["（本次跳过）"]

    md += ["", "## 3. 口径", "",
           "- 三项分数由官方 `od/score.py` 计算，本包未改一行。",
           "- 一致性只报 TV 统计量，不并入 Capability——OpenDecisions 本身不含该维度。",
           "- 未预测条目按错处理（官方约定）。", ""]

    json.dump({"model": model, "od": od,
               "consistency": {"n": len(cons or []), "rows": cons or []}},
              open(os.path.join(outdir, f"{slug}.json"), "w", encoding="utf-8"),
              ensure_ascii=False, indent=1)
    rpt = os.path.join(outdir, f"{slug}.md")
    open(rpt, "w", encoding="utf-8").write("\n".join(md))
    print("\n" + "\n".join(md))
    print(f"\n报告：{rpt}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
