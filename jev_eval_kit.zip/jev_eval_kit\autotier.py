#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
autotier.py —— 用「探测模型 + LLM」给数据集自动分档，并校验是否满足 OD 测评要求

流程
    1. 探测：用 jev（默认 d3-mini）跑一遍，记录每题对错与置信度
    2. 分档：答错的题交给 LLM 复核「是否真的属于 hard」；
             答对的题交给 LLM 判断「easy 还是 standard」
    3. 质检：同一次 LLM 调用顺带判断题目是否合格（gold 唯一、无歧义、信息充分）
    4. 校验：题型/难度/单元格数量、hard choice 数量、tier 分布是否均衡
    5. 输出：od_ready/<name>.jsonl + 校验报告

⚠️ 循环论证警告
    用模型 A 的对错来分档，再用这份数据给模型 A 打分，tier 就"贴着"模型 A 了，
    它的 Capability 会被系统性放大。**分档模型必须 ≠ 被测模型**，
    或者在报告里写明"tier 由 X 模型的对错生成"。

用法
    python autotier.py --src datasets_raw/xxx.jsonl --name dft
    python autotier.py --src ... --llm-base http://...:8001/v1 --llm-model qwen
    python autotier.py --src ... --fresh          # 忽略断点
"""

import argparse
import configparser
import hashlib
import json
import os
import sys
import threading
import time
import urllib.parse
from collections import Counter, defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import evaluate as E  # noqa: E402
from make_od_dataset import LLM, parse_json  # noqa: E402

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:  # noqa: BLE001
    pass

TIERS = ("easy", "standard", "judge", "hard")
SEP = "=" * 78


def load_state(path):
    try:
        return json.load(open(path, encoding="utf-8"))
    except Exception:  # noqa: BLE001
        return {}


def save_state(path, data):
    tmp = path + ".tmp"
    json.dump(data, open(tmp, "w", encoding="utf-8"), ensure_ascii=False)
    os.replace(tmp, path)


# ================================================================ 1. 探测

def probe(tasks, cfg, state_path, conc, fresh):
    done = {} if fresh else load_state(state_path)
    todo = [t for t in tasks if t["id"] not in done]
    if done:
        print(f"      探测断点：已完成 {len(done)}，待做 {len(todo)}")
    if not todo:
        return done

    lock = threading.Lock()
    n = [0]

    def work(start):
        cli = E.Client(cfg["host"], cfg["port"], cfg["headers"], cfg["timeout"])
        for i in range(start, len(todo), conc):
            t = todo[i]
            rec = {"ok": False}
            t0 = time.perf_counter()
            for q in E.payload_shapes(t):
                try:
                    body = json.dumps({"model": cfg["model"], "state": t["state"],
                                       "questions": {t["id"]: q}},
                                      ensure_ascii=False).encode()
                    st, raw = cli.post(cfg["endpoint"], body)
                    if 200 <= st < 300:
                        ans = (json.loads(raw).get("answers") or {}).get(t["id"]) or {}
                        p = E.to_probs(ans, t)
                        if p:
                            vec = [p.get(l, 0.0) for l in t["labels"]]
                            s = sum(vec) or 1.0
                            vec = [v / s for v in vec]
                            i2 = max(range(len(vec)), key=lambda k: vec[k])
                            rec = {"ok": True, "pred": t["labels"][i2],
                                   "conf": round(vec[i2], 4),
                                   "correct": t["labels"][i2] == t["expected"]}
                            break
                except Exception as e:  # noqa: BLE001
                    rec = {"ok": False, "error": type(e).__name__}
            rec["ms"] = round((time.perf_counter() - t0) * 1000, 1)
            with lock:
                done[t["id"]] = rec
                n[0] += 1
                if n[0] % 100 == 0:
                    save_state(state_path, done)
                    print(f"      探测 {n[0]}/{len(todo)}")
    ths = [threading.Thread(target=work, args=(k,), daemon=True) for k in range(conc)]
    for t in ths:
        t.start()
    for t in ths:
        t.join()
    save_state(state_path, done)
    return done


# ================================================================ 2. 分档 + 质检

SYS = ("你是数据集审校。给你一道选择题、标准答案，以及某个决策模型是否答对。"
       "请做两件事：\n"
       "1) 给这道题打一个 **1-10 的连续难度分**（不是分档）。判据：\n"
       "   1-2 = 单条证据直接可判，选项少于 4 个；\n"
       "   3-4 = 需要简单比对/一步推理；\n"
       "   5-6 = 需要综合多条证据，或要套一条明确规则；\n"
       "   7-8 = 需要专业领域规则、多步推理，或证据需要甄别；\n"
       "   9-10 = 证据冲突/信息不全/存在合理歧义，专家也要斟酌。\n"
       "   如果模型答错了，请判断它是真的难，还是只是模型疏忽或领域不熟"
       "（后者不要因为答错就抬高难度）。\n"
       "2) 这道题是否合格：标准答案是否唯一正确、选项是否无歧义、信息是否足够作答。\n"
       '只输出 JSON：{"difficulty":1-10 的数字,"keep":true|false,"reason":"≤20字"}')


def adjudicate(tasks, probe_res, llm, state_path, conc, fresh):
    done = {} if fresh else load_state(state_path)
    todo = [t for t in tasks if t["id"] not in done]
    if done:
        print(f"      分档断点：已完成 {len(done)}，待做 {len(todo)}")
    if not todo:
        return done

    lock = threading.Lock()
    n = [0]

    def work(start):
        for i in range(start, len(todo), conc):
            t = todo[i]
            pr = probe_res.get(t["id"]) or {}
            verdict = "答对" if pr.get("correct") else "答错"
            opts = "\n".join(f"- {k}: {v}" for k, v in t["question"]["criteria"].items())
            user = (f"状态：\n{t['state'][:2500]}\n\n"
                    f"问题：{t['question']['instructions']}\n\n选项：\n{opts}\n\n"
                    f"标准答案：{t['expected']}\n"
                    f"模型表现：{verdict}（置信度 {pr.get('conf')}）")
            rec = {"difficulty": 5.0, "keep": True, "reason": ""}
            try:
                r = parse_json(llm.chat(SYS, user, 120))
                if r:
                    # 优先用 1-10 的连续难度分；兼容只给档位的老输出
                    if isinstance(r.get("difficulty"), (int, float)):
                        rec["difficulty"] = float(r["difficulty"])
                    elif r.get("tier") in TIERS:
                        rec["difficulty"] = {"easy": 1.5, "standard": 4.0,
                                             "judge": 6.5, "hard": 9.0}[r["tier"]]
                    if r.get("keep") is False:
                        rec["keep"] = False
                    rec["reason"] = (r.get("reason") or "")[:40]
            except Exception as e:  # noqa: BLE001
                rec["error"] = str(e)[:80]
            with lock:
                done[t["id"]] = rec
                n[0] += 1
                if n[0] % 100 == 0:
                    save_state(state_path, done)
                    print(f"      分档 {n[0]}/{len(todo)}")
    ths = [threading.Thread(target=work, args=(k,), daemon=True) for k in range(conc)]
    for t in ths:
        t.start()
    for t in ths:
        t.join()
    save_state(state_path, done)
    return done


# ================================================================ 3. 难度分与分层

WEIGHTS = {"wrong": 0.30, "conf": 0.20, "llm": 0.30, "length": 0.10, "options": 0.10}


def difficulty_score(t, adj):
    """连续难度分（0~1），五个信号加权。

    为什么不用 LLM 直接分档：四分类会把绝大多数题挤进同一档（你都看到了 83% 落在 standard）。
    改成 1-10 分再按分位数切，既保留"难度"的连续性，又能控制每档数量。
    """
    conf = t.get("probe_conf")
    conf = 0.5 if conf is None else float(conf)
    wrong = 0.0 if t.get("probe_correct") else 1.0
    llm = (float(adj.get("difficulty", 5.0)) - 1.0) / 9.0
    length = min(len(t.get("state") or "") / 3000.0, 1.0)
    nopt = min(max(len(t["labels"]) - 2, 0) / 4.0, 1.0)
    w = WEIGHTS
    return round(w["wrong"] * wrong + w["conf"] * (1 - conf) + w["llm"] * llm
                 + w["length"] * length + w["options"] * nopt, 4)


def assign_quantile(items, ratios):
    """在每个题型内部按难度分排序后按比例切四档 —— 保证每档数量可控。"""
    by_type = defaultdict(list)
    for t in items:
        by_type[t["question"]["type"]].append(t)
    for arr in by_type.values():
        arr.sort(key=lambda x: x["_score"])
        n = len(arr)
        bounds, acc = [], 0.0
        for r in ratios:
            acc += r
            bounds.append(min(n, int(round(n * acc / 100.0))))
        idx = 0
        for i, t in enumerate(arr):
            while idx < 3 and i >= bounds[idx]:
                idx += 1
            t["tier"] = TIERS[idx]


def assign_absolute(items, cuts):
    """固定阈值：cuts 形如 0.3,0.5,0.75（三刀切四段）。"""
    cs = [float(x) for x in cuts.split(",")]
    for t in items:
        s = t["_score"]
        t["tier"] = ("easy" if s < cs[0] else
                     "standard" if s < cs[1] else
                     "judge" if s < cs[2] else "hard")


# ================================================================ 4. 校验

def validate(tasks, cfg_req):
    types = Counter(t["question"]["type"] for t in tasks)
    tiers = Counter(t["tier"] for t in tasks)
    cells = Counter((t["question"]["type"], t["tier"]) for t in tasks)
    hard_choice = cells[("choice", "hard")]

    checks = []
    checks.append(("三型齐全", len(types) == 3,
                   f"{dict(types)}"))
    checks.append(("难度至少 2 档", len(tiers) >= 2, f"{dict(tiers)}"))
    checks.append((f"hard 档 choice ≥ {cfg_req['min_hard_choice']}",
                   hard_choice >= cfg_req["min_hard_choice"], f"{hard_choice} 条"))

    thin = [(f"{k[0]}/{k[1]}", v) for k, v in cells.items() if v < cfg_req["min_cell"]]
    checks.append((f"每个(题型×难度) ≥ {cfg_req['min_cell']}", not thin,
                   "；".join(f"{k}={v}" for k, v in thin[:6]) if thin else "全部达标"))

    # 均衡度：最大一档占比
    top_share = max(tiers.values()) / len(tasks) if tasks else 1.0
    checks.append(("无单档垄断（最大档 ≤ 70%）", top_share <= 0.7,
                   f"最大档占 {top_share:.0%}"))
    return {"types": dict(types), "tiers": dict(tiers),
            "cells": {f"{k[0]}/{k[1]}": v for k, v in sorted(cells.items())},
            "hard_choice": hard_choice, "checks": checks,
            "pass": all(c[1] for c in checks)}


# ================================================================ main

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default=os.path.join(HERE, "config.ini"))
    ap.add_argument("--src", required=True)
    ap.add_argument("--name", default="")
    ap.add_argument("--out", default="od_ready")
    ap.add_argument("--jev-base")
    ap.add_argument("--jev-model")
    ap.add_argument("--llm-base")
    ap.add_argument("--llm-model")
    ap.add_argument("--llm-key")
    ap.add_argument("--concurrency", type=int, default=8)
    ap.add_argument("--min-cell", type=int, default=20)
    ap.add_argument("--min-hard-choice", type=int, default=30)
    ap.add_argument("--scheme", default="quantile", choices=["quantile", "absolute"],
                    help="quantile=按难度分位数切（默认）；absolute=固定阈值")
    ap.add_argument("--ratios", default="30,30,20,20",
                    help="quantile 模式下四档比例 easy,standard,judge,hard")
    ap.add_argument("--cuts", default="0.3,0.5,0.75",
                    help="absolute 模式下的三个切点")
    ap.add_argument("--fresh", action="store_true")
    a = ap.parse_args()

    cp = configparser.ConfigParser(interpolation=None)
    if os.path.exists(a.config):
        cp.read(a.config, encoding="utf-8")
    jb = a.jev_base or E.cget(cp, "api", "base", "http://127.0.0.1:9900")
    jm = a.jev_model or E.cget(cp, "api", "model", "")
    je = E.cget(cp, "api", "endpoint", "/v1/systemone")
    lb = a.llm_base or E.cget(cp, "llm", "base", "")
    lm = a.llm_model or E.cget(cp, "llm", "model", "")
    lk = a.llm_key or E.cget(cp, "llm", "api_key", "")
    if not (lb and lm):
        raise SystemExit("需要 LLM：在 config.ini 的 [llm] 配置 base/model，或用 --llm-base/--llm-model")
    if not jm:
        raise SystemExit("需要探测模型：在 [api] model 配置，或用 --jev-model")

    u = urllib.parse.urlparse(jb)
    cfg = {"host": u.hostname, "port": u.port or 8000, "endpoint": je,
           "headers": {"Content-Type": "application/json"}, "timeout": 180,
           "model": jm}
    llm = LLM(lb, lm, lk, timeout=120)

    outdir = a.out if os.path.isabs(a.out) else os.path.join(HERE, a.out)
    os.makedirs(outdir, exist_ok=True)
    name = a.name or os.path.splitext(os.path.basename(a.src))[0]

    # 读入 + 规范化 + 去重
    src = a.src if os.path.isabs(a.src) else os.path.join(HERE, a.src)
    rows = [json.loads(l) for l in open(src, encoding="utf-8") if l.strip()]
    tasks, seen, dropped = [], set(), []
    for i, raw in enumerate(rows):
        t = E.normalize(raw, name, i)
        if not t:
            dropped.append({"line": i, "reason": "字段不完整"})
            continue
        if len(t["labels"]) < 2 or not (t["state"] or "").strip():
            dropped.append({"id": t["id"], "reason": "选项/状态为空"})
            continue
        sig = hashlib.sha256((t["state"] + t["question"]["instructions"] +
                              json.dumps(t["question"]["criteria"], sort_keys=True,
                                         ensure_ascii=False)).encode()).hexdigest()[:16]
        if sig in seen:
            dropped.append({"id": t["id"], "reason": "重复"})
            continue
        seen.add(sig)
        tasks.append(t)

    print(SEP)
    print(f"数据集 {name}：读入 {len(rows)}，可用 {len(tasks)}，丢弃 {len(dropped)}")
    print(f"探测模型 {jm} @ {jb}")
    print(f"分档模型 {lm} @ {lb}")
    print(SEP)

    print("\n[1/3] 探测（用被测模型跑一遍）")
    probe_res = probe(tasks, cfg, os.path.join(outdir, f".{name}.probe.json"),
                      a.concurrency, a.fresh)
    ok = sum(1 for r in probe_res.values() if r.get("ok"))
    correct = sum(1 for r in probe_res.values() if r.get("correct"))
    print(f"      成功 {ok}/{len(tasks)}，答对 {correct}（{correct/max(1,ok):.1%}）")

    print("\n[2/3] 分档 + 质检（LLM 逐题复核）")
    adj = adjudicate(tasks, probe_res, llm, os.path.join(outdir, f".{name}.tier.json"),
                     a.concurrency, a.fresh)

    # 合并 + 连续难度分
    kept, rejected = [], []
    for t in tasks:
        v = adj.get(t["id"]) or {}
        if v.get("keep") is False:
            rejected.append({"id": t["id"], "reason": v.get("reason") or "LLM 判不合格"})
            continue
        t["tier_reason"] = v.get("reason", "")
        t["probe_correct"] = (probe_res.get(t["id"]) or {}).get("correct")
        t["probe_conf"] = (probe_res.get(t["id"]) or {}).get("conf")
        t["llm_difficulty"] = float(v.get("difficulty", 5.0))
        t["_score"] = difficulty_score(t, v)
        kept.append(t)

    # 分层：分位数（均衡）或固定阈值
    if a.scheme == "quantile":
        ratios = [float(x) for x in a.ratios.split(",") if x.strip()]
        if len(ratios) != 4:
            raise SystemExit("--ratios 需要 4 个数，如 30,30,20,20")
        s = sum(ratios)
        ratios = [r * 100.0 / s for r in ratios]
        assign_quantile(kept, ratios)
        print(f"      分层方式：按题型内部难度分位数 {ratios}%")
    else:
        assign_absolute(kept, a.cuts)
        print(f"      分层方式：固定阈值 {a.cuts}")

    # 回验：各档探测准确率应单调下降
    by_tier = defaultdict(list)
    for t in kept:
        by_tier[t["tier"]].append(t)
    tier_acc = {}
    for k, arr in by_tier.items():
        accs = [1.0 if x["probe_correct"] else 0.0 for x in arr
                if x["probe_correct"] is not None]
        tier_acc[k] = (len(arr), sum(accs) / len(accs) if accs else None)
    seq = [tier_acc[k][1] for k in TIERS if k in tier_acc and tier_acc[k][1] is not None]
    monotonic = all(seq[i] >= seq[i + 1] - 0.03 for i in range(len(seq) - 1)) if len(seq) >= 2 else None

    print("\n[3/3] 校验")
    rep = validate(kept, {"min_cell": a.min_cell,
                          "min_hard_choice": a.min_hard_choice})
    for name_, ok_, detail in rep["checks"]:
        print(f"      {'✅' if ok_ else '❌'} {name_}：{detail}")
    if monotonic is not None:
        s = " → ".join(f"{k} {tier_acc[k][1]*100:.0f}%" for k in TIERS
                       if k in tier_acc and tier_acc[k][1] is not None)
        print(f"      {'✅' if monotonic else '❌'} 探测准确率随难度单调：{s}")

    out_path = os.path.join(outdir, f"{name}.jsonl")
    with open(out_path, "w", encoding="utf-8") as f:
        for t in kept:
            f.write(json.dumps({"id": t["id"], "state": t["state"],
                                "question": t["question"], "labels": t["labels"],
                                "expected": t["expected"], "tier": t["tier"],
                                "difficulty_score": t["_score"],
                                "llm_difficulty": t.get("llm_difficulty"),
                                "tier_reason": t.get("tier_reason", ""),
                                "probe_correct": t.get("probe_correct"),
                                "probe_conf": t.get("probe_conf")},
                               ensure_ascii=False) + "\n")
    with open(os.path.join(outdir, f"{name}.rejected.jsonl"), "w", encoding="utf-8") as f:
        for d in rejected + dropped:
            f.write(json.dumps(d, ensure_ascii=False) + "\n")

    md = [f"# 自动分档报告：{name}", "",
          f"- 探测模型：`{jm}`　分档模型：`{lm}`",
          f"- 输入 {len(rows)} 条 → 可用 {len(tasks)} → 通过质检 {len(kept)}"
          f"（拒 {len(rejected)}，格式丢弃 {len(dropped)}）",
          f"- 探测准确率：{correct}/{ok} = {correct/max(1,ok):.1%}",
          f"- 分层方式：**{a.scheme}**"
          + (f"（{a.ratios}）" if a.scheme == "quantile" else f"（切点 {a.cuts}）"), "",
          "## 分档依据", "",
          "难度分 = 0.30×答错 + 0.20×(1−置信) + 0.30×(LLM 1-10 归一分) "
          "+ 0.10×状态长度 + 0.10×选项数。", "",
          "## 分布", "",
          "| 难度 | 数量 | 探测准确率 |", "|---|---|---|"]
    for k in TIERS:
        if k in rep["tiers"]:
            n_, acc_ = tier_acc.get(k, (0, None))
            md.append(f"| {k} | {n_} | {'—' if acc_ is None else f'{acc_*100:.1f}%'} |")
    if monotonic is not None:
        md += ["", f"**单调性：{'✅ 准确率随难度下降（分档有效）' if monotonic else '❌ 准确率未随难度下降（分档可能无效）'}**"]
    md += ["", "| 题型 | 数量 |", "|---|---|"]
    for k, v in rep["types"].items():
        md.append(f"| {k} | {v} |")
    md += ["", "| 单元格 | 数量 |", "|---|---|"]
    for k, v in rep["cells"].items():
        md.append(f"| {k} | {v} |")

    md += ["", "## OD 测评要求校验", "", "| 检查项 | 结果 | 详情 |", "|---|---|---|"]
    for name_, ok_, detail in rep["checks"]:
        md.append(f"| {name_} | {'✅' if ok_ else '❌'} | {detail} |")
    md += ["", f"**结论：{'✅ 可用于 OD 口径测评' if rep['pass'] else '❌ 不满足 OD 测评要求'}**",
           "", "## ⚠️ 循环论证提醒", "",
           f"- 难度档是根据 `{jm}` 的对错由 LLM 复核得出的。"
           f"如果用同一模型 `{jm}` 在这份数据上报 Capability，tier 会贴着它的表现，"
           "分数被系统性放大。",
           "- **正确用法**：这份数据给**其他模型**测；或只把它当\"难度分层集\"，"
           "报告里注明 tier 的来源模型。", ""]
    rpt = os.path.join(outdir, f"{name}.分档报告.md")
    open(rpt, "w", encoding="utf-8").write("\n".join(md))
    print("\n" + "\n".join(md[:26]))
    print(f"\n产物：{out_path}\n报告：{rpt}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
