#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
run_all.py —— 一键测评：准确性(ACC) / 校准(ECE) / 一致性(TV)

流程
    1. 读 data/items.jsonl      → 逐条调模型 → 记 ACC / ECE / Brier / NLL
    2. 读 data/pairs.jsonl      → 原题 + 变体各调一次 → 记 TV / 翻转率
    3. 汇总评分，输出以模型名开头的报告

输出（results/<时间戳>/）
    <模型名>_REPORT.md     最终得分报告（含 scorecard）
    <模型名>_results.json  结构化结果
    <模型名>_scores.csv    各维度分数
    <模型名>_items.jsonl   逐条过程数据（延迟/预测/是否正确）
    <模型名>_wrong.jsonl   错例

用法
    python run_all.py                     # 全量
    python run_all.py --limit 300 --pairs 100
    python run_all.py --skip-consistency  # 只跑 ACC/ECE
"""

import argparse
import configparser
import http.client
import json
import math
import os
import re
import sys
import threading
import time
import urllib.parse
import urllib.request
from collections import Counter, defaultdict
from datetime import datetime

HERE = os.path.dirname(os.path.abspath(__file__))
SEP = "=" * 78

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:  # noqa: BLE001
    pass


# ================================================================ 配置

DEFAULTS = {
    "api": {"base": "http://127.0.0.1:9900", "endpoint": "/v1/systemone",
            "model": "", "api_key": "", "timeout": "120", "concurrency": "8"},
    "data": {"items": "data/items.jsonl", "pairs": "data/pairs.jsonl",
             "limit": "0", "pairs_limit": "0"},
    "run": {"out_dir": "results", "ece_bins": "15"},
}


def cget(cp, sec, key):
    v = cp.get(sec, key, fallback=None)
    return DEFAULTS[sec][key] if v is None else v


def resolve(p):
    return p if os.path.isabs(p) else os.path.join(HERE, p)


# ================================================================ HTTP

class Client:
    def __init__(self, host, port, headers, timeout):
        self.host, self.port, self.headers, self.timeout = host, port, headers, timeout
        self.conn = None

    def post(self, path, body):
        if self.conn is None:
            self.conn = http.client.HTTPConnection(self.host, self.port,
                                                   timeout=self.timeout)
        for attempt in (0, 1):
            try:
                self.conn.request("POST", path, body=body, headers=self.headers)
                r = self.conn.getresponse()
                return r.status, r.read()
            except Exception:  # noqa: BLE001
                try:
                    if self.conn:
                        self.conn.close()
                except Exception:  # noqa: BLE001
                    pass
                self.conn = None
                if attempt:
                    raise
                self.conn = http.client.HTTPConnection(self.host, self.port,
                                                       timeout=self.timeout)


def build_body(model, state, question, qid="q0"):
    return json.dumps({"model": model, "state": state,
                       "questions": {qid: {"type": question["type"],
                                           "instructions": question["instructions"],
                                           "criteria": question["criteria"]}}},
                      ensure_ascii=False).encode("utf-8")


def probs_of(raw, qid="q0"):
    j = json.loads(raw)
    ans = (j.get("answers") or {}).get(qid) or {}
    p = ans.get("probabilities")
    if isinstance(p, dict) and p:
        return {str(k): float(v) for k, v in p.items()}
    return None


# ================================================================ 指标

def wilson(k, n, z=1.96):
    if n == 0:
        return (0.0, 0.0)
    p = k / n
    d = 1 + z * z / n
    c = p + z * z / (2 * n)
    m = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n))
    return ((c - m) / d, (c + m) / d)


def ece_table(rows, nbins):
    if not rows:
        return 0.0, 0.0, []
    bins = [[] for _ in range(nbins)]
    for conf, ok in rows:
        bins[min(int(conf * nbins), nbins - 1)].append((conf, ok))
    tot = len(rows)
    ece = mce = 0.0
    table = []
    for i, b in enumerate(bins):
        if not b:
            table.append((i / nbins, (i + 1) / nbins, 0, 0, 0, 0))
            continue
        c = sum(x[0] for x in b) / len(b)
        a = sum(1 for x in b if x[1]) / len(b)
        g = abs(c - a)
        ece += g * len(b) / tot
        if len(b) >= 5:
            mce = max(mce, g)
        table.append((i / nbins, (i + 1) / nbins, len(b), c, a, g))
    return ece, mce, table


def cov_acc(rows, frac):
    if not rows:
        return 0.0
    s = sorted(rows, key=lambda x: -x[0])
    k = max(1, int(len(s) * frac))
    return sum(1 for _, ok in s[:k] if ok) / k


def tv(p, q):
    keys = set(p) & set(q)
    if not keys:
        return None
    return 0.5 * sum(abs(p[k] - q[k]) for k in keys)


def probability_ece(pairs, nbins):
    """概率校准误差：按预测概率分桶，比 平均预测 与 平均真值。

    pairs: [(p_pred, p_gold)]，只对"真值概率已知"的题（Sys1Cal）有意义。
    """
    if not pairs:
        return 0.0, []
    bins = [[] for _ in range(nbins)]
    for p, g in pairs:
        bins[min(int(p * nbins), nbins - 1)].append((p, g))
    tot = len(pairs)
    e = 0.0
    tab = []
    for i, b in enumerate(bins):
        if not b:
            tab.append((i / nbins, (i + 1) / nbins, 0, 0, 0, 0))
            continue
        mp = sum(x for x, _ in b) / len(b)
        mg = sum(y for _, y in b) / len(b)
        gap = abs(mp - mg)
        e += gap * len(b) / tot
        tab.append((i / nbins, (i + 1) / nbins, len(b), mp, mg, gap))
    return e, tab


# ================================================================ 批量调用

def run_batch(tasks, cfg, desc, on_progress=None):
    """tasks: [(uid, state, question)]；返回 {uid: record}"""
    host, port = cfg["host"], cfg["port"]
    out = {}
    lock = threading.Lock()
    done = [0]

    def work(start):
        cli = Client(host, port, cfg["headers"], cfg["timeout"])
        for i in range(start, len(tasks), cfg["conc"]):
            uid, state, q = tasks[i]
            body = build_body(cfg["model"], state, q)
            t0 = time.perf_counter()
            rec = {"uid": uid, "ms": 0.0, "ok": False}
            try:
                st, raw = cli.post(cfg["endpoint"], body)
                rec["status"] = st
                if 200 <= st < 300:
                    p = probs_of(raw)
                    if p:
                        rec["p"] = p
                        rec["ok"] = True
            except Exception as e:  # noqa: BLE001
                rec["error"] = f"{type(e).__name__}: {e}"
            rec["ms"] = round((time.perf_counter() - t0) * 1000, 1)
            with lock:
                out[uid] = rec
                done[0] += 1
                if on_progress and done[0] % 200 == 0:
                    on_progress(done[0], len(tasks))

    ths = [threading.Thread(target=work, args=(k,), daemon=True)
           for k in range(cfg["conc"])]
    for t in ths:
        t.start()
    for t in ths:
        t.join()
    return out


# ================================================================ 主流程

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default=os.path.join(HERE, "config.ini"))
    ap.add_argument("--base")
    ap.add_argument("--model")
    ap.add_argument("--api-key")
    ap.add_argument("--limit", type=int, default=-1)
    ap.add_argument("--pairs", type=int, default=-1)
    ap.add_argument("--items", help="覆盖 config 里的 items 路径")
    ap.add_argument("--pairs-file", help="覆盖 config 里的 pairs 路径")
    ap.add_argument("--concurrency", type=int, default=0)
    ap.add_argument("--skip-consistency", action="store_true")
    ap.add_argument("--out-dir")
    a = ap.parse_args()

    cp = configparser.ConfigParser(interpolation=None)
    if not os.path.exists(a.config):
        raise SystemExit(f"找不到配置文件：{a.config}")
    cp.read(a.config, encoding="utf-8")

    base = a.base or cget(cp, "api", "base")
    endpoint = cget(cp, "api", "endpoint")
    model = a.model or cget(cp, "api", "model")
    key = a.api_key or os.environ.get("JEV_API_KEY") or cget(cp, "api", "api_key")
    u = urllib.parse.urlparse(base)
    headers = {"Content-Type": "application/json", "Connection": "keep-alive"}
    if key:
        headers["Authorization"] = f"Bearer {key}"

    if not model:
        try:
            with urllib.request.urlopen(f"{base}/v1/models", timeout=8) as r:
                j = json.loads(r.read().decode("utf-8", "replace"))
            it = (j.get("data") or j.get("models") or [])
            model = (it[0].get("id") or it[0].get("name")) if it else ""
        except Exception:  # noqa: BLE001
            pass
    if not model:
        raise SystemExit("无法确定 model：请在 config.ini 的 [api] model 填写")

    cfg = {
        "base": base, "endpoint": endpoint, "model": model,
        "host": u.hostname, "port": u.port or 8000,
        "headers": headers, "timeout": float(cget(cp, "api", "timeout")),
        "conc": a.concurrency or int(cget(cp, "api", "concurrency")),
    }
    items_path = resolve(a.items) if a.items else resolve(cget(cp, "data", "items"))
    pairs_path = resolve(a.pairs_file) if a.pairs_file else resolve(cget(cp, "data", "pairs"))
    nbins = int(cget(cp, "run", "ece_bins"))
    limit = a.limit if a.limit >= 0 else int(cget(cp, "data", "limit"))
    pairs_limit = a.pairs if a.pairs >= 0 else int(cget(cp, "data", "pairs_limit"))

    slug = re.sub(r"[^\w.\-]+", "_", model)[:60]
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    outdir = os.path.join(a.out_dir or resolve(cget(cp, "run", "out_dir")),
                          f"{ts}_{slug}")
    os.makedirs(outdir, exist_ok=True)

    print(SEP)
    print(f"jev 通用能力测评  ACC / ECE / 一致性")
    print(f"  模型   : {model}")
    print(f"  服务   : {base}{endpoint}   并发 {cfg['conc']}")
    print(f"  准确性集: {items_path}")
    print(f"  一致性集: {pairs_path}")
    print(f"  输出   : {outdir}")
    print(SEP)

    # ---------- 1. ACC / ECE
    items = []
    with open(items_path, "r", encoding="utf-8") as f:
        for line in f:
            if line.strip():
                items.append(json.loads(line))
    if limit:
        items = items[:limit]
    print(f"[1/2] 准确性 + 校准：{len(items)} 条")

    tasks = [(it["item_id"], it["state"], it["question"]) for it in items]
    t0 = time.perf_counter()
    recs = run_batch(tasks, cfg, "acc", on_progress=lambda d, n: print(f"      {d}/{n}"))
    elapsed1 = time.perf_counter() - t0

    rows, proc = [], []
    fails = 0
    for it in items:
        r = recs.get(it["item_id"]) or {}
        gold = it["gold"]["label"]
        keys = list(it["question"]["criteria"].keys())
        correct = conf = brier = nll = None
        pred = None
        if r.get("ok"):
            p = r["p"]
            if set(p) == set(keys):
                vec = [p[k] for k in keys]
            elif len(p) == len(keys):
                vec = list(p.values())
            else:
                vec = None
            if vec:
                s = sum(vec) or 1.0
                vec = [x / s for x in vec]
                i = max(range(len(vec)), key=lambda k: vec[k])
                pred = keys[i]
                conf = vec[i]
                correct = (pred == gold)
                if gold in keys:
                    gi = keys.index(gold)
                    y = [1.0 if j == gi else 0.0 for j in range(len(vec))]
                    brier = sum((x - t) ** 2 for x, t in zip(vec, y))
                    nll = -math.log(max(vec[gi], 1e-12))
                rows.append((conf, correct))
        else:
            fails += 1
        proc.append({"item_id": it["item_id"], "src": it["src"], "task": it["task"],
                     "type": it["type"], "gold": gold, "pred": pred,
                     "conf": None if conf is None else round(conf, 4),
                     "correct": correct, "ms": r.get("ms")})

    n = len(rows)
    acc = sum(1 for _, c in rows if c) / n if n else 0.0
    lo, hi = wilson(sum(1 for _, c in rows if c), n)
    ece, mce, table = ece_table(rows, nbins)
    # 逐条 Brier / NLL
    briers, nlls = [], []
    for it in items:
        r = recs.get(it["item_id"]) or {}
        gold = it["gold"]["label"]
        keys = list(it["question"]["criteria"].keys())
        if not r.get("ok") or gold not in keys:
            continue
        p = r["p"]
        vec = [p[k] for k in keys] if set(p) == set(keys) else list(p.values())
        if len(vec) != len(keys):
            continue
        s = sum(vec) or 1.0
        vec = [x / s for x in vec]
        gi = keys.index(gold)
        y = [1.0 if j == gi else 0.0 for j in range(len(vec))]
        briers.append(sum((x - t) ** 2 for x, t in zip(vec, y)))
        nlls.append(-math.log(max(vec[gi], 1e-12)))
    brier = sum(briers) / len(briers) if briers else 0.0
    nll = sum(nlls) / len(nlls) if nlls else 0.0

    def group(field):
        g = defaultdict(list)
        for it in items:
            r = recs.get(it["item_id"]) or {}
            if r.get("ok") and it["gold"]["label"]:
                g[it.get(field)].append(it)
        res = {}
        for k, its in g.items():
            rr = []
            for it in its:
                keys = list(it["question"]["criteria"].keys())
                p = (recs.get(it["item_id"]) or {}).get("p") or {}
                if set(p) != set(keys) and len(p) != len(keys):
                    continue
                vec = [p[x] for x in keys] if set(p) == set(keys) else list(p.values())
                s = sum(vec) or 1.0
                vec = [x / s for x in vec]
                i = max(range(len(vec)), key=lambda z: vec[z])
                rr.append((vec[i], keys[i] == it["gold"]["label"]))
            if rr:
                res[str(k)] = {"n": len(rr),
                               "acc": round(sum(1 for _, c in rr if c) / len(rr), 4),
                               "ece": round(ece_table(rr, nbins)[0], 4)}
        return dict(sorted(res.items(), key=lambda x: -x[1]["n"]))

    by_type, by_src = group("type"), group("src")
    print(f"      ACC {acc:.4f}  ECE {ece:.4f}  失败 {fails}  用时 {elapsed1:.0f}s")

    # ---------- 1.5 真值概率保真度（Sys1Cal：gold 是程序算出来的精确概率）
    fid = {}
    exact_items = [it for it in items if (it.get("meta") or {}).get("exact")]
    if exact_items:
        tvs, maes, briers_f, binary = [], [], [], []
        for it in exact_items:
            r = recs.get(it["item_id"]) or {}
            if not r.get("ok"):
                continue
            keys = list(it["question"]["criteria"].keys())
            p = r["p"]
            if set(p) == set(keys):
                vec = [p[k] for k in keys]
            elif len(p) == len(keys):
                vec = list(p.values())
            else:
                continue
            s = sum(vec) or 1.0
            vec = [x / s for x in vec]
            pmap = dict(zip(it["gold"]["ids"], it["gold"]["probs"]))
            g = [pmap.get(k, 0.0) for k in keys]
            tvs.append(0.5 * sum(abs(a - b) for a, b in zip(vec, g)))
            maes.append(max(abs(a - b) for a, b in zip(vec, g)))
            briers_f.append(sum((a - b) ** 2 for a, b in zip(vec, g)))
            if len(vec) == 2:
                binary.append((vec[1], g[1]))
        if tvs:
            pece, ptab = probability_ece(binary, nbins) if binary else (0.0, [])
            fid = {
                "n": len(tvs),
                "tv": round(sum(tvs) / len(tvs), 4),
                "mae": round(sum(maes) / len(maes), 4),
                "brier": round(sum(briers_f) / len(briers_f), 4),
                "pece": round(pece, 4),
                "table": ptab,
            }
            print(f"      真值概率：TV {fid['tv']}  MAE {fid['mae']}  "
                  f"概率ECE {fid['pece']}  (n={fid['n']})")

    # ---------- 2. 一致性
    cons = {"n": 0, "mean_tv": None, "pass_rate": None, "flip_rate": None,
            "by_kind": {}, "pairs": []}
    if not a.skip_consistency and os.path.exists(pairs_path):
        pairs = []
        with open(pairs_path, "r", encoding="utf-8") as f:
            for line in f:
                if line.strip():
                    pairs.append(json.loads(line))
        by_id = {it["item_id"]: it for it in items}
        # 关键：pairs 只保留本次 items 里真的有的（--limit 调试时常见交集很小）
        total_pairs = len(pairs)
        pairs = [p for p in pairs if p["item_id"] in by_id]
        if len(pairs) < total_pairs:
            print(f"      pairs 原始 {total_pairs} 对，与本次 items 交集 {len(pairs)} 对"
                  f"（--limit 会缩小交集，正式跑请用全量）")
        if pairs_limit:
            pairs = pairs[:pairs_limit]
        print(f"[2/2] 一致性：{len(pairs)} 对")

        tasks = []
        for k, pr in enumerate(pairs):
            it = by_id.get(pr["item_id"])
            if not it:
                continue
            tasks.append((f"o{k}", it["state"], it["question"]))
            tasks.append((f"v{k}", pr["variant"]["state"], pr["variant"]["question"]))
        t1 = time.perf_counter()
        r2 = run_batch(tasks, cfg, "cons", on_progress=lambda d, n: print(f"      {d}/{n}"))
        elapsed2 = time.perf_counter() - t1

        tvs, flips, per_kind = [], 0, defaultdict(list)
        for k, pr in enumerate(pairs):
            o, v = r2.get(f"o{k}"), r2.get(f"v{k}")
            if not (o and v and o.get("ok") and v.get("ok")):
                continue
            d = tv(o["p"], v["p"])
            if d is None:
                continue
            tvs.append(d)
            per_kind[pr["kind"]].append(d)
            ko = max(o["p"], key=o["p"].get)
            kv = max(v["p"], key=v["p"].get)
            if ko != kv:
                flips += 1
            cons["pairs"].append({"item_id": pr["item_id"], "kind": pr["kind"],
                                  "tv": round(d, 4), "flip": ko != kv,
                                  "ms": o.get("ms", 0) + v.get("ms", 0)})
        if tvs:
            cons.update({
                "n": len(tvs),
                "mean_tv": round(sum(tvs) / len(tvs), 4),
                "p95_tv": round(sorted(tvs)[int(len(tvs) * 0.95) - 1], 4) if len(tvs) > 1 else round(tvs[0], 4),
                "pass_rate": round(sum(1 for x in tvs if x <= 0.05) / len(tvs), 4),
                "flip_rate": round(flips / len(tvs), 4),
                "by_kind": {k: {"n": len(v2), "mean_tv": round(sum(v2) / len(v2), 4),
                                "pass_rate": round(sum(1 for x in v2 if x <= 0.05) / len(v2), 4)}
                            for k, v2 in per_kind.items()},
            })
        print(f"      TV 均值 {cons['mean_tv']}  通过率 {cons['pass_rate']}  用时 {elapsed2:.0f}s")

    # ---------- 3. 评分
    s_acc = 50 * min(acc / 0.90, 1.0)
    s_ece = 30 * max(0.0, 1 - ece / 0.15)
    s_tv = 20 * max(0.0, 1 - (cons["mean_tv"] or 0) / 0.08) if cons["n"] else 0
    total = s_acc + s_ece + s_tv

    def verdict_lo(x, good, warn):
        """越小越好：ECE / TV"""
        return "✅" if x <= good else ("⚠️" if x <= warn else "❌")

    def verdict_hi(x, good, warn):
        """越大越好：ACC"""
        return "✅" if x >= good else ("⚠️" if x >= warn else "❌")

    lat = sorted(p["ms"] for p in proc if p.get("ms"))
    summary = {
        "model": model, "items": len(items), "n_scored": n, "failed": fails,
        "acc": round(acc, 4), "acc_ci95": [round(lo, 4), round(hi, 4)],
        "ece": round(ece, 4), "mce": round(mce, 4),
        "brier": round(brier, 4), "nll": round(nll, 4),
        "cov90_acc": round(cov_acc(rows, 0.9), 4),
        "cov95_acc": round(cov_acc(rows, 0.95), 4),
        "fidelity": fid,
        "consistency": cons,
        "latency_ms": {"p50": lat[len(lat) // 2] if lat else 0,
                       "p95": lat[int(len(lat) * 0.95) - 1] if lat else 0},
        "scores": {"acc": round(s_acc, 1), "ece": round(s_ece, 1),
                   "tv": round(s_tv, 1), "total": round(total, 1)},
    }

    json.dump(summary, open(os.path.join(outdir, f"{slug}_results.json"), "w",
                            encoding="utf-8"), ensure_ascii=False, indent=1)
    with open(os.path.join(outdir, f"{slug}_items.jsonl"), "w", encoding="utf-8") as f:
        for p in proc:
            f.write(json.dumps(p, ensure_ascii=False) + "\n")
    with open(os.path.join(outdir, f"{slug}_wrong.jsonl"), "w", encoding="utf-8") as f:
        for p in proc:
            if p.get("correct") is False:
                f.write(json.dumps(p, ensure_ascii=False) + "\n")
    with open(os.path.join(outdir, f"{slug}_scores.csv"), "w", encoding="utf-8") as f:
        f.write("dimension,metric,value,score\n")
        f.write(f"accuracy,acc,{acc:.4f},{s_acc:.1f}\n")
        f.write(f"calibration,ece,{ece:.4f},{s_ece:.1f}\n")
        if cons["n"]:
            f.write(f"consistency,mean_tv,{cons['mean_tv']},{s_tv:.1f}\n")
        f.write(f"total,score,,{total:.1f}\n")

    md = [f"# {model} 测评报告", "",
          f"> 生成时间 {datetime.now().strftime('%Y-%m-%d %H:%M')} ｜ "
          f"数据集 {os.path.basename(items_path)}（{len(items)} 条）｜ "
          f"一致性 {cons['n']} 对", "",
          "## 0. 总评分", "",
          "| 维度 | 指标 | 实测 | 得分 | 判定 |", "|---|---|---|---|---|",
          f"| 准确性 | ACC | {acc:.4f}（95% CI {lo:.3f}–{hi:.3f}） | "
          f"{s_acc:.1f}/50 | {verdict_hi(acc, 0.85, 0.70)} |",
          f"| 校准 | ECE | {ece:.4f} | {s_ece:.1f}/30 | "
          f"{verdict_lo(ece, 0.05, 0.10)} |",
          f"| 一致性 | TV 均值 | {cons['mean_tv'] if cons['n'] else '—'} | "
          f"{s_tv:.1f}/20 | "
          f"{verdict_lo(cons['mean_tv'], 0.05, 0.08) if cons['n'] else '—'} |",
          f"| **合计** | | | **{total:.1f}/100** | |", "",
          "> 评分口径：ACC 折算 50 分（0.90 满分）；ECE 折算 30 分（0 满分，0.15 归零）；"
          "TV 折算 20 分（0 满分，0.08 归零）。", "",
          "## 1. 准确性 / 校准", "",
          "| 指标 | 值 |", "|---|---|",
          f"| 计分条数 | {n} / {len(items)}（失败 {fails}） |",
          f"| ACC | {acc:.4f} |",
          f"| ECE | {ece:.4f} |",
          f"| MCE | {mce:.4f} |",
          f"| Brier | {brier:.4f} |",
          f"| NLL | {nll:.4f} |",
          f"| 覆盖 90% 的准确率 | {cov_acc(rows, 0.9):.4f} |",
          f"| 覆盖 95% 的准确率 | {cov_acc(rows, 0.95):.4f} |",
          f"| 延迟 p50 / p95 | {summary['latency_ms']['p50']:.0f} / "
          f"{summary['latency_ms']['p95']:.0f} ms |"]
    if fid:
        md += [f"| 真值概率 TV（n={fid['n']}） | {fid['tv']:.4f} | 与 Sys1Cal 精确金标比 |",
               f"| 真值概率 MAE | {fid['mae']:.4f} | 单项最大偏差均值 |",
               f"| 概率 ECE | {fid['pece']:.4f} | 分桶比 平均预测 vs 平均真值 |"]
    md += ["", "## 2. 分题型", "", "| 类型 | n | ACC | ECE |", "|---|---|---|---|"]
    for k, v in by_type.items():
        md.append(f"| {k} | {v['n']} | {v['acc']:.4f} | {v['ece']:.4f} |")
    md += ["", "## 3. 分来源", "", "| 来源 | n | ACC | ECE |", "|---|---|---|---|"]
    for k, v in by_src.items():
        md.append(f"| {k} | {v['n']} | {v['acc']:.4f} | {v['ece']:.4f} |")

    md += ["", "## 4. 可靠性表（置信度 vs 实际准确率）", "",
           "| 置信区间 | n | 平均置信 | 实际准确 | 偏差 |", "|---|---|---|---|---|"]
    for l, h, cnt, c, acc_b, g in table:
        if cnt:
            md.append(f"| {l:.2f}–{h:.2f} | {cnt} | {c:.3f} | {acc_b:.3f} | {g:.3f} |")

    if cons["n"]:
        md += ["", "## 5. 一致性", "",
               "| 变体 | 对数 | TV 均值 | 通过率(TV≤0.05) |", "|---|---|---|---|"]
        for k, v in cons["by_kind"].items():
            md.append(f"| {k} | {v['n']} | {v['mean_tv']:.4f} | {v['pass_rate']*100:.0f}% |")
        md += ["", f"- 整体 TV 均值 **{cons['mean_tv']}**，p95 {cons['p95_tv']}，"
                   f"通过率 {cons['pass_rate']*100:.0f}%，答案翻转率 {cons['flip_rate']*100:.0f}%"]

    md += ["", "## 6. 结论", ""]
    issues = []
    if acc < 0.70:
        issues.append("准确性低于 0.70，基本盘不成立")
    if ece > 0.10:
        issues.append("ECE 超过 0.10，概率不能直接用于自动放行")
    if cons["n"] and cons["mean_tv"] and cons["mean_tv"] > 0.08:
        issues.append("一致性偏差大，概率对选项顺序/措辞敏感")
    if fid and fid["tv"] > 0.10:
        issues.append(f"真值概率保真度差（TV {fid['tv']:.3f}），概率数值本身不可信")
    if issues:
        md += [f"- {x}" for x in issues]
    else:
        md += ["- 三项均在可用区间；可作为通用能力基线存档。"]
    md += ["", "## 7. 口径说明", "",
           "- ACC = argmax(概率) 与 gold label 比较；未归一化的返回先归一化再判。",
           "- ECE 对 one-hot(label) 计算，**不把 gold 的软分布当真实概率**。",
           "- TV = 0.5×Σ|p−q|，按选项 key 对齐；≤0.05 视为一致。",
           "- 失败条目（超时/非 200/无概率）不计入 ACC 分母，单独计数。", ""]

    rpt = os.path.join(outdir, f"{slug}_REPORT.md")
    open(rpt, "w", encoding="utf-8").write("\n".join(md))

    print("\n" + "\n".join(md[:20]))
    print(f"\n报告：{rpt}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
