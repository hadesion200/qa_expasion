#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
make_variants.py —— 生成一致性测评的成对变体（纯规则，不用模型）

输入：data/items.jsonl
输出：data/pairs.jsonl

两类变体
    order   把选项顺序打乱（gold 跟着重排）→ 答案应该基本不变
    repeat  同一条原样再问一遍          → 答案必须完全一致（确定性）

为什么先做这两类
    它们零成本、零语义风险，且能直接暴露"概率是不是伪概率"：
    一个对位置敏感的模型，换序后 TV 会明显大于 0。

用法：
    python make_variants.py --n 400
"""

import argparse
import json
import os
import random

HERE = os.path.dirname(os.path.abspath(__file__))


def permute(item, rng):
    keys = list(item["question"]["criteria"].keys())
    if len(keys) < 3:
        return None
    new_keys = keys[:]
    for _ in range(5):
        rng.shuffle(new_keys)
        if new_keys != keys:
            break
    else:
        return None
    crit = {k: item["question"]["criteria"][k] for k in new_keys}
    gold_ids = item["gold"]["ids"]
    pmap = dict(zip(gold_ids, item["gold"]["probs"]))
    new_gold = [pmap.get(k, 0.0) for k in new_keys]
    label = item["gold"]["label"]
    return {
        "state": item["state"],
        "question": {"type": item["question"]["type"],
                     "instructions": item["question"]["instructions"],
                     "criteria": crit},
        "gold": {"ids": new_keys, "probs": new_gold, "label": label,
                 "annotation": item["gold"]["annotation"]},
    }


def repr_pairs(items, rng, n):
    """同一 latent 题目的不同等价渲染（Sys1Cal）→ 表示一致性。"""
    groups = {}
    for it in items:
        lid = (it.get("meta") or {}).get("latent_id")
        if lid:
            groups.setdefault(lid, []).append(it)
    cand = [v for v in groups.values() if len(v) >= 2]
    rng.shuffle(cand)
    out = []
    for g in cand:
        if len(out) >= n:
            break
        a, b = rng.sample(g, 2)
        out.append({"item_id": a["item_id"], "kind": "repr",
                    "variant": {"state": b["state"], "question": b["question"],
                                "gold": b["gold"]}})
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--items", default=os.path.join(HERE, "data", "items.jsonl"))
    ap.add_argument("--out", default=os.path.join(HERE, "data", "pairs.jsonl"))
    ap.add_argument("--n", type=int, default=400, help="总变体对数")
    ap.add_argument("--repeat-frac", type=float, default=0.25,
                    help="其中多少比例是 repeat 变体")
    ap.add_argument("--mode", default="order", choices=["order", "repr", "both"],
                    help="order=换序+重复；repr=同题不同渲染；both=各出一半")
    ap.add_argument("--seed", type=int, default=20261110)
    a = ap.parse_args()

    items = []
    with open(a.items, "r", encoding="utf-8") as f:
        for line in f:
            if line.strip():
                items.append(json.loads(line))

    rng = random.Random(a.seed)
    pool = [it for it in items if len(it["question"]["criteria"]) >= 3]
    rng.shuffle(pool)

    # 两侧名额分开算，避免"选项不足 3 个"把 repr 名额也砍掉（Sys1Cal 全是二选一）
    n_order_target = 0 if a.mode == "repr" else (a.n if a.mode == "order" else a.n // 2)
    n_repr_target = a.n - n_order_target
    n_order_target = min(n_order_target, len(pool))

    n_repeat = min(int(n_order_target * a.repeat_frac), n_order_target // 2)
    pairs = []
    for it in pool[:n_order_target - n_repeat]:
        v = permute(it, rng)
        if v:
            pairs.append({"item_id": it["item_id"], "kind": "order", "variant": v})
    for it in pool[n_order_target - n_repeat:n_order_target]:
        pairs.append({"item_id": it["item_id"], "kind": "repeat",
                      "variant": {"state": it["state"],
                                  "question": it["question"],
                                  "gold": it["gold"]}})
    if n_repr_target > 0:
        pairs += repr_pairs(items, rng, n_repr_target)

    with open(a.out, "w", encoding="utf-8") as f:
        for p in pairs:
            f.write(json.dumps(p, ensure_ascii=False) + "\n")

    kinds = {}
    for p in pairs:
        kinds[p["kind"]] = kinds.get(p["kind"], 0) + 1
    print(f"生成 {len(pairs)} 对变体 → {os.path.abspath(a.out)}")
    print("分布:", kinds)


if __name__ == "__main__":
    main()
