# jev 通用能力测评包（ACC / ECE / 一致性）

一个 `config.ini` 配好 API，`python run_all.py` 一键跑完，输出以**模型名开头**的得分报告。

## 目录

```
jev_eval_kit/
├── config.ini            # 唯一需要改的文件（API + 数据路径 + 并发）
├── run_all.py            # 一键入口：ACC/ECE/真值概率 + 一致性 → 报告
├── make_variants.py      # 生成一致性变体（换序/重复/等价渲染，纯规则）
├── build_set.py          # 从原始公开数据重建 items.jsonl（需要 pyarrow，一般不用跑）
├── data/
│   ├── items.jsonl       # 7,352 条统一评测集（已随包提供）
│   ├── pairs.jsonl       # 342 对一致性变体（已随包提供）
│   ├── items_smoke.jsonl # 150 条冒烟集
│   ├── pairs_smoke.jsonl # 40 对冒烟变体
│   └── manifest.json     # 数据指纹与分布
└── results/              # 运行产物
```

## 一键运行

```bash
# 1) 只改 config.ini 的 [api] 段
#    base / endpoint / model / api_key

# 2) 跑
python run_all.py
```

调试时缩小规模：

```bash
python run_all.py --limit 300 --pairs 100
python run_all.py --skip-consistency        # 只跑 ACC/ECE
```

## 产物

`results/<时间戳>_<模型名>/` 下：

| 文件 | 内容 |
|---|---|
| `<模型名>_REPORT.md` | **最终得分报告**（scorecard + 分题型 + 可靠性表 + 一致性 + 结论） |
| `<模型名>_results.json` | 结构化结果，便于入库对比 |
| `<模型名>_scores.csv` | 各维度分数，一行一个指标 |
| `<模型名>_items.jsonl` | 逐条过程数据：gold / pred / conf / 是否正确 / 延迟 |
| `<模型名>_wrong.jsonl` | 错例清单，拿去人工看 |

## 评分口径

| 维度 | 指标 | 满分 | 折算方式 | ✅ / ⚠️ / ❌ |
|---|---|---|---|---|
| 准确性 | ACC | 50 | `50 × min(ACC/0.90, 1)` | ≥0.85 / ≥0.70 / <0.70 |
| 校准 | ECE | 30 | `30 × max(0, 1 − ECE/0.15)` | ≤0.05 / ≤0.10 / >0.10 |
| 一致性 | TV 均值 | 20 | `20 × max(0, 1 − TV/0.08)` | ≤0.05 / ≤0.08 / >0.08 |

此外还有**两项不计分但必须看**的指标（只对有真值概率的 Sys1Cal 计算）：

| 指标 | 含义 | 门槛 |
|---|---|---|
| 真值概率 TV / MAE | 预测分布与**精确金标**的差 | ≤0.10 |
| 概率 ECE | 按预测概率分桶，比「平均预测」与「平均真值」 | ≤0.05 |

> 标签型 ECE 回答“置信度能不能用来放行”，真值概率 TV 回答“概率数值本身对不对”。
> 两者都过，概率才可信。

阈值可在 `run_all.py` 顶部 `verdict_*` 调用处改。

## 数据说明

`items.jsonl` 由四路公开数据转成统一格式（一行 = 一个决策）：

| 来源 | 条数 | 说明 |
|---|---|---|
| s1mb | 5,887 | 106 个任务，以 hard_label 为主，覆盖 NLI / 阅读理解 / 安全 / 控制类任务 |
| jev-distill-corpus-v3 | 800 | choice / noul / score 三题型，`target` 是软分布 |
| TruthfulQA | 300 | mc1，事实性 |
| **Sys1Cal-v1** | **365** | **真值概率由程序精确给定**，同一 latent 题有 3~6 种等价渲染 |

`pairs.jsonl` 三类变体：

| kind | 对数 | 含义 |
|---|---|---|
| order | 188 | 选项换序，答案应不变 |
| repeat | 62 | 同题重复，答案必须一致（确定性） |
| **repr** | **92** | **同 latent 题的不同渲染**（direct/counts/table/prose…），答案应等价 |

口径要点：

- **ECE 一律对 one-hot(label) 算**——gold 的软分布是标注/教师信心，不是真实概率。
- 只有 Sys1Cal 的 `annotation="exact"` 才做**真值概率**比对（TV / MAE / 概率 ECE），
  其余数据没有真值概率，不做这一项。
- 失败条目（超时/非 200/无概率）不计入 ACC 分母，单独计数。
- TV 按选项 key 对齐，≤0.05 视为一致。

## 重建数据（一般不需要）

```bash
python build_set.py --root "<DataBase 目录>" \
    --limit-s1mb 30 --limit-distill 800 --limit-tqa 300
python make_variants.py --n 500 --mode both     # order + repeat + repr
```

`build_set.py` 需要 `pyarrow`；`run_all.py` 与 `make_variants.py` 只用标准库。
