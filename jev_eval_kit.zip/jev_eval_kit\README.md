# jev 数据改造工具

把任意 jsonl 变成**「OD 可测」数据集**：jev 模型探测 + LLM 复核，联合定难度、做质检、分档、校验。
**这里只产数据，不打分。**

## 一条命令

```bash
# 改 config.ini 的 [api]（jev）和 [llm]（辅助模型），然后：
python prepare/build_dataset.py --src data/xxx.jsonl --name mydata
```

产物在 `od_ready/`：

| 文件 | 内容 |
|---|---|
| `mydata.jsonl` | **OD 数据集**：`id/state/question/labels/expected/tier[/target_probs]` |
| `mydata.报告.md` | 分布、校验清单、结论 |
| `mydata.rejected.jsonl` | 被筛掉的条目及原因 |
| `mydata.probe.jsonl` | 探测模型的逐条表现（单独放，不进数据集） |
| `mydata.balanced.jsonl` | `--balance` 时的均衡子集 |

## 三种模式

| 模式 | 用谁 | 适用 |
|---|---|---|
| `--mode assisted`（默认） | jev 探测 + LLM 复核 | 最准；注意循环论证（见下） |
| `--mode llm` | 只 LLM | 给**别的模型**准备数据时用，不依赖被测模型 |
| `--mode rules` | 都不调 | 最快，纯启发式（长度/选项数/关键词） |

```bash
python prepare/build_dataset.py --src ... --mode llm        # 不碰 jev
python prepare/build_dataset.py --src ... --mode rules      # 完全离线
```

## 难度怎么定

**assisted**：先让 jev 跑一遍拿「对错 + 置信度」，再让 LLM 给 1–10 连续难度分，合成：

```
难度分 = 0.30×答错 + 0.20×(1−置信) + 0.30×(LLM 归一) + 0.10×长度 + 0.10×选项数
```

**llm**：去掉前两项，`0.50×LLM + 0.25×长度 + 0.25×选项数`。

**rules**：直接按长度/选项数/关键词分四档。

然后用**分位数**切（默认 30/30/20/20），保证每档数量可控：

```bash
--scheme quantile --ratios 30,30,20,20
--scheme absolute --cuts 0.3,0.5,0.75     # 跨数据集比较时用固定阈值
```

## 校验（决定能不能用 OD 口径）

```
| 三型齐全 | ✅ |
| 难度至少 2 档 | ✅ |
| hard 档 choice ≥ 30 | ✅ |
| 每个(题型×难度) ≥ 20 | ✅ |
| 无单档垄断（最大档 ≤ 70%） | ✅ |
```

全绿才算“可用于 OD 口径测评”；报告里会直接写结论。

另外还会回验「探测准确率是否随难度下降」——不单调说明分档可能无效。

## 均衡子集

```bash
--balance cap                     # 完全均衡：取最小格，N = 最小格 × 格数
--balance target --per-cell 60    # 每格最多 60 条（小格全留，不完全均衡）
```

报告会给出**理论最大完全均衡子集** = 最小格 × 格数，以及实际产出。

## 两个必须知道的点

1. **assisted 模式有循环论证**：难度档含 jev 的对错信号，用**同一个模型**在这份数据上报分会虚高。
   给别的模型测，或改用 `--mode llm`。
2. **数据集不掺模型输出**：探测结果只进 `<name>.probe.jsonl`，
   `mydata.jsonl` 里只有题目/标签/难度，换任何模型都能复用。

## 400 排查

服务端对 `noul`/`score` 的请求形状要求不同，整类题全挂时先探测：

```bash
python prepare/probe_api.py --data data/xxx.jsonl
```

`build_dataset.py` 内置了同样的形状自动回退，通常不用手动指定。

## 目录

```
jev_eval_kit/
├── config.ini
├── prepare/
│   ├── build_dataset.py   # 唯一入口
│   ├── jevio.py           # 公共件（normalize / HTTP / LLM）
│   └── probe_api.py       # 请求形状探测
└── od_ready/              # 产物
```
