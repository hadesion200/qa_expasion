# jev 决策模型评测包

一套评测，两条命令：

```bash
# 1) 改 config.ini 的 [api]（base / endpoint / model / api_key）
# 2) 跑
python run_eval.py
```

产物在 `results/<模型名>/`，文件名就是模型名。

## 结构

```
jev_eval_kit/
├── config.ini        # 唯一需要改的文件
├── run_eval.py       # 唯一入口：OpenDecisions + 一致性
├── od/               # OpenDecisions 官方原件，未改一行
│   ├── opendecisions.jsonl   2,352 题
│   ├── score.py              官方 scorer（MIT）
│   ├── run_od.py             适配器：题目 → 本地 Jev API → predictions.jsonl
│   └── OFFICIAL_README.md
└── results/<模型名>/
    ├── <模型名>.md           合并报告
    ├── <模型名>.json         结构化结果
    └── od/                   OD 明细（predictions.jsonl 等）
```

## 为什么是这一套

| 维度 | 用什么 | 理由 |
|---|---|---|
| 准确性 / 校准 | **OpenDecisions 官方 scorer** | 官方 pinned 版本、可复现、能和榜单横向比；自带 tier 加权、chance 校正、hard 档校准、真概率 TVD |
| 一致性 | 本包补充（换序 / 重复） | OpenDecisions **没有**这一维度；只报原始统计量（TV 均值、通过率），不折算成分数 |

之前那套「ACC/ECE + 100 分加权」已删除——权重是自己配的，跟任何榜单都不可比。

## 三项分数的含义（官方口径）

```
Capability   = (Intelligence + Calibration) / 2
Intelligence = 相对随机基线的能力；tier 权重 easy .1 / standard .2 / judge .3 / hard .4
Calibration  = 概率分桶偏差；choice 只统计 hard 档
```

**Capability 不是准确率**，别当百分比读。

## 一致性怎么读

| 指标 | 含义 | 参考阈值 |
|---|---|---|
| TV 均值 | 两次回答的概率分布差（0 = 完全一致） | ≤ 0.05 算一致 |
| 通过率 | TV ≤ 0.05 的对数占比 | 越高越稳 |
| 翻转率 | argmax 变了的比例 | 越低越好 |

- `换序`：打乱选项顺序，答案应基本不变。
- `重复`：同题问两遍，答案必须完全一致（确定性）。这一项若不为 0，说明采样没关。

## 常用参数

```bash
python run_eval.py --od-limit 60 --pairs 20    # 冒烟（按题型分层，含 hard 档）
python run_eval.py --skip-consistency          # 只跑 OD
python run_eval.py --skip-od --pairs 200       # 只补一致性
python run_eval.py --fresh                     # 忽略断点
```

断点：OD 的 `od/predictions.state.json`、一致性的临时结果都会保留，重跑自动接着做。

## 单独跑官方 scorer

```bash
python od/score.py results/<模型名>/od/predictions.jsonl --data od/opendecisions.jsonl
```

输出与 `run_eval.py` 里的三项分完全一致。

## 注意

- `--od-limit` 会按题型分层抽样并强制包含 hard 档 choice，否则官方 Calibration 可能算不出来（显示 `—`）。
- 没预测的条目按错处理（官方约定）；网络失败会体现在 `预测覆盖 x/2352`。
- 官方 scorer 只读 `{"id", "probs"}`，所以换成任何能返回选项概率的服务都能跑，不只 Jev。
