# Jev 数据集测评

改 `config.ini` 里的 API，执行 `./run.sh`，`datasets/` 下所有 `*.jsonl` 会被依次测评，
结果写到 `results/<模型名>/`，文件名就是模型名。

## 快速开始

```bash
# 1) 改 config.ini 的 [api]（base / endpoint / model / api_key）
# 2) 一键跑
./run.sh

# 冒烟（每个数据集 40 条，均匀抽样）
./run.sh --limit 40

# 只跑一个文件
./run.sh --dataset opendecisions.jsonl

# 忽略断点重跑
./run.sh --fresh
```

> Windows 上在 Git Bash / WSL 里跑 `bash run.sh`；或直接 `python evaluate.py`。

## 目录

```
jev_eval_kit/
├── config.ini        # 唯一需要改的文件
├── run.sh            # 一键入口
├── evaluate.py       # 主程序：扫 datasets → 调 API → 打分 → 出报告
├── datasets/         # 放 *.jsonl（已含 OpenDecisions 2,352 题）
├── od/score.py       # OpenDecisions 官方 scorer（原样，MIT）
└── results/<模型名>/
    ├── <模型名>.md      报告
    ├── <模型名>.json    完整数据（含每条可靠性/一致性明细）
    ├── <模型名>.csv     汇总表
    └── .state/          断点，每个数据集一个文件
```

## 数据集格式

一行一个 JSON。最少只要 `state` + `question` + 标签，字段会自动兜底：

```jsonc
// 形态 1：OpenDecisions 原生
{"id": "...", "state": "...", "question": {"type":"choice","instructions":"...","criteria":{...}},
 "labels": ["a","b","c"], "expected": "b", "tier": "hard", "target_probs": null}

// 形态 2：question 是字符串 + options 列表 + target 概率（jev-distill 风格）
{"id": "...", "state": "...", "question": "...", "options": ["0","1","2"], "target": [0.1,0.7,0.2]}

// 形态 3：Gold 用 answer / gold / label 任一字段
{"id": "...", "state": "...", "question": {"type":"noul","instructions":"...","criteria":{...}}, "gold": "yes"}
```

| 字段 | 必需 | 说明 |
|---|---|---|
| `state` | ✅ | 判断对象 |
| `question` | ✅ | 字符串或 `{type, instructions, criteria}` |
| `labels` | 可推导 | 缺省用 `criteria` 的 key |
| `expected` / `answer` / `gold` / `label` | ✅ 之一 | 标准答案 |
| `tier` | 可选 | `easy/standard/judge/hard`，缺省 `standard` |
| `target_probs` / `target` | 可选 | 已知真概率 → 额外报 TVD |

解析不了的条目会被跳过（不会报错中断）。

## 报告怎么读

**总览**：每个数据集一行，最后一列是覆盖（`预测 x/y`），覆盖不足说明有超时/失败。

**三项分**（官方 `score.py` 计算）：

```
Capability   = (Intelligence + Calibration) / 2
Intelligence = 相对随机基线的能力；题型内按 tier 加权（easy .1 / standard .2 / judge .3 / hard .4）
Calibration  = 概率分桶偏差；choice 只统计 hard 档
```

⚠️ Capability **不是准确率**。准确率在下面的分题型表里。

**分题型表**：`准确率` 是原始命中率，`能力` 已扣掉随机猜对的基线，`校准` 是概率可信度。
三者经常差很多——准确率高但能力低，说明题偏简单；能力高但校准低，说明概率不能直接拿去卡阈值。

**可靠性表**：按模型自报置信度分桶，看「平均置信」与「实际准确」差多少。差得越大，说明它越"自信但错"。

**一致性**（官方没有，本包补）：

| 变体 | 含义 |
|---|---|
| 换序 | 打乱选项顺序，答案应基本不变（TV ≤ 0.05） |
| 重复 | 同题问两遍，必须完全一致（TV 应为 0） |

换序 TV 大 = 位置偏置；重复 TV 不为 0 = 采样没关/服务端非确定性。

## 断点续跑

每 50 条落一次盘到 `results/<模型名>/.state/<数据集>.json`，中断后重跑同一条命令自动接着做：

```
[opendecisions.jsonl]
      2352 条
      断点续跑：已完成 1200，本次待做 1152
```

`--fresh` 或删掉 `.state/` 即从头开始。

## 常用参数

| 参数 | 作用 |
|---|---|
| `--limit N` | 每个数据集均匀抽 N 条（不是取前 N 条，避免只覆盖一类） |
| `--pairs N` | 每个数据集的一致性对数（默认取 config） |
| `--concurrency N` | 并发数 |
| `--dataset name.jsonl` | 只跑一个 |
| `--fresh` | 忽略断点 |
