# Jev 数据集测评

改 `config.ini` 里的 API，执行 `./run.sh`，`datasets/` 下所有 `*.jsonl` 会被依次测评，
结果写到 `results/<模型名>/`，文件名就是模型名。

## 快速开始

```bash
# 1) 改 config.ini 的 [api]（base / endpoint / model / api_key）
# 2) 一键跑
./run.sh

# 冒烟（每个数据集 40 条，均匀抽样）
./run.sh --limit 40

# 只跑一个文件
./run.sh --dataset opendecisions.jsonl

# 忽略断点重跑
./run.sh --fresh
```

> Windows 上在 Git Bash / WSL 里跑 `bash run.sh`；或直接 `python evaluate.py`。

## 目录

```
jev_eval_kit/
├── config.ini        # 唯一需要改的文件
├── run.sh            # 一键入口
├── evaluate.py       # 主程序：扫 datasets → 调 API → 打分 → 出报告
├── datasets/         # 放 *.jsonl（已含 OpenDecisions 2,352 题）
├── od/score.py       # OpenDecisions 官方 scorer（原样，MIT）
└── results/<模型名>/
    ├── <模型名>.md      报告
    ├── <模型名>.json    完整数据（含每条可靠性/一致性明细）
    ├── <模型名>.csv     汇总表
    └── .state/          断点，每个数据集一个文件
```

## 数据集格式

一行一个 JSON。最少只要 `state` + `question` + 标签，字段会自动兜底：

```jsonc
// 形态 1：OpenDecisions 原生
{"id": "...", "state": "...", "question": {"type":"choice","instructions":"...","criteria":{...}},
 "labels": ["a","b","c"], "expected": "b", "tier": "hard", "target_probs": null}

// 形态 2：question 是字符串 + options 列表 + target 概率（jev-distill 风格）
{"id": "...", "state": "...", "question": "...", "options": ["0","1","2"], "target": [0.1,0.7,0.2]}

// 形态 3：Gold 用 answer / gold / label 任一字段
{"id": "...", "state": "...", "question": {"type":"noul","instructions":"...","criteria":{...}}, "gold": "yes"}
```

| 字段 | 必需 | 说明 |
|---|---|---|
| `state` | ✅ | 判断对象 |
| `question` | ✅ | 字符串或 `{type, instructions, criteria}` |
| `labels` | 可推导 | 缺省用 `criteria` 的 key |
| `expected` / `answer` / `gold` / `label` | ✅ 之一 | 标准答案 |
| `tier` | 可选 | `easy/standard/judge/hard`，缺省 `standard` |
| `target_probs` / `target` | 可选 | 已知真概率 → 额外报 TVD |

解析不了的条目会被跳过（不会报错中断）。

## 报告怎么读

报告分**两套指标**，因为 OD 的公式对数据分布有前提。

### 通用指标（任何数据集都能算）

| 指标 | 含义 |
|---|---|
| 准确率 | argmax 命中率，按题型拆分 |
| 平均置信度 | top-label 概率的均值 |
| ECE | 置信度 vs 实际准确率的分桶偏差（10 桶） |
| Brier / NLL | 概率质量指标 |
| 覆盖 90% 的准确率 | 只放行最有把握的 90% |

这套与数据分布无关，`dft_gen/out/train.jsonl` 这种没有 tier 的普通数据集也照样算、照样横向比。

### OD 口径（有前提）

```
Capability = (Intelligence + Calibration) / 2
Intelligence = 相对随机基线的能力；题型内按 tier 加权（easy .1 / standard .2 / judge .3 / hard .4）
Calibration  = 分桶偏差；choice 只统计 hard 档
```

只有满足下面三条才显示，否则标 `—` 并写明缺什么：

1. 三型齐全（choice / noul / score）
2. 有难度分层（至少 2 档 tier）
3. hard 档 choice ≥ 30 条

三种状态：`ok`（可比）、`weak`（样本不足，标 `*`，仅供参考）、`na`（不适用）。

> 为什么卡这么严：`_weighted` 只对"出现过的"题型/难度归一化。缺型时"三型平均"会变成"单型分数"；
> 没有 tier 时难度加权退化成等权；没有 hard choice 时 Calibration 的 choice 项直接缺失。
> 这些情况下数字仍算得出来，但**不可比**。

### 一致性（官方没有，本包补）

| 变体 | 含义 |
|---|---|
| 换序 | 打乱选项顺序，答案应基本不变（TV ≤ 0.05） |
| 重复 | 同题问两遍，必须完全一致（TV 应为 0） |

换序 TV 大 = 位置偏置；重复 TV 不为 0 = 采样没关/服务端非确定性。

## 断点续跑

每 50 条落一次盘到 `results/<模型名>/.state/<数据集>.json`，中断后重跑同一条命令自动接着做：

```
[opendecisions.jsonl]
      2352 条
      断点续跑：已完成 1200，本次待做 1152
```

`--fresh` 或删掉 `.state/` 即从头开始。

## 常用参数

| 参数 | 作用 |
|---|---|
| `--limit N` | 每个数据集均匀抽 N 条（不是取前 N 条，避免只覆盖一类） |
| `--pairs N` | 每个数据集的一致性对数（默认取 config） |
| `--concurrency N` | 并发数 |
| `--dataset name.jsonl` | 只跑一个 |
| `--fresh` | 忽略断点 |
