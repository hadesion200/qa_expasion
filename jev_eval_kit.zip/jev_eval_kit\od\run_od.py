#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
run_od.py —— 用本地 Jev API 跑 OpenDecisions（官方口径）

为什么不是改 predict_letters.py
    官方 predict_letters.py 面向"聊天模型"：把题渲染成 A/B/C 选项，读字母 token 的 logits，
    再 softmax 成概率。本地 Jev 是 typed decision API，**直接返回 criteria 上的概率**，
    跳掉字母映射更准、更省一次前向。所以这里只做"同一道题 → 同样的 probs 格式"，
    然后原样调用官方 score.py（不改一行），保证分数口径与榜单一致。

流程
    od/opendecisions.jsonl  →(本脚本调 API)→  predictions.jsonl  →(官方 score.py)→ 三项分数

用法
    python od/run_od.py                  # 全量 2352 条
    python od/run_od.py --limit 50       # 冒烟
    python od/run_od.py --fresh          # 忽略断点重跑
    python od/run_od.py --data od/opendecisions.jsonl --out-dir results

产物（results/<模型名>/od/）
    <模型名>.md                报告（含三项分数）
    <模型名>.json              官方 score.py 的完整输出
    predictions.jsonl          逐条预测，可直接喂 score.py
    predictions.state.json     断点
"""

import argparse
import configparser
import http.client
import json
import os
import re
import sys
import threading
import time
import urllib.parse
import urllib.request
from datetime import datetime

HERE = os.path.dirname(os.path.abspath(__file__))
KIT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
import score as official  # noqa: E402  官方 scorer，原样使用

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:  # noqa: BLE001
    pass

SEP = "=" * 78


# ================================================================ 配置

def cget(cp, sec, key, default):
    v = cp.get(sec, key, fallback=None)
    return default if v is None else v


# ================================================================ HTTP

class Client:
    def __init__(self, host, port, headers, timeout):
        self.host, self.port, self.headers, self.timeout = host, port, headers, timeout
        self.conn = None

    def post(self, path, body):
        if self.conn is None:
            self.conn = http.client.HTTPConnection(self.host, self.port, timeout=self.timeout)
        for attempt in (0, 1):
            try:
                self.conn.request("POST", self.path_or(path), body=body, headers=self.headers)
                r = self.conn.getresponse()
                return r.status, r.read()
            except Exception:  # noqa: BLE001
                try:
                    if self.conn:
                        self.conn.close()
                except Exception:  # noqa: BLE001
                    pass
                self.conn = None
                if attempt:
                    raise
                self.conn = http.client.HTTPConnection(self.host, self.port,
                                                       timeout=self.timeout)

    @staticmethod
    def path_or(p):
        return p


def to_probs(ans, task):
    """把 API 返回的概率对齐到官方 labels；noul 统一成 yes/no。"""
    p = (ans or {}).get("probabilities")
    if not isinstance(p, dict) or not p:
        return None
    p = {str(k): float(v) for k, v in p.items()}
    t = task["question"]["type"]
    labels = list(task.get("labels") or [])

    if t == "noul":
        for k in ("yes", "true", "1", "True"):
            if k in p:
                py = p[k]
                return {"yes": py, "no": 1.0 - py}
        if len(p) == 2:                                  # 按顺序兜底
            vals = list(p.values())
            return {"yes": vals[0], "no": vals[1]}
        return None

    if set(p) == set(labels):
        vals = {k: p[k] for k in labels}
    elif len(p) == len(labels):                          # key 被服务端改写，按顺序对齐
        vals = dict(zip(labels, p.values()))
    else:
        return None
    s = sum(vals.values())
    if s <= 0:
        return None
    return {k: v / s for k, v in vals.items()}


# ================================================================ 主流程

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default=os.path.join(KIT, "config.ini"))
    ap.add_argument("--data", default=os.path.join(HERE, "opendecisions.jsonl"))
    ap.add_argument("--base")
    ap.add_argument("--model")
    ap.add_argument("--api-key")
    ap.add_argument("--limit", type=int, default=0)
    ap.add_argument("--concurrency", type=int, default=0)
    ap.add_argument("--out-dir")
    ap.add_argument("--fresh", action="store_true")
    a = ap.parse_args()

    cp = configparser.ConfigParser(interpolation=None)
    if os.path.exists(a.config):
        cp.read(a.config, encoding="utf-8")
    base = a.base or cget(cp, "api", "base", "http://127.0.0.1:9900")
    endpoint = cget(cp, "api", "endpoint", "/v1/systemone")
    model = a.model or cget(cp, "api", "model", "")
    key = a.api_key or os.environ.get("JEV_API_KEY") or cget(cp, "api", "api_key", "")
    timeout = float(cget(cp, "api", "timeout", "120"))
    conc = a.concurrency or int(cget(cp, "api", "concurrency", "8"))

    u = urllib.parse.urlparse(base)
    if not u.hostname:
        raise SystemExit(f"base 不合法：{base}")
    headers = {"Content-Type": "application/json", "Connection": "keep-alive"}
    if key:
        headers["Authorization"] = f"Bearer {key}"
    if not model:
        try:
            with urllib.request.urlopen(f"{base}/v1/models", timeout=8) as r:
                j = json.loads(r.read().decode("utf-8", "replace"))
            it = (j.get("data") or j.get("models") or [])
            model = (it[0].get("id") or it[0].get("name")) if it else ""
        except Exception:  # noqa: BLE001
            pass
    if not model:
        raise SystemExit("无法确定 model：请在 config.ini 的 [api] model 填写")

    tasks = [json.loads(l) for l in open(a.data, encoding="utf-8") if l.strip()]
    if a.limit:
        tasks = tasks[:a.limit]

    slug = re.sub(r"[^\w.\-]+", "_", model)[:60]
    outdir = os.path.join(a.out_dir or os.path.join(KIT, "results"), slug, "od")
    os.makedirs(outdir, exist_ok=True)
    pred_path = os.path.join(outdir, "predictions.jsonl")
    state_path = os.path.join(outdir, "predictions.state.json")

    done = {}
    if os.path.exists(state_path) and not a.fresh:
        try:
            done = json.load(open(state_path, encoding="utf-8"))
        except Exception:  # noqa: BLE001
            done = {}
    if a.fresh and os.path.exists(state_path):
        os.remove(state_path)

    print(SEP)
    print("OpenDecisions × 本地 Jev API（官方 score.py 口径）")
    print(f"  模型 : {model}")
    print(f"  服务 : {base}{endpoint}  并发 {conc}")
    print(f"  数据 : {a.data}  {len(tasks)} 条")
    print(f"  输出 : {outdir}")
    print(SEP)

    todo = [t for t in tasks if t["id"] not in done]
    if len(done):
        print(f"  断点续跑：已完成 {len(done)}，本次待做 {len(todo)}")

    lock = threading.Lock()
    done_n = [0]

    def work(start):
        cli = Client(u.hostname, u.port or 8000, headers, timeout)
        for i in range(start, len(todo), conc):
            task = todo[i]
            qid = task["id"]
            payload = {"model": model, "state": task["state"],
                       "questions": {qid: {"type": task["question"]["type"],
                                           "instructions": task["question"].get("instructions", ""),
                                           "criteria": task["question"]["criteria"]}}}
            rec = {"ok": False}
            try:
                st, raw = cli.post(endpoint, json.dumps(payload, ensure_ascii=False).encode())
                if 200 <= st < 300:
                    ans = (json.loads(raw).get("answers") or {}).get(qid) or {}
                    probs = to_probs(ans, task)
                    if probs:
                        rec = {"ok": True, "probs": probs}
            except Exception as e:  # noqa: BLE001
                rec["error"] = f"{type(e).__name__}: {e}"
            with lock:
                done[qid] = rec
                done_n[0] += 1
                if done_n[0] % 50 == 0:
                    json.dump(done, open(state_path + ".tmp", "w", encoding="utf-8"),
                              ensure_ascii=False)
                    os.replace(state_path + ".tmp", state_path)
                    print(f"      {done_n[0]}/{len(todo)}")

    ths = [threading.Thread(target=work, args=(k,), daemon=True) for k in range(conc)]
    for t in ths:
        t.start()
    for t in ths:
        t.join()
    json.dump(done, open(state_path, "w", encoding="utf-8"), ensure_ascii=False)

    with open(pred_path, "w", encoding="utf-8") as f:
        for t in tasks:
            r = done.get(t["id"])
            if r and r.get("ok"):
                f.write(json.dumps({"id": t["id"], "probs": r["probs"]},
                                   ensure_ascii=False) + "\n")

    # ---- 官方打分（原样调用）
    preds = [json.loads(l) for l in open(pred_path, encoding="utf-8") if l.strip()]
    result = official.score(tasks, preds)

    json.dump(result, open(os.path.join(outdir, f"{slug}.json"), "w",
                           encoding="utf-8"), ensure_ascii=False, indent=1)

    def f1(x):
        return "—" if x is None else f"{x:.1f}"

    md = [f"# {model} · OpenDecisions", "",
          f"> {datetime.now().strftime('%Y-%m-%d %H:%M')} ｜ "
          f"{result['predicted']}/{result['items']} 条有预测 ｜ 官方 score.py v1.6", "",
          "## 综合分", "",
          "| 指标 | 得分 |", "|---|---|",
          f"| **Capability** | **{f1(result['capability'])}** |",
          f"| Intelligence | {f1(result['intelligence'])} |",
          f"| Calibration | {f1(result['calibration'])} |", "",
          "## 分题型", "", "| 题型 | 准确率 | 能力(competence) | 校准 |", "|---|---|---|---|"]
    for t in ("choice", "noul", "score"):
        if t in result["accuracy_per_type"]:
            cc = result["competence_per_type"].get(t)
            ca = result["calibration_per_type"].get(t)
            md.append(f"| {t} | {result['accuracy_per_type'][t]:.1f}% | "
                      f"{f1(cc)} | {f1(ca)} |")
    if result.get("calibration_items_tvd") is not None:
        md += ["", f"真概率校准题（{result['calibration_items']} 条）平均 TVD："
                   f"**{result['calibration_items_tvd']:.3f}**（0 = 完全一致）"]
    md += ["", "## 口径", "",
           "- 打分完全由官方 `score.py` 计算，本脚本只负责把题目发给本地 API、生成 predictions.jsonl。",
           "- 没预测的条目按错处理（与官方一致）。",
           "- noul 以 P(yes) ≥ 0.5 判 yes（官方对本数据集的约定）。", ""]

    rpt = os.path.join(outdir, f"{slug}.md")
    open(rpt, "w", encoding="utf-8").write("\n".join(md))
    print("\n" + "\n".join(md[:14]))
    print(f"\n产物：{rpt}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
