#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
probe_api.py —— 探测本地服务能接受哪种请求形状（定位 400 的元凶）

背景
    同一批数据，choice 全过、noul/score 全 400。这几乎一定是**请求体形状**问题：
    各家 System One 服务对 noul 是否需要 criteria、score 的 criteria 用 dict 还是 list，
    约定不一致。本脚本对同一道题依次尝试几种常见形状，打印 HTTP 状态和响应体，
    一眼就能看出服务端要什么。

用法
    python probe_api.py                                  # 用 datasets/opendecisions.jsonl
    python probe_api.py --data datasets/xxx.jsonl        # 指定数据集
    python probe_api.py --type noul                      # 只试某一类
    python probe_api.py --raw '{"type":"noul","instructions":"..."}'   # 直接试自定义形状
"""

import argparse
import http.client
import json
import os
import sys
import urllib.parse

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import evaluate as E  # noqa: E402

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:  # noqa: BLE001
    pass


def post(base, endpoint, headers, model, state, q):
    u = urllib.parse.urlparse(base)
    body = json.dumps({"model": model, "state": state,
                       "questions": {"q0": q}}, ensure_ascii=False).encode()
    c = http.client.HTTPConnection(u.hostname, u.port or 8000, timeout=30)
    try:
        c.request("POST", endpoint, body=body, headers=headers)
        r = c.getresponse()
        return r.status, r.read()[:300].decode("utf-8", "replace")
    finally:
        c.close()


def shapes_for(task):
    """同一道题的几种候选形状，按"最可能被接受"排序。"""
    q = task["question"]
    base = {"type": q["type"], "instructions": q["instructions"]}
    crit = q["criteria"]
    out = []
    if q["type"] == "choice":
        out.append(("dict", dict(base, criteria=crit)))
        out.append(("list", dict(base, criteria=[str(v) for v in crit.values()])))
    elif q["type"] == "noul":
        out.append(("无 criteria", dict(base)))
        out.append(("dict", dict(base, criteria=crit)))
        out.append(("list", dict(base, criteria=[str(v) for v in crit.values()])))
    else:  # score
        if crit:
            out.append(("dict", dict(base, criteria=crit)))
            out.append(("list[str]", dict(base, criteria=[str(v) for v in crit.values()])))
            out.append(("list[id/desc]",
                        dict(base, criteria=[{"id": k, "description": str(v)}
                                             for k, v in crit.items()])))
        else:
            out.append(("无 criteria", dict(base)))
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default=os.path.join(HERE, "config.ini"))
    ap.add_argument("--data", default=os.path.join(HERE, "datasets", "opendecisions.jsonl"))
    ap.add_argument("--base")
    ap.add_argument("--model")
    ap.add_argument("--api-key")
    ap.add_argument("--type", default="", help="只试 choice/noul/score 之一")
    ap.add_argument("--raw", default="", help="直接试一个自定义 question JSON")
    a = ap.parse_args()

    import configparser
    cp = configparser.ConfigParser(interpolation=None)
    if os.path.exists(a.config):
        cp.read(a.config, encoding="utf-8")
    base = a.base or E.cget(cp, "api", "base", "http://127.0.0.1:9900")
    endpoint = E.cget(cp, "api", "endpoint", "/v1/systemone")
    model = a.model or E.cget(cp, "api", "model", "")
    key = a.api_key or os.environ.get("JEV_API_KEY") or E.cget(cp, "api", "api_key", "")
    headers = {"Content-Type": "application/json"}
    if key:
        headers["Authorization"] = f"Bearer {key}"

    print(f"目标 {base}{endpoint}  模型 {model or '(未指定)'}")

    if a.raw:
        state = "测试：阀门处于关闭状态。"
        st, body = post(base, endpoint, headers, model, state, json.loads(a.raw))
        print(f"  raw -> HTTP {st}  {body[:200]}")
        return 0

    tasks = E.load_dataset(a.data)
    picked = {}
    for t in tasks:
        k = t["question"]["type"]
        if k in picked or (a.type and k != a.type):
            continue
        picked[k] = t
        if len(picked) >= 3:
            break
    if not picked:
        raise SystemExit("没有可用的题目")

    ok_shape = {}
    for k, t in picked.items():
        print(f"\n=== {k}（题目 {t['id'][:40]}）")
        for name, q in shapes_for(t):
            st, body = post(base, endpoint, headers, model, t["state"], q)
            flag = "✅" if 200 <= st < 300 else "❌"
            print(f"  {flag} {name:<14} HTTP {st}  {body[:160]}")
            if 200 <= st < 300 and k not in ok_shape:
                ok_shape[k] = name

    print("\n" + "=" * 60)
    if ok_shape:
        print("服务端接受的形状：")
        for k, v in ok_shape.items():
            print(f"  {k:<7} -> {v}")
    else:
        print("三种形状全部失败，说明不是形状问题：")
        print("  1) 服务是否只支持 choice（noul/score 未实现）")
        print("  2) 是否有字段校验（如 criteria 必须为 null、instructions 不能为空）")
        print("  3) 用 --raw 手工试最小请求体")
    return 0


if __name__ == "__main__":
    sys.exit(main())
