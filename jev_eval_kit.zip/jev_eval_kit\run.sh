#!/usr/bin/env bash
# 一键测评：读 config.ini，扫 datasets/*.jsonl，结果写到 results/<模型名>/
#   ./run.sh                    全量
#   ./run.sh --limit 50         每个数据集只跑 50 条（冒烟）
#   ./run.sh --fresh            忽略断点重跑
#   ./run.sh --dataset xxx.jsonl
set -euo pipefail
cd "$(dirname "$0")"

PY="${PYTHON:-python3}"
if ! command -v "$PY" >/dev/null 2>&1; then
  PY=python
fi

echo "== jev 数据集测评 =="
"$PY" evaluate.py "$@"
