#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
build_dataset.py —— 数据改造：把任意 jsonl 变成「OD 可测」的数据集

只做数据，不打分。两条辅助路径可单独开关：

    探测（可选）  jev 模型跑一遍 → 每题对错 + 置信度，作为难度信号
    复核（可选）  LLM 逐题给 1-10 连续难度分 + 质量判定（keep/drop）

三种模式：
    --mode assisted   jev 探测 + LLM 复核（默认，最准）
    --mode llm        只让 LLM 定难度（不依赖被测模型，适合给别的模型准备数据）
    --mode rules      纯规则（不调任何模型，最快，深度依赖启发式）

输出（od_ready/）
    <name>.jsonl              OD 数据集（只有题目+标签+难度，不含任何模型输出）
    <name>.报告.md            分布、校验、结论
    <name>.rejected.jsonl     被筛掉的条目及原因
    <name>.probe.jsonl        探测模型的逐条表现（可选，单独放）
    <name>.balanced.jsonl     --balance 时的均衡子集

用法
    python prepare/build_dataset.py --src data/xxx.jsonl --name mydata
    python prepare/build_dataset.py --src ... --mode llm
    python prepare/build_dataset.py --src ... --mode rules
    python prepare/build_dataset.py --src ... --balance cap --ratios 30,30,20,20
"""

import argparse
import configparser
import hashlib
import json
import os
import sys
import threading
import time
import urllib.parse
from collections import Counter, defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
from jevio import (TIERS, LLM, Client, cget, load_jsonl, normalize,  # noqa: E402
                   parse_json, payload_shapes, to_probs)

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:  # noqa: BLE001
    pass

SEP = "=" * 78

SYS_LLM = (
    "你是数据集审校。给你一道选择题、标准答案，以及（可选）某个决策模型是否答对。"
    "请做两件事：\n"
    "1) 给这道题打一个 1-10 的连续难度分（不是分档）：\n"
    "   1-2 单条证据直接可判、选项<4；3-4 需简单比对或一步推理；\n"
    "   5-6 需综合多条证据或套一条明确规则；7-8 需专业规则、多步推理或证据甄别；\n"
    "   9-10 证据冲突/信息不全/存在合理歧义。\n"
    "   若模型答错，判断它是真的难，还是只是疏忽/领域不熟（后者不要抬高难度）。\n"
    "2) 这道题是否合格：标准答案唯一正确、选项无歧义、信息足够作答。\n"
    '只输出 JSON：{"difficulty":1-10,"keep":true|false,"reason":"≤20字"}'
)


# ================================================================ 规则难度

def rule_tier(t):
    crit = t["question"]["criteria"]
    n = len(crit)
    state = t["state"] or ""
    text = state + " " + (t["question"]["instructions"] or "")
    L = len(state)
    if "冲突" in text or "矛盾" in text or "例外" in text or "歧义" in text:
        return "hard"
    if n >= 6 or L >= 2500:
        return "hard"
    if any(k in text for k in ("阈值", "合规", "评审", "规程", "标准条款", "校验规则")):
        return "judge"
    if n <= 3 and L <= 600:
        return "easy"
    return "standard"


# ================================================================ 探测

def probe(tasks, cfg, state_path, conc, fresh):
    done = {} if fresh else _load(state_path)
    todo = [t for t in tasks if t["id"] not in done]
    if done:
        print(f"      探测断点：已完成 {len(done)}，待做 {len(todo)}")

    lock = threading.Lock()
    n = [0]

    def work(start):
        cli = Client(cfg["host"], cfg["port"], cfg["headers"], cfg["timeout"])
        for i in range(start, len(todo), conc):
            t = todo[i]
            rec = {"ok": False}
            t0 = time.perf_counter()
            for q in payload_shapes(t):
                try:
                    body = json.dumps({"model": cfg["model"], "state": t["state"],
                                       "questions": {t["id"]: q}},
                                      ensure_ascii=False).encode()
                    st, raw = cli.post(cfg["endpoint"], body)
                    if 200 <= st < 300:
                        ans = (json.loads(raw).get("answers") or {}).get(t["id"]) or {}
                        p = to_probs(ans, t)
                        if p:
                            vec = [p.get(l, 0.0) for l in t["labels"]]
                            s = sum(vec) or 1.0
                            vec = [v / s for v in vec]
                            k = max(range(len(vec)), key=lambda j: vec[j])
                            rec = {"ok": True, "pred": t["labels"][k],
                                   "conf": round(vec[k], 4),
                                   "correct": t["labels"][k] == t["expected"]}
                            break
                except Exception as e:  # noqa: BLE001
                    rec = {"ok": False, "error": type(e).__name__}
            rec["ms"] = round((time.perf_counter() - t0) * 1000, 1)
            with lock:
                done[t["id"]] = rec
                n[0] += 1
                if n[0] % 100 == 0:
                    _save(state_path, done)
                    print(f"      探测 {n[0]}/{len(todo)}")
    ths = [threading.Thread(target=work, args=(k,), daemon=True) for k in range(conc)]
    for t in ths:
        t.start()
    for t in ths:
        t.join()
    _save(state_path, done)
    return done


# ================================================================ LLM 复核

def adjudicate(tasks, probe_res, llm, state_path, conc, fresh, with_probe):
    done = {} if fresh else _load(state_path)
    todo = [t for t in tasks if t["id"] not in done]
    if done:
        print(f"      复核断点：已完成 {len(done)}，待做 {len(todo)}")

    lock = threading.Lock()
    n = [0]

    def work(start):
        for i in range(start, len(todo), conc):
            t = todo[i]
            opts = "\n".join(f"- {k}: {v}" for k, v in t["question"]["criteria"].items())
            user = (f"状态：\n{t['state'][:2500]}\n\n"
                    f"问题：{t['question']['instructions']}\n\n选项：\n{opts}\n\n"
                    f"标准答案：{t['expected']}")
            if with_probe:
                pr = probe_res.get(t["id"]) or {}
                user += (f"\n模型表现：{'答对' if pr.get('correct') else '答错'}"
                         f"（置信度 {pr.get('conf')}）")
            rec = {"difficulty": 5.0, "keep": True, "reason": ""}
            try:
                r = parse_json(llm.chat(SYS_LLM, user, 120))
                if r:
                    if isinstance(r.get("difficulty"), (int, float)):
                        rec["difficulty"] = max(1.0, min(10.0, float(r["difficulty"])))
                    if r.get("keep") is False:
                        rec["keep"] = False
                    rec["reason"] = (r.get("reason") or "")[:40]
            except Exception as e:  # noqa: BLE001
                rec["error"] = str(e)[:80]
            with lock:
                done[t["id"]] = rec
                n[0] += 1
                if n[0] % 100 == 0:
                    _save(state_path, done)
                    print(f"      复核 {n[0]}/{len(todo)}")
    ths = [threading.Thread(target=work, args=(k,), daemon=True) for k in range(conc)]
    for t in ths:
        t.start()
    for t in ths:
        t.join()
    _save(state_path, done)
    return done


# ================================================================ 难度分

def difficulty_score(t, adj, with_probe):
    llm = (float(adj.get("difficulty", 5.0)) - 1.0) / 9.0
    length = min(len(t.get("state") or "") / 3000.0, 1.0)
    nopt = min(max(len(t["labels"]) - 2, 0) / 4.0, 1.0)
    if with_probe:
        conf = t.get("probe_conf")
        conf = 0.5 if conf is None else float(conf)
        wrong = 0.0 if t.get("probe_correct") else 1.0
        return round(0.30 * wrong + 0.20 * (1 - conf) + 0.30 * llm
                     + 0.10 * length + 0.10 * nopt, 4)
    return round(0.50 * llm + 0.25 * length + 0.25 * nopt, 4)


def assign_quantile(items, ratios):
    by_type = defaultdict(list)
    for t in items:
        by_type[t["question"]["type"]].append(t)
    for arr in by_type.values():
        arr.sort(key=lambda x: x["_score"])
        n = len(arr)
        bounds, acc = [], 0.0
        for r in ratios:
            acc += r
            bounds.append(min(n, int(round(n * acc / 100.0))))
        idx = 0
        for i, t in enumerate(arr):
            while idx < 3 and i >= bounds[idx]:
                idx += 1
            t["tier"] = TIERS[idx]


def assign_absolute(items, cuts):
    cs = [float(x) for x in cuts.split(",")]
    for t in items:
        s = t["_score"]
        t["tier"] = ("easy" if s < cs[0] else "standard" if s < cs[1]
                     else "judge" if s < cs[2] else "hard")


def balance(items, mode, per_cell):
    cells = defaultdict(list)
    for t in items:
        cells[(t["question"]["type"], t["tier"])].append(t)
    if mode == "none" or not cells:
        return items, None
    before = {f"{k[0]}/{k[1]}": len(v) for k, v in cells.items()}
    m = min(len(v) for v in cells.values())
    take = {k: (m if mode == "cap" else min(len(v), per_cell)) for k, v in cells.items()}
    out = []
    for k, v in cells.items():
        n = take[k]
        if n <= 0:
            continue
        v = sorted(v, key=lambda t: t["_score"])
        step = len(v) / n
        out += [v[min(int(i * step), len(v) - 1)] for i in range(n)]
    return out, {"before": before,
                 "take": {f"{k[0]}/{k[1]}": take[k] for k in cells},
                 "min_cell": m, "cells": len(cells),
                 "max_uniform": m * len(cells), "total": len(out)}


# ================================================================ 校验

def validate(items, min_cell, min_hard_choice):
    types = Counter(t["question"]["type"] for t in items)
    tiers = Counter(t["tier"] for t in items)
    cells = Counter((t["question"]["type"], t["tier"]) for t in items)
    hard_choice = cells[("choice", "hard")]
    checks = [("三型齐全", len(types) == 3, f"{dict(types)}"),
              ("难度至少 2 档", len(tiers) >= 2, f"{dict(tiers)}"),
              (f"hard 档 choice ≥ {min_hard_choice}",
               hard_choice >= min_hard_choice, f"{hard_choice} 条")]
    thin = [(f"{k[0]}/{k[1]}", v) for k, v in cells.items() if v < min_cell]
    checks.append((f"每个(题型×难度) ≥ {min_cell}", not thin,
                   "；".join(f"{k}={v}" for k, v in thin[:6]) if thin else "全部达标"))
    top_share = max(tiers.values()) / len(items) if items else 1.0
    checks.append(("无单档垄断（最大档 ≤ 70%）", top_share <= 0.7, f"最大档占 {top_share:.0%}"))
    return {"types": dict(types), "tiers": dict(tiers),
            "cells": {f"{k[0]}/{k[1]}": v for k, v in sorted(cells.items())},
            "hard_choice": hard_choice, "checks": checks,
            "pass": all(c[1] for c in checks)}


# ================================================================ 状态

def _load(p):
    try:
        return json.load(open(p, encoding="utf-8"))
    except Exception:  # noqa: BLE001
        return {}


def _save(p, d):
    tmp = p + ".tmp"
    json.dump(d, open(tmp, "w", encoding="utf-8"), ensure_ascii=False)
    os.replace(tmp, p)


# ================================================================ main

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default=os.path.join(ROOT, "config.ini"))
    ap.add_argument("--src", required=True)
    ap.add_argument("--name", default="")
    ap.add_argument("--out", default=None)
    ap.add_argument("--mode", default="assisted", choices=["assisted", "llm", "rules"])
    ap.add_argument("--no-probe", action="store_true", help="跳过 jev 探测")
    ap.add_argument("--jev-base")
    ap.add_argument("--jev-model")
    ap.add_argument("--llm-base")
    ap.add_argument("--llm-model")
    ap.add_argument("--llm-key")
    ap.add_argument("--concurrency", type=int, default=None)
    ap.add_argument("--scheme", default=None, choices=["quantile", "absolute", "rule"],
                    help="rule 仅在 rules 模式下有效（用规则直接分档）")
    ap.add_argument("--ratios", default=None)
    ap.add_argument("--cuts", default=None)
    ap.add_argument("--balance", default=None, choices=["none", "cap", "target"])
    ap.add_argument("--per-cell", type=int, default=None)
    ap.add_argument("--min-cell", type=int, default=None)
    ap.add_argument("--min-hard-choice", type=int, default=None)
    ap.add_argument("--fresh", action="store_true")
    a = ap.parse_args()

    cp = configparser.ConfigParser(interpolation=None)
    if os.path.exists(a.config):
        cp.read(a.config, encoding="utf-8")
    jb = a.jev_base or cget(cp, "api", "base", "http://127.0.0.1:9900")
    jm = a.jev_model or cget(cp, "api", "model", "")
    je = cget(cp, "api", "endpoint", "/v1/systemone")
    lb = a.llm_base or cget(cp, "llm", "base", "")
    lm = a.llm_model or cget(cp, "llm", "model", "")
    lk = a.llm_key or cget(cp, "llm", "api_key", "")

    # 命令行没给的，回落到 config.ini 的 [prepare]
    a.out = a.out or cget(cp, "prepare", "out", "od_ready")
    a.concurrency = a.concurrency or int(cget(cp, "api", "concurrency", "8"))
    a.scheme = a.scheme or cget(cp, "prepare", "scheme", "quantile")
    a.ratios = a.ratios or cget(cp, "prepare", "ratios", "30,30,20,20")
    a.cuts = a.cuts or cget(cp, "prepare", "cuts", "0.3,0.5,0.75")
    a.balance = a.balance or cget(cp, "prepare", "balance", "none")
    a.per_cell = a.per_cell or int(cget(cp, "prepare", "per_cell", "40"))
    a.min_cell = a.min_cell or int(cget(cp, "prepare", "min_cell", "20"))
    a.min_hard_choice = a.min_hard_choice or int(cget(cp, "prepare", "min_hard_choice", "30"))

    use_probe = a.mode == "assisted" and not a.no_probe
    use_llm = a.mode in ("assisted", "llm")
    if use_probe and not jm:
        raise SystemExit("assisted 模式需要 jev 模型：配置 [api] model 或用 --jev-model"
                         "（也可 --no-probe / --mode llm）")
    if use_llm and not (lb and lm):
        raise SystemExit("需要 LLM：在 [llm] 配置 base/model，或用 --llm-base/--llm-model"
                         "（也可 --mode rules）")

    src = a.src if os.path.isabs(a.src) else os.path.join(ROOT, a.src)
    outdir = a.out if os.path.isabs(a.out) else os.path.join(ROOT, a.out)
    os.makedirs(outdir, exist_ok=True)
    name = a.name or os.path.splitext(os.path.basename(src))[0]
    statedir = os.path.join(outdir, ".state")
    os.makedirs(statedir, exist_ok=True)

    # ---- 读入 + 规范化 + 去重
    rows = load_jsonl(src)
    tasks, seen, dropped = [], set(), []
    for i, raw in enumerate(rows):
        t = normalize(raw, name, i)
        if not t:
            dropped.append({"line": i, "reason": "字段不完整/无法解析"})
            continue
        if len(t["labels"]) < 2 or not (t["state"] or "").strip():
            dropped.append({"id": t["id"], "reason": "选项或状态为空"})
            continue
        sig = hashlib.sha256((t["state"] + t["question"]["instructions"] +
                              json.dumps(t["question"]["criteria"], sort_keys=True,
                                         ensure_ascii=False)).encode()).hexdigest()[:16]
        if sig in seen:
            dropped.append({"id": t["id"], "reason": "重复"})
            continue
        seen.add(sig)
        tasks.append(t)

    print(SEP)
    print(f"数据集 {name}：读入 {len(rows)}，可用 {len(tasks)}，丢弃 {len(dropped)}")
    print(f"模式 {a.mode}　探测 {'开' if use_probe else '关'}　LLM {'开' if use_llm else '关'}")
    print(SEP)

    # ---- 探测
    probe_res = {}
    if use_probe:
        u = urllib.parse.urlparse(jb)
        cfg = {"host": u.hostname, "port": u.port or 8000, "endpoint": je,
               "headers": {"Content-Type": "application/json"}, "timeout": 180,
               "model": jm}
        print("\n[1/3] 探测（jev 模型跑一遍）")
        probe_res = probe(tasks, cfg, os.path.join(statedir, f"{name}.probe.state.json"),
                          a.concurrency, a.fresh)
        ok = sum(1 for r in probe_res.values() if r.get("ok"))
        print(f"      成功 {ok}/{len(tasks)}")

    # ---- LLM 复核
    adj = {}
    if use_llm:
        llm = LLM(lb, lm, lk, timeout=120)
        print("\n[2/3] 复核（LLM 给难度分 + 质检）")
        adj = adjudicate(tasks, probe_res, llm,
                         os.path.join(statedir, f"{name}.llm.state.json"),
                         a.concurrency, a.fresh, use_probe)
        n_err = sum(1 for v in adj.values() if v.get("error"))
        diffs = [float(v.get("difficulty", 5.0)) for v in adj.values() if not v.get("error")]
        uniq = len(set(diffs))
        mean = sum(diffs) / len(diffs) if diffs else 0.0
        std = (sum((d - mean) ** 2 for d in diffs) / len(diffs)) ** 0.5 if diffs else 0.0
        llm_ok = (n_err <= max(2, 0.05 * len(adj))) and uniq >= 3 and std >= 0.5
        print(f"      LLM：成功 {len(adj) - n_err}/{len(adj)}，难度分 {uniq} 种，"
              f"均值 {mean:.1f}，std {std:.2f} → {'✅ 生效' if llm_ok else '❌ 未生效'}")
        if not llm_ok:
            print("      ⚠️ 难度分会退化为「长度+选项数」，请检查 LLM 配置")
    else:
        llm_ok, n_err, uniq, mean, std = None, 0, 0, 0.0, 0.0
        print("\n[2/3] 复核：跳过（rules 模式）")

    # ---- 合并、分档
    print("\n[3/3] 分档 + 校验")
    kept, rejected = [], []
    for t in tasks:
        v = adj.get(t["id"]) or {}
        if v.get("keep") is False:
            rejected.append({"id": t["id"], "reason": v.get("reason") or "LLM 判不合格"})
            continue
        t["llm_difficulty"] = float(v.get("difficulty", 5.0))
        t["probe_correct"] = (probe_res.get(t["id"]) or {}).get("correct")
        t["probe_conf"] = (probe_res.get(t["id"]) or {}).get("conf")
        t["_score"] = difficulty_score(t, t, use_probe)
        kept.append(t)

    if a.mode == "rules":
        for t in kept:
            t["tier"] = rule_tier(t)
        print("      分层：规则（长度/选项数/关键词）")
    elif a.scheme == "quantile":
        ratios = [float(x) for x in a.ratios.split(",") if x.strip()]
        if len(ratios) != 4:
            raise SystemExit("--ratios 需要 4 个数，如 30,30,20,20")
        s = sum(ratios)
        ratios = [r * 100.0 / s for r in ratios]
        assign_quantile(kept, ratios)
        print(f"      分层：题型内按难度分位数 {['%.0f' % r for r in ratios]}%")
    else:
        assign_absolute(kept, a.cuts)
        print(f"      分层：固定阈值 {a.cuts}")

    # 回验：各档探测准确率应单调
    tier_acc, monotonic = {}, None
    if use_probe:
        by_tier = defaultdict(list)
        for t in kept:
            by_tier[t["tier"]].append(t)
        for k, arr in by_tier.items():
            accs = [1.0 if x["probe_correct"] else 0.0 for x in arr
                    if x["probe_correct"] is not None]
            tier_acc[k] = (len(arr), sum(accs) / len(accs) if accs else None)
        seq = [tier_acc[k][1] for k in TIERS if k in tier_acc and tier_acc[k][1] is not None]
        monotonic = (all(seq[i] >= seq[i + 1] - 0.03 for i in range(len(seq) - 1))
                     if len(seq) >= 2 else None)

    rep = validate(kept, a.min_cell, a.min_hard_choice)
    for nm, ok, detail in rep["checks"]:
        print(f"      {'✅' if ok else '❌'} {nm}：{detail}")
    if monotonic is not None:
        s = " → ".join(f"{k} {tier_acc[k][1]*100:.0f}%" for k in TIERS
                       if k in tier_acc and tier_acc[k][1] is not None)
        print(f"      {'✅' if monotonic else '❌'} 探测准确率单调：{s}")

    # ---- 均衡子集
    bal = None
    if a.balance != "none":
        kept_bal, bal = balance(kept, a.balance, a.per_cell)
        print(f"\n      均衡子集：{len(kept_bal)} 条 / 原 {len(kept)}"
              f"　最小格 {bal['min_cell']} × {bal['cells']} 格 = {bal['max_uniform']}")
        _write(os.path.join(outdir, f"{name}.balanced.jsonl"), kept_bal)

    # ---- 输出
    out_path = os.path.join(outdir, f"{name}.jsonl")
    _write(out_path, kept)
    with open(os.path.join(outdir, f"{name}.rejected.jsonl"), "w", encoding="utf-8") as f:
        for d in rejected + dropped:
            f.write(json.dumps(d, ensure_ascii=False) + "\n")
    if use_probe:
        with open(os.path.join(outdir, f"{name}.probe.jsonl"), "w", encoding="utf-8") as f:
            for t in kept:
                f.write(json.dumps({"id": t["id"],
                                    "probe_correct": t["probe_correct"],
                                    "probe_conf": t["probe_conf"],
                                    "tier": t["tier"]}, ensure_ascii=False) + "\n")

    md = _report(name, len(rows), len(tasks), kept, rejected, dropped,
                 rep, tier_acc, monotonic, bal, a, jm, lm, use_probe, use_llm,
                 llm_ok, n_err, uniq, mean, std)
    rpt = os.path.join(outdir, f"{name}.报告.md")
    open(rpt, "w", encoding="utf-8").write("\n".join(md))
    print("\n" + "\n".join(md[:24]))
    print(f"\n数据集：{out_path}\n报告：{rpt}")
    return 0


def _write(path, items):
    with open(path, "w", encoding="utf-8") as f:
        for t in items:
            row = {"id": t["id"], "state": t["state"], "question": t["question"],
                   "labels": t["labels"], "expected": t["expected"], "tier": t["tier"]}
            if t.get("target_probs"):
                row["target_probs"] = t["target_probs"]
            f.write(json.dumps(row, ensure_ascii=False) + "\n")


def _report(name, n_in, n_tasks, kept, rejected, dropped, rep, tier_acc,
            monotonic, bal, a, jm, lm, use_probe, use_llm, llm_ok,
            n_err, uniq, mean, std):
    md = [f"# 数据改造报告：{name}", "",
          f"- 模式：**{a.mode}**　探测：{'开' if use_probe else '关'}"
          f"　LLM：{'开' if use_llm else '关'}",
          f"- 模型：探测 `{jm or '—'}`　复核 `{lm or '—'}`",
          f"- 读入 {n_in} → 可用 {n_tasks} → 通过质检 {len(kept)}"
          f"（拒 {len(rejected)}，格式丢弃 {len(dropped)}）", ""]
    if use_llm:
        md += ["## LLM 是否生效", "",
               f"- 失败 {n_err} 条（占比 {n_err/max(1,len(kept)):.1%}）",
               f"- 难度分 {uniq} 种，均值 {mean:.1f}，std {std:.2f}",
               f"- 判定：**{'✅ 生效' if llm_ok else '❌ 未生效'}**", ""]
    md += ["## 分布", "", "| 难度 | 数量 | 探测准确率 |", "|---|---|---|"]
    for k in TIERS:
        if k in rep["tiers"]:
            n_, acc_ = tier_acc.get(k, (rep["tiers"][k], None))
            md.append(f"| {k} | {n_} | {'—' if acc_ is None else f'{acc_*100:.1f}%'} |")
    if monotonic is not None:
        md += ["", f"**单调性：{'✅ 准确率随难度下降' if monotonic else '❌ 准确率未随难度下降'}**"]
    md += ["", "| 题型 | 数量 |", "|---|---|"]
    for k, v in rep["types"].items():
        md.append(f"| {k} | {v} |")
    md += ["", "| 单元格 | 数量 |", "|---|---|"]
    for k, v in rep["cells"].items():
        md.append(f"| {k} | {v} |")
    if bal:
        md += ["", "## 均衡子集", "",
               f"- 方式 {a.balance}　最小格 {bal['min_cell']} × {bal['cells']} 格"
               f" = 理论最大 **{bal['max_uniform']}** 条",
               f"- 实际产出 **{bal['total']}** 条 → `{name}.balanced.jsonl`", "",
               "| 单元格 | 原有 | 取用 |", "|---|---|---|"]
        for k in bal["before"]:
            md.append(f"| {k} | {bal['before'][k]} | {bal['take'][k]} |")
    md += ["", "## 校验", "", "| 检查项 | 结果 | 详情 |", "|---|---|---|"]
    for nm, ok, detail in rep["checks"]:
        md.append(f"| {nm} | {'✅' if ok else '❌'} | {detail} |")
    md += ["", f"**结论：{'✅ 可直接用于 OD 口径测评' if rep['pass'] else '❌ 不满足 OD 测评要求'}**",
           "", "## 说明", "",
           "- 数据集只含 `id/state/question/labels/expected/tier[/target_probs]`，"
           "**不含任何模型输出**。",
           "- 探测模型的逐条表现另存 `<name>.probe.jsonl`，供人工抽查，不进数据集。",
           "- gold 全部沿用原数据，未由任何模型生成。"]
    if use_probe:
        md += ["- ⚠️ 难度档含探测模型的对错信号：用**同一模型**在被它分档的数据上报分数会被放大。"]
    return md


if __name__ == "__main__":
    sys.exit(main())
