#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
jevio.py —— 数据改造流程用的公共件（不依赖任何评测代码）

    cget           读 config
    load_jsonl     读 jsonl
    normalize      把任意 jsonl 记录转成统一 task
    Client         Jev 决策服务的 HTTP 客户端
    payload_shapes 同一道题的几种请求形状（服务端 schema 不同）
    to_probs       把返回的概率对齐到 labels
    LLM            OpenAI 兼容的 chat 客户端
    parse_json     从模型输出里抠出 JSON
"""

import http.client
import json
import os
import re
import threading
import urllib.parse

TIERS = ("easy", "standard", "judge", "hard")


def cget(cp, sec, key, default):
    v = cp.get(sec, key, fallback=None)
    return default if v is None else v


def load_jsonl(path):
    with open(path, "r", encoding="utf-8") as f:
        return [json.loads(l) for l in f if l.strip()]


# ================================================================ 规范化

def jload(v, default=None):
    if v is None:
        return default
    if isinstance(v, (dict, list, int, float, bool)):
        return v
    s = str(v).strip()
    if not s:
        return default
    try:
        return json.loads(s)
    except Exception:  # noqa: BLE001
        return default if default is not None else s


def normalize(raw, ds_name, idx):
    """任意 jsonl 记录 → {id, state, question{type,instructions,criteria},
                          labels, expected, tier, target_probs}"""
    q = raw.get("question")
    if isinstance(q, str):
        q = {"type": raw.get("type") or raw.get("kind") or "choice",
             "instructions": q,
             "criteria": raw.get("options") or raw.get("criteria") or {}}
    elif not isinstance(q, dict):
        q = {}

    qtype = str(q.get("type") or raw.get("type") or raw.get("kind") or "choice").lower()
    crit = q.get("criteria") or raw.get("options") or raw.get("criteria") or {}
    labels = raw.get("labels")
    if isinstance(crit, list):
        if labels and len(labels) == len(crit):
            crit = {str(l): str(x) for l, x in zip(labels, crit)}
        else:
            crit = {str(i): str(x) for i, x in enumerate(crit)}

    if not labels:
        labels = [str(k) for k in crit.keys()] if crit else []
    labels = [str(x) for x in labels]

    expected = raw.get("expected")
    if expected is None:
        expected = raw.get("answer", raw.get("gold", raw.get("label")))
    target = raw.get("target_probs") or raw.get("target")
    target_probs = None
    if isinstance(target, dict) and target:
        target_probs = {str(k): float(v) for k, v in target.items()}
    elif isinstance(target, list) and target and len(target) == len(labels):
        target_probs = {str(k): float(v) for k, v in zip(labels, target)}
    if expected is None and target_probs:
        expected = max(target_probs, key=target_probs.get)

    if expected is None or not labels:
        return None
    if str(expected) not in labels:
        low = {x.lower(): x for x in labels}
        if str(expected).lower() not in low:
            return None
        expected = low[str(expected).lower()]
    expected = str(expected)

    extra = {}
    if qtype in ("noul", "yesno", "yes/no"):
        qtype = "noul"
        low = {x.lower(): x for x in labels}
        yes_lab = next((v for k, v in low.items() if k in ("yes", "true", "1", "成立")), None)
        no_lab = next((v for k, v in low.items() if k in ("no", "false", "0", "不成立")), None)
        if not yes_lab or not no_lab:
            return None
        expected = "yes" if expected.lower() in ("yes", "true", "1", "成立") else "no"
        labels = ["no", "yes"]
        extra = {"_yes": yes_lab, "_no": no_lab}
        if target_probs:
            py = target_probs.get(yes_lab, target_probs.get("yes", 0.0))
            target_probs = {"no": 1.0 - float(py), "yes": float(py)}

    task = {
        "id": str(raw.get("id") or f"{ds_name}:{idx}"),
        "state": raw.get("state") if isinstance(raw.get("state"), str)
                 else json.dumps(raw.get("state") or "", ensure_ascii=False),
        "question": {"type": qtype,
                     "instructions": q.get("instructions") or raw.get("instructions") or "",
                     "criteria": crit},
        "labels": labels,
        "expected": expected,
        "tier": raw.get("tier") or "standard",
        "target_probs": target_probs,
    }
    task.update(extra)
    return task


def load_tasks(path, limit=0):
    """读 jsonl 并规范化成 task 列表（跳过无法解析的条目）。"""
    rows = load_jsonl(path)
    out = []
    for i, r in enumerate(rows):
        t = normalize(r, os.path.basename(path), i)
        if t:
            out.append(t)
        if limit and len(out) >= limit:
            break
    return out


# ================================================================ HTTP

class Client:
    def __init__(self, host, port, headers, timeout):
        self.host, self.port, self.headers, self.timeout = host, port, headers, timeout
        self.conn = None

    def post(self, path, body):
        if self.conn is None:
            self.conn = http.client.HTTPConnection(self.host, self.port, timeout=self.timeout)
        for attempt in (0, 1):
            try:
                self.conn.request("POST", path, body=body, headers=self.headers)
                r = self.conn.getresponse()
                return r.status, r.read()
            except Exception:  # noqa: BLE001
                try:
                    if self.conn:
                        self.conn.close()
                except Exception:  # noqa: BLE001
                    pass
                self.conn = None
                if attempt:
                    raise
                self.conn = http.client.HTTPConnection(self.host, self.port,
                                                       timeout=self.timeout)


def payload_shapes(t):
    """同一道题的几种合法请求形状，按"最可能被接受"排序。

    各家服务约定不同：noul 可能要求省略 criteria；score 的 criteria 可能是
    dict / 字符串列表 / {id,description} 列表。运行时按实际返回自动挑一个。
    """
    q = t["question"]
    crit = q["criteria"]
    base = {"type": q["type"], "instructions": q["instructions"]}
    if q["type"] == "choice":
        out = [dict(base, criteria=crit)]
        if crit:
            out.append(dict(base, criteria=[str(v) for v in crit.values()]))
        return out
    if q["type"] == "noul":
        out = [dict(base)]
        if crit:
            out.append(dict(base, criteria=crit))
            out.append(dict(base, criteria=[str(v) for v in crit.values()]))
        return out
    if crit:
        return [dict(base, criteria=crit),
                dict(base, criteria=[str(v) for v in crit.values()]),
                dict(base, criteria=[{"id": k, "description": str(v)}
                                     for k, v in crit.items()])]
    return [base]


def to_probs(ans, task):
    """把服务端返回的概率对齐到 task.labels；noul 统一成 {"no","yes"}。"""
    p = (ans or {}).get("probabilities")
    if not isinstance(p, dict) or not p:
        return None
    p = {str(k): float(v) for k, v in p.items()}
    if task["question"]["type"] == "noul":
        py = None
        for k in (task.get("_yes"), "yes", "true", "True", "1"):
            if k and k in p:
                py = p[k]
                break
        if py is None:
            for k in (task.get("_no"), "no", "false", "False", "0"):
                if k and k in p:
                    py = 1.0 - p[k]
                    break
        if py is None and len(p) == 2:
            py = list(p.values())[0]
        return None if py is None else {"no": 1.0 - py, "yes": py}

    labels = task["labels"]
    if set(p) == set(labels):
        vals = {k: p[k] for k in labels}
    elif len(p) == len(labels):
        vals = dict(zip(labels, p.values()))
    else:
        return None
    s = sum(vals.values())
    return {k: v / s for k, v in vals.items()} if s > 0 else None


# ================================================================ LLM

class LLM:
    def __init__(self, base, model, key, timeout=120):
        u = urllib.parse.urlparse(base)
        self.host, self.port = u.hostname, u.port or 8000
        self.path = (u.path.rstrip("/") or "") + "/chat/completions"
        self.model, self.timeout = model, timeout
        self.headers = {"Content-Type": "application/json"}
        if key:
            self.headers["Authorization"] = f"Bearer {key}"
        self._tls = threading.local()

    def _conn(self):
        c = getattr(self._tls, "c", None)
        if c is None:
            c = http.client.HTTPConnection(self.host, self.port, timeout=self.timeout)
            self._tls.c = c
        return c

    def chat(self, system, user, max_tokens=200):
        body = json.dumps({"model": self.model, "temperature": 0, "max_tokens": max_tokens,
                           "messages": [{"role": "system", "content": system},
                                        {"role": "user", "content": user}]},
                          ensure_ascii=False).encode()
        for attempt in (0, 1):
            try:
                c = self._conn()
                c.request("POST", self.path, body=body, headers=self.headers)
                r = c.getresponse()
                raw = r.read()
                if not (200 <= r.status < 300):
                    raise RuntimeError(f"HTTP {r.status}: {raw[:120]}")
                return json.loads(raw)["choices"][0]["message"]["content"]
            except Exception:
                try:
                    self._conn().close()
                except Exception:  # noqa: BLE001
                    pass
                self._tls.c = None
                if attempt:
                    raise
        return ""


def parse_json(text):
    if not text:
        return None
    m = re.search(r"\{.*\}", text, re.S)
    if not m:
        return None
    try:
        return json.loads(m.group(0))
    except Exception:  # noqa: BLE001
        return None
