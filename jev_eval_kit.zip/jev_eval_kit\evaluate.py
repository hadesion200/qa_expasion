#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
evaluate.py —— 通用 Jev 数据集测评（一个入口，扫 datasets/ 下所有 jsonl）

流程
    datasets/*.jsonl  →  逐条调本地 Jev API  →  predictions  →  打分  →  results/<模型名>/

打分
    直接复用 OpenDecisions 官方 scorer（od/score.py，未改一行）：
        Capability = (Intelligence + Calibration) / 2
        Intelligence = 三题型等权；题型内按 tier 加权（easy .1 / standard .2 / judge .3 / hard .4）
                       choice: 100(acc−c)/(1−c)；noul: 100(acc−0.5)/0.5；score: 100(1−nMAE/nMAE_mid)
        Calibration  = 三题型等权；choice 只统计 hard 档；各 100(1−ECE/0.5)
    另外补三块官方没有的：可靠性分桶表、一致性（换序/重复）、延迟与失败分析。

支持的 jsonl 格式（缺字段会自动兜底）
    {"id", "state", "question": {"type","instructions","criteria"}, "labels", "expected", "tier"}
    {"id", "state", "question"(str), "options": [...], "target": [p...]}      # jev-distill 风格
    {"id", "state", "question": {"...criteria"}, "answer"/"gold"/"label"}

用法
    ./run.sh                        # 一键：全部数据集
    ./run.sh --limit 50             # 冒烟
    ./run.sh --dataset opendecisions.jsonl
    ./run.sh --fresh                # 忽略断点
"""

import argparse
import configparser
import http.client
import json
import math
import os
import random
import re
import sys
import threading
import time
import urllib.parse
import urllib.request
from collections import Counter

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "od"))
import score as official  # noqa: E402

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:  # noqa: BLE001
    pass

SEP = "=" * 78


def cget(cp, sec, key, default):
    v = cp.get(sec, key, fallback=None)
    return default if v is None else v


# ================================================================ 读入 & 归一化

def normalize(raw, ds_name, idx):
    """把各种 jsonl 形态统一成官方 scorer 需要的 task。"""
    q = raw.get("question")
    if isinstance(q, str):
        q = {"type": raw.get("type") or raw.get("kind") or "choice",
             "instructions": q,
             "criteria": raw.get("options") or raw.get("criteria") or {}}
    elif not isinstance(q, dict):
        q = {}

    qtype = str(q.get("type") or raw.get("type") or raw.get("kind") or "choice").lower()
    crit = q.get("criteria") or raw.get("options") or raw.get("criteria") or {}
    labels = raw.get("labels")
    if isinstance(crit, list):
        # 列表型 options：优先用显式 labels 当键，否则用位置键 0..n-1（避免同名选项互相覆盖）
        if labels and len(labels) == len(crit):
            crit = {str(l): str(x) for l, x in zip(labels, crit)}
        else:
            crit = {str(i): str(x) for i, x in enumerate(crit)}

    if not labels:
        labels = [str(k) for k in crit.keys()] if crit else []
    labels = [str(x) for x in labels]

    expected = raw.get("expected")
    if expected is None:
        expected = raw.get("answer", raw.get("gold", raw.get("label")))
    target = raw.get("target_probs") or raw.get("target")
    target_probs = None
    if isinstance(target, dict) and target:
        target_probs = {str(k): float(v) for k, v in target.items()}
    elif isinstance(target, list) and target and len(target) == len(labels):
        target_probs = {str(k): float(v) for k, v in zip(labels, target)}
    if expected is None and target_probs:
        expected = max(target_probs, key=target_probs.get)

    if expected is None or not labels:
        return None
    if str(expected) not in labels:                      # 大小写不一致时按忽略大小写对齐
        low = {x.lower(): x for x in labels}
        if str(expected).lower() not in low:
            return None
        expected = low[str(expected).lower()]
    expected = str(expected)

    extra = {}
    if qtype in ("noul", "yesno", "yes/no"):
        qtype = "noul"
        # 官方 scorer 要求 noul 的 labels 是 yes/no（item_outcome 直接取 probs["yes"]），
        # 但数据集可能是 true/false，这里做一次规范化，并记住原始键
        low = {x.lower(): x for x in labels}
        yes_lab = next((v for k, v in low.items() if k in ("yes", "true", "1", "成立")), None)
        no_lab = next((v for k, v in low.items() if k in ("no", "false", "0", "不成立")), None)
        if not yes_lab or not no_lab:
            return None
        expected = "yes" if expected.lower() in ("yes", "true", "1", "成立") else "no"
        labels = ["no", "yes"]
        extra = {"_yes": yes_lab, "_no": no_lab}
        if target_probs:
            py = target_probs.get(yes_lab, target_probs.get("yes", 0.0))
            target_probs = {"no": 1.0 - float(py), "yes": float(py)}

    task = {
        "id": str(raw.get("id") or f"{ds_name}:{idx}"),
        "state": raw.get("state") if isinstance(raw.get("state"), str)
                 else json.dumps(raw.get("state") or "", ensure_ascii=False),
        "question": {"type": qtype,
                     "instructions": q.get("instructions") or raw.get("instructions") or "",
                     "criteria": crit},
        "labels": labels,
        "expected": expected,
        "tier": raw.get("tier") or "standard",
        "target_probs": target_probs,
    }
    task.update(extra)
    return task


def load_dataset(path, limit=0):
    rows = []
    name = os.path.basename(path)
    with open(path, "r", encoding="utf-8") as f:
        for i, line in enumerate(f):
            line = line.strip()
            if not line:
                continue
            try:
                raw = json.loads(line)
            except Exception:  # noqa: BLE001
                continue
            t = normalize(raw, name, i)
            if t:
                rows.append(t)
    if limit and limit < len(rows):
        # 均匀抽样而不是取前 N 条：数据文件常按 family 排序，取头部会只覆盖一类
        step = len(rows) / float(limit)
        rows = [rows[min(int(i * step), len(rows) - 1)] for i in range(limit)]
    return rows


# ================================================================ 调 API

class Client:
    def __init__(self, host, port, headers, timeout):
        self.host, self.port, self.headers, self.timeout = host, port, headers, timeout
        self.conn = None

    def post(self, path, body):
        if self.conn is None:
            self.conn = http.client.HTTPConnection(self.host, self.port, timeout=self.timeout)
        for attempt in (0, 1):
            try:
                self.conn.request("POST", path, body=body, headers=self.headers)
                r = self.conn.getresponse()
                return r.status, r.read()
            except Exception:  # noqa: BLE001
                try:
                    if self.conn:
                        self.conn.close()
                except Exception:  # noqa: BLE001
                    pass
                self.conn = None
                if attempt:
                    raise
                self.conn = http.client.HTTPConnection(self.host, self.port,
                                                       timeout=self.timeout)


def to_probs(ans, task):
    """对齐到 task.labels；noul 统一成 {"no","yes"}（官方 scorer 要这个键）。"""
    p = (ans or {}).get("probabilities")
    if not isinstance(p, dict) or not p:
        return None
    p = {str(k): float(v) for k, v in p.items()}
    if task["question"]["type"] == "noul":
        # 数据集原本的键可能是 true/false，normalize() 里记在 _yes/_no
        py = None
        for k in (task.get("_yes"), "yes", "true", "True", "1"):
            if k and k in p:
                py = p[k]
                break
        if py is None:
            for k in (task.get("_no"), "no", "false", "False", "0"):
                if k and k in p:
                    py = 1.0 - p[k]
                    break
        if py is None and len(p) == 2:                 # 最后按顺序兜底
            py = list(p.values())[0]
        return None if py is None else {"no": 1.0 - py, "yes": py}
    labels = task["labels"]
    if set(p) == set(labels):
        vals = {k: p[k] for k in labels}
    elif len(p) == len(labels):
        vals = dict(zip(labels, p.values()))
    else:
        return None
    s = sum(vals.values())
    return {k: v / s for k, v in vals.items()} if s > 0 else None


SHAPE_CACHE = {}     # 题型 -> 已知可用的请求形状下标
BROKEN = Counter()   # 题型 -> 连续失败次数（超过 3 次就不再试备选形状）


def payload_shapes(t):
    """同一道题的几种合法请求形状；按"最可能被接受"排序。

    各家 System One 服务约定不同：
      noul  有的要求省略 criteria，有的要求传 false/true 两项
      score 的 criteria 可能是 dict、字符串列表、或 {id, description} 列表
    这里全部准备好，运行时按实际返回自动挑一个。
    """
    q = t["question"]
    crit = q["criteria"]
    base = {"type": q["type"], "instructions": q["instructions"]}
    if q["type"] == "choice":
        out = [dict(base, criteria=crit)]
        if crit:
            out.append(dict(base, criteria=[str(v) for v in crit.values()]))
        return out
    if q["type"] == "noul":
        out = [dict(base)]                       # 官方例子里 noul 不带 options
        if crit:
            out.append(dict(base, criteria=crit))
            out.append(dict(base, criteria=[str(v) for v in crit.values()]))
        return out
    if crit:
        return [dict(base, criteria=crit),
                dict(base, criteria=[str(v) for v in crit.values()]),
                dict(base, criteria=[{"id": k, "description": str(v)}
                                     for k, v in crit.items()])]
    return [base]


def predict(tasks, cfg, state_path, fresh=False, progress=True):
    done = {}
    if os.path.exists(state_path) and not fresh:
        try:
            done = json.load(open(state_path, encoding="utf-8"))
        except Exception:  # noqa: BLE001
            done = {}
    todo = [t for t in tasks if t["id"] not in done]
    if done:
        print(f"      断点续跑：已完成 {len(done)}，本次待做 {len(todo)}")

    lock = threading.Lock()
    n = [0]

    def work(start):
        cli = Client(cfg["host"], cfg["port"], cfg["headers"], cfg["timeout"])
        for i in range(start, len(todo), cfg["conc"]):
            t = todo[i]
            qid = t["id"]
            shapes = payload_shapes(t)
            pref = SHAPE_CACHE.get(t["question"]["type"], 0)
            order = sorted(range(len(shapes)), key=lambda k: (k != pref, k))
            if BROKEN[t["question"]["type"]] >= 3:      # 该题型反复失败，只试首选，避免三倍流量
                order = order[:1]
            rec = {"ok": False, "error": "no_shape"}
            t0 = time.perf_counter()
            for si in order:
                try:
                    payload = {"model": cfg["model"], "state": t["state"],
                               "questions": {qid: shapes[si]}}
                    st, raw = cli.post(cfg["endpoint"],
                                       json.dumps(payload, ensure_ascii=False).encode())
                    if 200 <= st < 300:
                        ans = (json.loads(raw).get("answers") or {}).get(qid) or {}
                        probs = to_probs(ans, t)
                        if probs:
                            rec = {"ok": True, "probs": probs, "shape": si}
                            SHAPE_CACHE[t["question"]["type"]] = si
                            break
                        rec = {"ok": False, "error": "no_probs", "shape": si,
                               "detail": raw[:300].decode("utf-8", "replace")}
                    else:
                        rec = {"ok": False, "error": f"http_{st}", "shape": si,
                               "detail": raw[:300].decode("utf-8", "replace")}
                except Exception as e:  # noqa: BLE001
                    rec = {"ok": False, "error": type(e).__name__, "shape": si,
                           "detail": str(e)[:300]}
            if not rec.get("ok"):
                with lock:
                    BROKEN[t["question"]["type"]] += 1
            rec["ms"] = round((time.perf_counter() - t0) * 1000, 1)
            with lock:
                done[qid] = rec
                n[0] += 1
                if n[0] % 50 == 0:
                    json.dump(done, open(state_path + ".tmp", "w", encoding="utf-8"),
                              ensure_ascii=False)
                    os.replace(state_path + ".tmp", state_path)
                    if progress:
                        print(f"      {n[0]}/{len(todo)}")

    ths = [threading.Thread(target=work, args=(k,), daemon=True) for k in range(cfg["conc"])]
    for t in ths:
        t.start()
    for t in ths:
        t.join()
    json.dump(done, open(state_path, "w", encoding="utf-8"), ensure_ascii=False)
    return done


# ================================================================ 一致性

def consistency(tasks, cfg, n_pairs, rng):
    cand = [t for t in tasks if len(t["labels"]) >= 3]
    rng.shuffle(cand)
    n_order = int(n_pairs * 0.75)
    plan = []
    for t in cand[:n_order]:
        crit = t["question"]["criteria"]
        if isinstance(crit, dict):
            keys = list(crit.keys())
            perm = keys[:]
            for _ in range(5):
                rng.shuffle(perm)
                if perm != keys:
                    break
            plan.append(("order", t, {k: crit[k] for k in perm}))
        else:
            keys = [str(x) for x in crit]
            perm = keys[:]
            for _ in range(5):
                rng.shuffle(perm)
                if perm != keys:
                    break
            plan.append(("order", t, perm))
    for t in cand[n_order:n_order + (n_pairs - n_order)]:
        plan.append(("repeat", t, t["question"]["criteria"]))

    out, lock = {}, threading.Lock()

    def one(i):
        kind, t, crit = plan[i]
        cli = Client(cfg["host"], cfg["port"], cfg["headers"], cfg["timeout"])
        qid = t["id"]
        res = []
        for c in (t["question"]["criteria"], crit):
            try:
                body = json.dumps({"model": cfg["model"], "state": t["state"],
                                   "questions": {qid: {"type": t["question"]["type"],
                                                       "instructions": t["question"]["instructions"],
                                                       "criteria": c}}},
                                  ensure_ascii=False).encode()
                st, raw = cli.post(cfg["endpoint"], body)
                if 200 <= st < 300:
                    ans = (json.loads(raw).get("answers") or {}).get(qid) or {}
                    res.append(to_probs(ans, t))
                else:
                    res.append(None)
            except Exception:  # noqa: BLE001
                res.append(None)
        with lock:
            out[i] = res

    ths = [threading.Thread(target=one, args=(i,), daemon=True) for i in range(len(plan))]
    running = []
    for t in ths:
        t.start()
        running.append(t)
        if len(running) >= cfg["conc"]:
            running[0].join()
            running.pop(0)
    for t in running:
        t.join()

    rows = []
    for i, (kind, t, _) in enumerate(plan):
        a, b = (out.get(i) or [None, None])[:2]
        if not a or not b:
            continue
        keys = set(a) & set(b)
        if not keys:
            continue
        d = 0.5 * sum(abs(a[k] - b[k]) for k in keys)
        rows.append({"id": t["id"], "kind": kind, "tv": round(d, 4),
                     "flip": max(a, key=a.get) != max(b, key=b.get)})
    return rows


# ================================================================ 分析

def reliability(outs, bins=10):
    rows = [(o["conf"], o["correct"]) for o in outs if o.get("conf") is not None]
    if not rows:
        return []
    buckets = [[] for _ in range(bins)]
    for c, ok in rows:
        buckets[min(int(c * bins), bins - 1)].append((c, ok))
    table, total = [], len(rows)
    ece = 0.0
    for i, b in enumerate(buckets):
        if not b:
            continue
        mc = sum(x for x, _ in b) / len(b)
        ma = sum(1 for _, o in b if o) / len(b)
        ece += abs(mc - ma) * len(b) / total
        table.append((i / bins, (i + 1) / bins, len(b), mc, ma, abs(mc - ma)))
    return table, ece


def pctl(vals, p):
    if not vals:
        return 0.0
    s = sorted(vals)
    return s[min(int(len(s) * p), len(s) - 1)]


def audit(tasks):
    """数据体检：OD 的公式对分布有隐含前提，不满足时分数会失真。"""
    from collections import Counter
    types = Counter(t["question"]["type"] for t in tasks)
    tiers = Counter(t["tier"] for t in tasks)
    cells = Counter((t["question"]["type"], t["tier"]) for t in tasks)
    ks = [len(t["labels"]) for t in tasks if t["question"]["type"] == "choice"]
    warns = []

    if len(types) < 3:
        warns.append(f"只有 {len(types)} 种题型（{'/'.join(types)}）；OD 的 Intelligence/Calibration "
                     f"是**三型等权**，缺型时会按存在型归一化，分数不能和 OD 榜单直接比")
    if set(tiers) == {"standard"} or sum(1 for t in tasks if t["tier"] == "standard") == len(tasks):
        warns.append("没有难度分层（全是 standard）；tier 权重 easy .1/.2/.3/.4 失效，"
                     "Intelligence 退化成简单平均")
    hard_choice = cells[("choice", "hard")]
    if hard_choice == 0:
        warns.append("没有 hard 档 choice；官方 Calibration 的 choice 项**只统计 hard**，该项会缺失")
    elif hard_choice < 30:
        warns.append(f"hard 档 choice 只有 {hard_choice} 条；10 桶 ECE 估计不稳（建议 ≥30，最好 ≥100）")
    thin = [(k, v) for k, v in cells.items() if v < 10]
    if thin:
        warns.append("样本过少的格子：" + "、".join(f"{k[0]}/{k[1]}={v}" for k, v in thin[:5]))
    if ks and max(ks) != min(ks):
        warns.append(f"choice 选项数 {min(ks)}~{max(ks)} 不等；chance 基线按 1/K 逐题平均，"
                     f"K 差异大时 competence 会偏向小 K 的题")

    ok = (len(types) == 3 and len(tiers) >= 2 and hard_choice >= 30)
    weak = (not ok) and hard_choice > 0 and len(tiers) >= 2
    return {"types": dict(types), "tiers": dict(tiers),
            "cells": {f"{k[0]}/{k[1]}": v for k, v in sorted(cells.items())},
            "k_min": min(ks) if ks else None, "k_max": max(ks) if ks else None,
            "hard_choice": hard_choice, "warns": warns,
            "od_ok": ok,
            "od_state": "ok" if ok else ("weak" if weak else "na"),
            "od_reason": ("满足：三型齐全、有难度分层、hard choice ≥30" if ok else
                          ("仅供参考：样本不足（" + "、".join(filter(None, [
                              None if len(types) == 3 else f"题型只有 {len(types)} 种",
                              None if hard_choice >= 30 else f"hard choice 仅 {hard_choice} 条"])) + "）"
                           if weak else
                           "缺：" + "、".join(filter(None, [
                               None if len(types) == 3 else f"题型只有 {len(types)} 种",
                               None if len(tiers) >= 2 else "无难度分层",
                               None if hard_choice >= 30 else f"hard choice 仅 {hard_choice} 条"]))))}


def generic_metrics(tasks, probs, bins=10):
    """任何数据集都能算的通用指标：准确率 / 置信度 / ECE / Brier / 覆盖率。"""
    per_type = {}
    allrows = []
    for t in tasks:
        p = probs.get(t["id"])
        if not p:
            continue
        labels = t["labels"]
        vec = [float(p.get(l, 0.0)) for l in labels]
        s = sum(vec)
        if s <= 0:
            continue
        vec = [v / s for v in vec]
        i = max(range(len(vec)), key=lambda k: vec[k])
        pred, conf = labels[i], vec[i]
        correct = (pred == t["expected"])
        brier = nll = None
        if t["expected"] in labels:
            gi = labels.index(t["expected"])
            y = [1.0 if j == gi else 0.0 for j in range(len(vec))]
            brier = sum((a - b) ** 2 for a, b in zip(vec, y))
            nll = -math.log(max(vec[gi], 1e-12))
        row = {"type": t["question"]["type"], "correct": correct, "conf": conf,
               "brier": brier, "nll": nll}
        allrows.append(row)
        per_type.setdefault(row["type"], []).append(row)

    if not allrows:
        return None

    def block(rows):
        n = len(rows)
        acc = sum(1 for r in rows if r["correct"]) / n
        # 分桶 ECE
        buckets = [[] for _ in range(bins)]
        for r in rows:
            buckets[min(int(r["conf"] * bins), bins - 1)].append(r)
        ece, table = 0.0, []
        for bi, b in enumerate(buckets):
            if not b:
                continue
            mc = sum(r["conf"] for r in b) / len(b)
            ma = sum(1 for r in b if r["correct"]) / len(b)
            ece += abs(mc - ma) * len(b) / n
            table.append((bi / bins, (bi + 1) / bins, len(b), mc, ma, abs(mc - ma)))
        srt = sorted(rows, key=lambda r: -r["conf"])
        k = max(1, int(n * 0.9))
        return {"n": n, "acc": acc,
                "conf": sum(r["conf"] for r in rows) / n,
                "ece": ece, "table": table,
                "brier": sum(r["brier"] for r in rows if r["brier"] is not None)
                / max(1, sum(1 for r in rows if r["brier"] is not None)),
                "nll": sum(r["nll"] for r in rows if r["nll"] is not None)
                / max(1, sum(1 for r in rows if r["nll"] is not None)),
                "cov90": sum(1 for r in srt[:k] if r["correct"]) / k}

    out = block(allrows)
    out["by_type"] = {t: block(v) for t, v in per_type.items()}
    out["covered"] = len(allrows)
    return out


def item_rows(tasks, preds, probs):
    """逐条明细：模型选了哪个、置信多少、对错、耗时、失败原因。"""
    rows = []
    for t in tasks:
        p = probs.get(t["id"])
        r = preds.get(t["id"]) or {}
        row = {"id": t["id"], "type": t["question"]["type"], "gold": t["expected"]}
        if p:
            labels = t["labels"]
            vec = [float(p.get(l, 0.0)) for l in labels]
            s = sum(vec) or 1.0
            vec = [v / s for v in vec]
            i = max(range(len(vec)), key=lambda k: vec[k])
            row.update(pred=labels[i], conf=round(vec[i], 4),
                       correct=(labels[i] == t["expected"]),
                       probs={k: round(v, 4) for k, v in zip(labels, vec)})
        else:
            row.update(pred=None, conf=None, correct=None,
                       error=r.get("error"), detail=(r.get("detail") or "")[:300])
        row["ms"] = r.get("ms")
        rows.append(row)
    return rows


def analyze(tasks, preds):
    """返回该数据集的完整分析；打分失败不抛异常，返回 error 让主流程继续。"""
    probs = {}
    for t in tasks:
        r = preds.get(t["id"])
        if r and r.get("ok"):
            probs[t["id"]] = r["probs"]
    gen = generic_metrics(tasks, probs)
    try:
        result = official.score(tasks, [{"id": k, "probs": v} for k, v in probs.items()])
    except Exception as e:  # noqa: BLE001
        bad = [k for k, v in probs.items() if abs(sum(v.values()) - 1.0) > 0.01]
        return {"error": f"{type(e).__name__}: {e}", "bad": bad[:5], "generic": gen,
                "latency": {}, "fails": 0, "errs": {}, "reliability": [],
                "err_samples": [], "items": item_rows(tasks, preds, probs),
                "result": {"capability": None, "intelligence": None, "calibration": None,
                           "accuracy_per_type": {}, "competence_per_type": {},
                           "calibration_per_type": {}, "predicted": len(probs),
                           "items": len(tasks)}}

    outs = []
    for t in tasks:
        try:
            outs.append(official.item_outcome(t, probs.get(t["id"])))
        except Exception:  # noqa: BLE001
            continue
    rel = reliability(outs)

    ms = sorted(r["ms"] for r in preds.values() if r.get("ms"))
    fails = [r for r in preds.values() if not r.get("ok")]
    from collections import Counter
    errs = Counter(r.get("error") for r in fails)
    samples, seen = [], set()
    for r in fails:
        key = (r.get("error"), (r.get("detail") or "")[:100])
        if key in seen:
            continue
        seen.add(key)
        samples.append({"error": r.get("error"), "detail": (r.get("detail") or "")[:200]})
        if len(samples) >= 3:
            break

    return {"result": result, "generic": gen, "reliability": rel, "latency": {
        "p50": pctl(ms, 0.5), "p95": pctl(ms, 0.95), "n": len(ms)},
        "fails": len(fails), "errs": dict(errs), "err_samples": samples,
        "items": item_rows(tasks, preds, probs)}


# ================================================================ 报告

def fmt(x, nd=1, suffix=""):
    return "—" if x is None else f"{x:.{nd}f}{suffix}"


def pctv(x, nd=1):
    """比率类指标按百分比显示。"""
    return "—" if x is None else f"{x * 100:.{nd}f}%"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default=os.path.join(HERE, "config.ini"))
    ap.add_argument("--base")
    ap.add_argument("--model")
    ap.add_argument("--api-key")
    ap.add_argument("--dataset", help="只跑某一个文件名")
    ap.add_argument("--limit", type=int, default=0, help="每个数据集最多多少条")
    ap.add_argument("--concurrency", type=int, default=0)
    ap.add_argument("--out-dir")
    ap.add_argument("--fresh", action="store_true")
    ap.add_argument("--pairs", type=int, default=-1, help="每个数据集的一致性对数")
    a = ap.parse_args()

    cp = configparser.ConfigParser(interpolation=None)
    if not os.path.exists(a.config):
        raise SystemExit(f"找不到配置：{a.config}")
    cp.read(a.config, encoding="utf-8")

    base = a.base or cget(cp, "api", "base", "http://127.0.0.1:9900")
    endpoint = cget(cp, "api", "endpoint", "/v1/systemone")
    model = a.model or cget(cp, "api", "model", "")
    key = a.api_key or os.environ.get("JEV_API_KEY") or cget(cp, "api", "api_key", "")
    ds_dir = cget(cp, "run", "datasets", "datasets")
    ds_dir = ds_dir if os.path.isabs(ds_dir) else os.path.join(HERE, ds_dir)
    out_root = a.out_dir or cget(cp, "run", "out_dir", "results")
    out_root = out_root if os.path.isabs(out_root) else os.path.join(HERE, out_root)
    limit = a.limit or int(cget(cp, "run", "limit", "0"))
    pairs = a.pairs if a.pairs >= 0 else int(cget(cp, "run", "consistency_pairs", "100"))
    bins = int(cget(cp, "run", "bins", "10"))
    conc = a.concurrency or int(cget(cp, "api", "concurrency", "8"))
    timeout = float(cget(cp, "api", "timeout", "120"))

    u = urllib.parse.urlparse(base)
    if not u.hostname:
        raise SystemExit(f"base 不合法：{base}")
    headers = {"Content-Type": "application/json", "Connection": "keep-alive"}
    if key:
        headers["Authorization"] = f"Bearer {key}"
    if not model:
        try:
            with urllib.request.urlopen(f"{base}/v1/models", timeout=8) as r:
                j = json.loads(r.read().decode("utf-8", "replace"))
            it = (j.get("data") or j.get("models") or [])
            model = (it[0].get("id") or it[0].get("name")) if it else ""
        except Exception:  # noqa: BLE001
            pass
    if not model:
        raise SystemExit("无法确定 model：请在 config.ini 的 [api] model 填写")

    files = sorted(f for f in os.listdir(ds_dir) if f.endswith(".jsonl"))
    if a.dataset:
        files = [f for f in files if f == a.dataset]
    if not files:
        raise SystemExit(f"{ds_dir} 下没有 .jsonl")

    slug = re.sub(r"[^\w.\-]+", "_", model)[:60]
    outdir = os.path.join(out_root, slug)
    os.makedirs(os.path.join(outdir, ".state"), exist_ok=True)

    cfg = {"host": u.hostname, "port": u.port or 8000, "endpoint": endpoint,
           "headers": headers, "timeout": timeout, "conc": conc, "model": model}

    print(SEP)
    print("Jev 数据集测评")
    print(f"  模型 : {model}")
    print(f"  服务 : {base}{endpoint}   并发 {conc}")
    print(f"  数据 : {ds_dir}（{len(files)} 个文件）")
    print(f"  输出 : {outdir}")
    print(SEP)

    all_res = []
    for name in files:
        print(f"\n[{name}]")
        tasks = load_dataset(os.path.join(ds_dir, name), limit)
        if not tasks:
            print("      跳过：没有可解析的样本")
            continue
        print(f"      {len(tasks)} 条")
        au = audit(tasks)
        for w in au["warns"]:
            print(f"      ⚠ {w[:90]}")
        st_path = os.path.join(outdir, ".state", f"{name}.json")
        preds = predict(tasks, cfg, st_path, fresh=a.fresh)
        ana = analyze(tasks, preds)
        cons = consistency(tasks, cfg, pairs, random.Random(20261110)) if pairs else []
        items_dir = os.path.join(outdir, "items")
        os.makedirs(items_dir, exist_ok=True)
        with open(os.path.join(items_dir, f"{os.path.splitext(name)[0]}.jsonl"), "w",
                  encoding="utf-8") as f:
            for row in ana.get("items") or []:
                f.write(json.dumps(row, ensure_ascii=False) + "\n")
        all_res.append({"name": name, "n": len(tasks), "analyze": ana,
                        "cons": cons, "audit": au})
        r = ana["result"]
        g = ana.get("generic") or {}
        print(f"      准确率 {g.get('acc', 0):.4f}  ECE {g.get('ece', 0):.4f}  "
              f"置信 {g.get('conf', 0):.4f}", end="")
        if au["od_state"] != "na":
            print(f"  |  Capability {fmt(r['capability'])}  "
                  f"Intel {fmt(r['intelligence'])}  Cal {fmt(r['calibration'])}"
                  + ("（参考）" if au["od_state"] == "weak" else ""))
        else:
            print(f"  |  OD 不适用（{au['od_reason']}）")
        if ana.get("error"):
            print(f"      ! 打分失败：{ana['error']}")
            if ana.get("bad"):
                print(f"        概率异常的条目：{ana['bad']}")

    if not all_res:
        raise SystemExit("没有产出任何结果")

    # ---- 汇总
    def agg(key):
        vals = [x["analyze"]["result"][key] for x in all_res
                if x["analyze"]["result"].get(key) is not None]
        return sum(vals) / len(vals) if vals else None

    md = [f"# {model} 测评报告", "",
          f"> 数据集 {len(all_res)} 个 ｜ 目标 {base}{endpoint} ｜ 并发 {conc}", "",
          "## 0. 总览", "",
          "| 数据集 | 条数 | 准确率 | ECE | 平均置信 | Capability | 一致性TV | 覆盖 |",
          "|---|---|---|---|---|---|---|---|"]
    for x in all_res:
        r = x["analyze"]["result"]
        g = x["analyze"].get("generic") or {}
        tv = (sum(c["tv"] for c in x["cons"]) / len(x["cons"])) if x["cons"] else None
        cap = ((fmt(r["capability"]) + ("*" if x["audit"]["od_state"] == "weak" else ""))
               if x["audit"]["od_state"] != "na" else "—")
        md.append(f"| {x['name']} | {x['n']} | {pctv(g.get('acc'))} | "
                  f"{pctv(g.get('ece'))} | {pctv(g.get('conf'))} | "
                  f"**{cap}** | {'—' if tv is None else f'{tv:.4f}'} | "
                  f"{r['predicted']}/{r['items']} |")
    md += ["", "> 准确率/ECE/置信度是通用指标，任何数据集都能算；Capability 只有在满足 OD 前提时才给，"
               "否则显示 `—`（原因见各数据集小节）。", ""]

    for x in all_res:
        r = x["analyze"]["result"]
        au = x["audit"]
        g = x["analyze"].get("generic") or {}
        md += ["", f"## {x['name']}", ""]
        if au["warns"]:
            md += ["> ⚠️ 数据分布注意事项：", ">"] + [f"> - {w}" for w in au["warns"]] + [""]
        md += [f"**数据体检**：{x['n']} 条 ｜ 题型 {au['types']} ｜ 难度 {au['tiers']} ｜ "
               f"hard choice {au['hard_choice']} 条"
               + (f" ｜ choice 选项数 {au['k_min']}~{au['k_max']}" if au['k_min'] else ""), ""]

        # ---- 通用指标（永远有）
        if g:
            md += ["### 通用指标（任何数据集适用）", "",
                   "| 指标 | 值 |", "|---|---|",
                   f"| 准确率 ACC | **{pctv(g['acc'])}** |",
                   f"| 平均置信度 | {pctv(g['conf'])} |",
                   f"| 校准误差 ECE | {pctv(g['ece'])} |",
                   f"| Brier | {g['brier']:.4f} |",
                   f"| NLL | {g['nll']:.4f} |",
                   f"| 覆盖 90% 的准确率 | {pctv(g['cov90'])} |",
                   f"| 计分条数 | {g['covered']}/{x['n']} |",
                   f"| 延迟 p50 / p95 | {x['analyze']['latency'].get('p50', 0):.0f} / "
                   f"{x['analyze']['latency'].get('p95', 0):.0f} ms |",
                   f"| 失败 | {x['analyze']['fails']}"
                   + (f"（{x['analyze']['errs']}）" if x['analyze']['errs'] else "") + " |"]
            for s in (x["analyze"].get("err_samples") or []):
                md += [f"| ↳ {s['error']} | `{(s['detail'] or '')[:120]}` |"]
            md += ["", "| 题型 | n | 准确率 | ECE |", "|---|---|---|---|"]
            for t, b in g["by_type"].items():
                md.append(f"| {t} | {b['n']} | {pctv(b['acc'])} | {pctv(b['ece'])} |")
            if g["table"]:
                md += ["", "**可靠性**（置信度 vs 实际准确率）", "",
                       "| 置信区间 | n | 平均置信 | 实际准确 | 偏差 |", "|---|---|---|---|---|"]
                for lo, hi, n, mc, ma, gap in g["table"]:
                    md.append(f"| {lo:.1f}–{hi:.1f} | {n} | {mc:.3f} | {ma:.3f} | {gap:.3f} |")

        # ---- OD 口径（有条件）
        md += ["", "### OD 口径（与榜单可比的前提）", ""]
        if x["analyze"].get("error"):
            md += [f"> ⚠️ 打分失败：`{x['analyze']['error']}`",
                   f"> 概率异常的条目（前 5 个）：{x['analyze'].get('bad')}"]
        elif au["od_state"] != "na":
            md += ["| 指标 | 值 |", "|---|---|",
                   f"| Capability | **{fmt(r['capability'])}** |",
                   f"| Intelligence | {fmt(r['intelligence'])} |",
                   f"| Calibration | {fmt(r['calibration'])} |", "",
                   "| 题型 | 准确率 | 能力 | 校准 |", "|---|---|---|---|"]
            for t in ("choice", "noul", "score"):
                if t in r["accuracy_per_type"]:
                    md.append(f"| {t} | {r['accuracy_per_type'][t]:.1f}% | "
                              f"{fmt(r['competence_per_type'].get(t))} | "
                              f"{fmt(r['calibration_per_type'].get(t))} |")
            if r.get("calibration_items_tvd") is not None:
                md += ["", f"真概率题（{r['calibration_items']} 条）平均 TVD："
                           f"**{r['calibration_items_tvd']:.3f}**"]
            if au["od_state"] == "weak":
                md += ["", f"> ⚠️ 仅参考：{au['od_reason']}。样本不足时 ECE 与 tier 权重都不稳。"]

        else:
            md += [f"> 不适用 —— {au['od_reason']}。",
                   "> 这套公式依赖 tier 加权与 hard 档 choice，条件不满足时数字会失真，"
                   "**请以上面的通用指标为准**。"]

        # ---- 一致性
        if x["cons"]:
            tvs = [c["tv"] for c in x["cons"]]
            order = [c["tv"] for c in x["cons"] if c["kind"] == "order"]
            rep = [c["tv"] for c in x["cons"] if c["kind"] == "repeat"]
            md += ["", "### 一致性", "", "| 变体 | 对数 | TV 均值 | 通过率(≤0.05) |",
                   "|---|---|---|---|"]
            if order:
                md.append(f"| 换序 | {len(order)} | {sum(order)/len(order):.4f} | "
                          f"{sum(1 for v in order if v <= 0.05)/len(order):.1%} |")
            if rep:
                md.append(f"| 重复 | {len(rep)} | {sum(rep)/len(rep):.4f} | "
                          f"{sum(1 for v in rep if v <= 0.05)/len(rep):.1%} |")
            md += ["", f"整体 TV 均值 {sum(tvs)/len(tvs):.4f}，"
                       f"翻转率 {sum(1 for c in x['cons'] if c['flip'])/len(tvs):.1%}"]

    md += ["", "## 指标说明", "",
           "| 缩写 | 全称 | 含义 | 方向 |", "|---|---|---|---|",
           "| ACC | Accuracy | argmax 命中标准答案的比例 | 越高越好 |",
           "| Conf | Confidence | 模型自报的把握（被选中选项的概率） | — |",
           "| ECE | Expected Calibration Error | 按置信度分 10 桶，比较「平均置信」与「实际准确率」，"
           "加权平均偏差。0.05 以内算可信，0.10 以上不能用于自动放行 | 越低越好 |",
           "| Brier | Brier Score | 概率与 one-hot 真值的均方误差 Σ(p−y)²，同时惩罚「错得自信」 | 越低越好 |",
           "| NLL | Negative Log-Likelihood | −log p(正确答案)，对极端错误惩罚更重 | 越低越好 |",
           "| Cov@90 | Coverage at 90% | 只放行置信度最高的 90%，这批的准确率 | 越高越好 |",
           "| TV | Total Variation | 两次回答概率分布的差：0.5×Σ\\|p−q\\|，0 完全一致、1 完全相反 | 越低越好 |",
           "| Capability | — | OD 综合分 =(Intelligence+Calibration)/2，**不是准确率** | 越高越好 |",
           "| Intelligence | — | 扣掉随机猜对基线、按难度加权后的能力分 | 越高越好 |",
           "| Calibration | — | 概率可信度分 = 100×(1−ECE/0.5)，choice 只统计 hard 档 | 越高越好 |",
           "", "> 通用指标（ACC/ECE/Brier/NLL/Cov@90）任何数据集都能算；"
               "Capability/Intelligence/Calibration 只有满足 OD 前提才给。", ""]

    md += ["", "## 逐条明细", "",
           "每个数据集一份，便于定位具体是哪条错、错成什么样：", "",
           "```", "results/<模型名>/items/<数据集名>.jsonl",
           '{"id","type","gold","pred","conf","correct","probs","ms","error","detail"}', "```", ""]

    md += ["", "## 口径", "",
           "- **通用指标**（准确率/ECE/Brier/覆盖率）与数据分布无关，任何数据集都能算、都能横向比。",
           "- **OD 口径**（Capability/Intelligence/Calibration）由官方 `od/score.py` 计算，"
           "仅在三型齐全、有难度分层、hard choice ≥30 时才给出。",
           "- Capability 不是准确率：Intelligence 已扣除随机猜对的基线，并按 tier 加权。",
           "- Calibration 的 choice 只统计 hard 档，缺 hard 档时该题型不参与。",
           "- 没预测的条目在 OD 口径里按错处理（官方约定），在通用指标里不计入分母。", ""]

    json.dump({"model": model,
               "datasets": [{"name": x["name"], "n": x["n"],
                             "generic": x["analyze"].get("generic"),
                             "od_applicable": x["audit"]["od_state"] != "na",
                             "result": x["analyze"]["result"],
                             "audit": x["audit"],
                             "latency": x["analyze"]["latency"],
                             "fails": x["analyze"]["fails"],
                             "errs": x["analyze"]["errs"],
                             "reliability": x["analyze"]["reliability"][0]
                             if x["analyze"]["reliability"] else [],
                             "consistency": x["cons"]} for x in all_res]},
              open(os.path.join(outdir, f"{slug}.json"), "w", encoding="utf-8"),
              ensure_ascii=False, indent=1)

    with open(os.path.join(outdir, f"{slug}.csv"), "w", encoding="utf-8") as f:
        f.write("dataset,n,acc,ece,conf,capability,intelligence,calibration,od_state,"
                "coverage,consistency_tv\n")
        for x in all_res:
            r = x["analyze"]["result"]
            g = x["analyze"].get("generic") or {}
            tv = (sum(c["tv"] for c in x["cons"]) / len(x["cons"])) if x["cons"] else ""
            cap = r["capability"] if x["audit"]["od_state"] != "na" else ""
            f.write(f"{x['name']},{x['n']},{g.get('acc','')},{g.get('ece','')},"
                    f"{g.get('conf','')},{cap},"
                    f"{r['intelligence'] if x['audit']['od_state'] != 'na' else ''},"
                    f"{r['calibration'] if x['audit']['od_state'] != 'na' else ''},"
                    f"{x['audit']['od_state']},{r['predicted']}/{r['items']},{tv}\n")

    rpt = os.path.join(outdir, f"{slug}.md")
    open(rpt, "w", encoding="utf-8").write("\n".join(md))
    print("\n" + "\n".join(md[:22]))
    print(f"\n报告：{rpt}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
