#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
make_od_dataset.py —— 把任意 jsonl 转成「OD 可测」格式（含质量筛选与难度初判）

做什么
    1. 规范化：补齐 OD 需要的字段（labels / expected / tier / question.criteria）
    2. 过滤：去重、去 gold 不在选项里、去空 state、去空选项
    3. 难度：先用规则打 tier（easy/standard/judge/hard），
       可选让 LLM 复核（更准，但慢、要钱）
    4. 质检（可选）：LLM 判断"题目是否自洽、gold 是否唯一"，给出 keep/drop + 理由
    5. 体检（可选）：拿 jev 模型跑一遍，标出"模型几乎在瞎猜"的题（**只标记，不删**）

红线
    - gold 必须来自原数据或人工，**绝不能用被测模型生成**
    - jev 体检只用于标记，不参与筛题，否则评测集会被模型"挑过"
    - LLM 给的是初判，最终要人工抽检 + 用准确率单调性回验 tier

用法
    python make_od_dataset.py --src datasets_raw/dft.jsonl --out od_ready
    python make_od_dataset.py --src ... --llm-tier --llm-check      # 用 LLM 辅助
    python make_od_dataset.py --src ... --jev-check                 # 额外做可答性体检
"""

import argparse
import configparser
import hashlib
import http.client
import json
import os
import re
import sys
import threading
import time
import urllib.parse
import urllib.request
from collections import Counter, defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import evaluate as E  # noqa: E402  复用 normalize / 客户端

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:  # noqa: BLE001
    pass

TIERS = ("easy", "standard", "judge", "hard")
SEP = "=" * 78


# ================================================================ LLM

class LLM:
    def __init__(self, base, model, key, timeout=120):
        u = urllib.parse.urlparse(base)
        self.host, self.port = u.hostname, u.port or 8000
        self.path = (u.path.rstrip("/") or "") + "/chat/completions"
        self.model, self.timeout = model, timeout
        self.headers = {"Content-Type": "application/json"}
        if key:
            self.headers["Authorization"] = f"Bearer {key}"
        self._tls = threading.local()

    def _conn(self):
        c = getattr(self._tls, "c", None)
        if c is None:
            c = http.client.HTTPConnection(self.host, self.port, timeout=self.timeout)
            self._tls.c = c
        return c

    def chat(self, system, user, max_tokens=200):
        body = json.dumps({"model": self.model, "temperature": 0, "max_tokens": max_tokens,
                           "messages": [{"role": "system", "content": system},
                                        {"role": "user", "content": user}]},
                          ensure_ascii=False).encode()
        for attempt in (0, 1):
            try:
                c = self._conn()
                c.request("POST", self.path, body=body, headers=self.headers)
                r = c.getresponse()
                raw = r.read()
                if not (200 <= r.status < 300):
                    raise RuntimeError(f"HTTP {r.status}: {raw[:120]}")
                j = json.loads(raw)
                return j["choices"][0]["message"]["content"]
            except Exception:
                try:
                    self._conn().close()
                except Exception:  # noqa: BLE001
                    pass
                self._tls.c = None
                if attempt:
                    raise
        return ""


def parse_json(text):
    if not text:
        return None
    m = re.search(r"\{.*\}", text, re.S)
    if not m:
        return None
    try:
        return json.loads(m.group(0))
    except Exception:  # noqa: BLE001
        return None


# ================================================================ 规则打 tier

def rule_tier(task):
    """粗判：只作为草稿，最终要用准确率单调性回验。"""
    crit = task["question"]["criteria"]
    n = len(crit)
    state = task["state"] or ""
    text = state + " " + (task["question"]["instructions"] or "")
    L = len(state)

    if "冲突" in text or "矛盾" in text or "例外" in text or "歧义" in text:
        return "hard"
    if n >= 6 or L >= 2500:
        return "hard"
    if any(k in text for k in ("阈值", "合规", "评审", "规程", "标准条款", "校验规则")):
        return "judge"
    if n <= 3 and L <= 600:
        return "easy"
    return "standard"


# ================================================================ 主流程

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default=os.path.join(HERE, "config.ini"))
    ap.add_argument("--src", required=True, help="输入 jsonl（可逗号分隔多个）")
    ap.add_argument("--out", default="od_ready")
    ap.add_argument("--name", default="", help="输出文件名（默认取输入名）")
    ap.add_argument("--keep-gold", action="store_true",
                    help="保留原 gold（默认就是保留；此开关仅为显式声明）")
    ap.add_argument("--llm-tier", action="store_true", help="用 LLM 复核难度档")
    ap.add_argument("--llm-check", action="store_true", help="用 LLM 做质量筛选")
    ap.add_argument("--jev-check", action="store_true", help="用 jev 做可答性体检（只标记）")
    ap.add_argument("--concurrency", type=int, default=8)
    ap.add_argument("--llm-base", default="", help="覆盖 config 的 [llm] base")
    ap.add_argument("--llm-model", default="", help="覆盖 config 的 [llm] model")
    ap.add_argument("--llm-key", default="", help="覆盖 config 的 [llm] api_key")
    a = ap.parse_args()

    cp = configparser.ConfigParser(interpolation=None)
    if os.path.exists(a.config):
        cp.read(a.config, encoding="utf-8")
    llm_cfg = {"base": a.llm_base or E.cget(cp, "llm", "base", ""),
               "model": a.llm_model or E.cget(cp, "llm", "model", ""),
               "key": a.llm_key or E.cget(cp, "llm", "api_key", "")}
    jev_base = E.cget(cp, "api", "base", "http://127.0.0.1:9900")
    jev_ep = E.cget(cp, "api", "endpoint", "/v1/systemone")
    jev_model = E.cget(cp, "api", "model", "")

    outdir = a.out if os.path.isabs(a.out) else os.path.join(HERE, a.out)
    os.makedirs(outdir, exist_ok=True)

    # ---- 1. 读入 + 规范化
    srcs = [s.strip() for s in a.src.split(",") if s.strip()]
    kept, dropped = [], []
    seen = set()
    for src in srcs:
        if not os.path.isabs(src):
            src = os.path.join(HERE, src)
        rows = [json.loads(l) for l in open(src, encoding="utf-8") if l.strip()]
        for i, raw in enumerate(rows):
            t = E.normalize(raw, os.path.basename(src), i)
            if not t:
                dropped.append({"src": src, "line": i, "reason": "字段不完整/无法解析"})
                continue
            if not (t["state"] or "").strip():
                dropped.append({"id": t["id"], "reason": "state 为空"})
                continue
            if len(t["labels"]) < 2:
                dropped.append({"id": t["id"], "reason": "选项少于 2 个"})
                continue
            # 去重：state + instructions + 选项集合（同一个情景可以有不同选项的题，不能误杀）
            sig = (t["state"] + "|" + t["question"]["instructions"] + "|" +
                   json.dumps(t["question"]["criteria"], ensure_ascii=False, sort_keys=True))
            h = hashlib.sha256(sig.encode()).hexdigest()[:16]
            if h in seen:
                dropped.append({"id": t["id"], "reason": "重复"})
                continue
            seen.add(h)
            kept.append(t)

    print(SEP)
    print(f"读入 {len(kept) + len(dropped)} 条 → 保留 {len(kept)}，丢弃 {len(dropped)}")
    for r, c in Counter(d["reason"] for d in dropped).most_common():
        print(f"  丢弃 {r}: {c}")

    # ---- 2. 规则 tier
    for t in kept:
        t["tier"] = rule_tier(t)

    # ---- 3. LLM 辅助（可选）
    if a.llm_tier or a.llm_check:
        if not (llm_cfg["base"] and llm_cfg["model"]):
            print("! 未配置 [llm]，跳过 LLM 辅助")
        else:
            llm = LLM(llm_cfg["base"], llm_cfg["model"], llm_cfg["key"])
            lock = threading.Lock()
            q = list(range(len(kept)))
            n = [0]

            def work(start):
                for i in range(start, len(q), a.concurrency):
                    t = kept[q[i]]
                    opts = "\n".join(f"- {k}: {v}" for k, v in
                                     t["question"]["criteria"].items())
                    user = (f"状态：\n{t['state'][:2000]}\n\n"
                            f"问题：{t['question']['instructions']}\n\n选项：\n{opts}\n\n"
                            f"标准答案：{t['expected']}\n题型：{t['question']['type']}")
                    try:
                        if a.llm_tier:
                            r = parse_json(llm.chat(
                                "你是出题审校。按难度把题目分成 easy/standard/judge/hard。"
                                "easy=单条证据直接可判；standard=需简单比对；"
                                "judge=需专业规则或领域知识；hard=证据冲突/多步推理/信息不全。"
                                '只输出 JSON：{"tier":"...","reason":"不超过15字"}', user, 120))
                            if r and r.get("tier") in TIERS:
                                t["tier"] = r["tier"]
                                t["tier_reason"] = r.get("reason", "")
                        if a.llm_check:
                            r2 = parse_json(llm.chat(
                                "你是数据质检员。判断这道题是否合格：标准答案是否唯一正确、"
                                "选项是否有歧义、信息是否足够作答。"
                                '只输出 JSON：{"keep":true/false,"reason":"不超过15字"}', user, 120))
                            if r2 and r2.get("keep") is False:
                                t["_drop"] = r2.get("reason") or "LLM 判定不合格"
                    except Exception as e:  # noqa: BLE001
                        t["llm_error"] = str(e)[:80]
                    with lock:
                        n[0] += 1
                        if n[0] % 50 == 0:
                            print(f"      LLM {n[0]}/{len(q)}")

            ths = [threading.Thread(target=work, args=(k,), daemon=True)
                   for k in range(a.concurrency)]
            for th in ths:
                th.start()
            for th in ths:
                th.join()

            bad = [t for t in kept if t.get("_drop")]
            for t in bad:
                dropped.append({"id": t["id"], "reason": "LLM: " + t["_drop"]})
            kept = [t for t in kept if not t.get("_drop")]
            print(f"  LLM 筛掉 {len(bad)} 条")

    # ---- 4. jev 可答性体检（只标记）
    if a.jev_check:
        u = urllib.parse.urlparse(jev_base)
        headers = {"Content-Type": "application/json"}
        lock = threading.Lock()

        def work(start):
            cli = E.Client(u.hostname, u.port or 8000, headers, 120)
            for i in range(start, len(kept), a.concurrency):
                t = kept[i]
                try:
                    body = json.dumps({"model": jev_model, "state": t["state"],
                                       "questions": {"q0": E.payload_shapes(t)[0]}},
                                      ensure_ascii=False).encode()
                    st, raw = cli.post(jev_ep, body)
                    if 200 <= st < 300:
                        ans = (json.loads(raw).get("answers") or {}).get("q0") or {}
                        p = E.to_probs(ans, t)
                        if p:
                            top = max(p.values())
                            t["jev_top"] = round(top, 3)
                            k = max(2, len(t["labels"]))
                            t["jev_ambiguous"] = (top - 1.0 / k) < 0.05
                except Exception:  # noqa: BLE001
                    pass
                with lock:
                    pass

        ths = [threading.Thread(target=work, args=(k,), daemon=True)
               for k in range(a.concurrency)]
        for th in ths:
            th.start()
        for th in ths:
            th.join()
        amb = sum(1 for t in kept if t.get("jev_ambiguous"))
        print(f"  jev 体检：{amb}/{len(kept)} 条接近随机猜（已标记，不删除）")

    # ---- 5. 输出
    name = a.name or os.path.splitext(os.path.basename(srcs[0]))[0]
    out_path = os.path.join(outdir, f"{name}.jsonl")
    with open(out_path, "w", encoding="utf-8") as f:
        for t in kept:
            row = {"id": t["id"], "state": t["state"],
                   "question": {"type": t["question"]["type"],
                                "instructions": t["question"]["instructions"],
                                "criteria": t["question"]["criteria"]},
                   "labels": t["labels"], "expected": t["expected"], "tier": t["tier"]}
            if t.get("target_probs"):
                row["target_probs"] = t["target_probs"]
            if t.get("tier_reason"):
                row["tier_reason"] = t["tier_reason"]
            if t.get("jev_top") is not None:
                row["jev_top"] = t["jev_top"]
            if t.get("jev_ambiguous"):
                row["jev_ambiguous"] = True
            f.write(json.dumps(row, ensure_ascii=False) + "\n")

    with open(os.path.join(outdir, f"{name}.dropped.jsonl"), "w", encoding="utf-8") as f:
        for d in dropped:
            f.write(json.dumps(d, ensure_ascii=False) + "\n")

    types = Counter(t["question"]["type"] for t in kept)
    tiers = Counter(t["tier"] for t in kept)
    hard_choice = sum(1 for t in kept
                      if t["question"]["type"] == "choice" and t["tier"] == "hard")
    ok = (len(types) == 3 and len(tiers) >= 2 and hard_choice >= 30)

    md = [f"# 数据集转换报告：{name}", "",
          f"- 输出：`{os.path.relpath(out_path, HERE)}`（{len(kept)} 条）",
          f"- 丢弃：{len(dropped)} 条", "",
          "## 分布", "",
          "| 维度 | 分布 |", "|---|---|",
          f"| 题型 | {dict(types)} |",
          f"| 难度 | {dict(tiers)} |",
          f"| hard 档 choice | {hard_choice} 条 |", "",
          "## OD 可测性", "",
          f"- 三型齐全：{'✅' if len(types) == 3 else '❌'}　"
          f"难度 ≥2 档：{'✅' if len(tiers) >= 2 else '❌'}　"
          f"hard choice ≥30：{'✅' if hard_choice >= 30 else '❌'}",
          f"- 结论：**{'可以直接用 OD 口径' if ok else '只能算通用指标（原因见上）'}**", "",
          "## 注意", "",
          "- tier 是规则/LLM 初判，必须用「准确率随难度单调下降」回验，否则加权无意义。",
          "- jev 体检只标记不筛题：被标记的题说明模型在瞎猜，不代表题不好。",
          "- gold 全部沿用原数据，未由任何模型生成。", ""]
    rpt = os.path.join(outdir, f"{name}.转换报告.md")
    open(rpt, "w", encoding="utf-8").write("\n".join(md))

    print("\n" + "\n".join(md))
    print(f"\n产物：{out_path}")
    print(f"报告：{rpt}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
