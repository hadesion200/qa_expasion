#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
build_set.py —— 把公开数据集转成统一的评测集（items.jsonl）

三路数据 → 一种格式，后续所有指标（acc / ece / 一致性）都只认这一种格式。

    s1mb_dataset/           106 个任务，test 分片 14,009 行 / 26,269 个决策
    jev-distill-corpus-v3/  test 14,261 条（choice 3,620 / noul 7,298 / score 3,343）
    TruthfulQA/             817 条 mc1

统一格式（一行 = 一个决策，不是一行 = 一道题）：
    {
      "item_id": "s1mb:arc:test:27:answer",
      "src": "s1mb", "task": "arc", "group_id": "...",
      "type": "choice",                    # choice | noul | score
      "state": "...",                      # 原样给模型
      "question": {"type": "choice", "instructions": "...",
                   "criteria": {"B": "Object 1, Object 3, Object 2", ...}},
      "gold": {"ids": ["B","C","A","D"], "probs": [1,0,0,0],
               "label": "B", "annotation": "hard_label"},
      "meta": {"language": "en", "n_options": 4}
    }

用法（在有 pyarrow 的机器上跑，比如这台 Windows）：
    python build_set.py --root "C:\\Users\\18227\\Desktop\\中继数据\\System-one_temp\\DataBase"
    python build_set.py --limit-s1mb 30 --limit-distill 800 --limit-tqa 300
    python build_set.py --tasks arc,contract_nli --limit-s1mb 3      # 冒烟
"""

import argparse
import hashlib
import json
import os
import random
from collections import Counter

try:
    import pyarrow as pa
    import pyarrow.ipc as ipc
except ImportError:  # pragma: no cover
    pa = ipc = None


def jload(v, default=None):
    """s1mb 里很多字段是「JSON 字符串套 JSON」，统一拆开。"""
    if v is None:
        return default
    if isinstance(v, (dict, list, int, float, bool)):
        return v
    s = str(v).strip()
    if not s:
        return default
    try:
        return json.loads(s)
    except Exception:  # noqa: BLE001
        return default if default is not None else s


# ================================================================ s1mb

def load_arrow(path):
    with pa.memory_map(path, "r") as src:
        try:
            return ipc.open_file(src).read_all()
        except Exception:  # noqa: BLE001
            src.seek(0)
            return ipc.open_stream(src).read_all()


def s1mb_items(root, tasks, limit, seed):
    base = os.path.join(root, "s1mb_dataset")
    out = []
    for task in tasks:
        d = os.path.join(base, task, "test")
        if not os.path.isdir(d):
            continue
        files = [f for f in os.listdir(d) if f.endswith(".arrow")]
        if not files:
            continue
        tb = load_arrow(os.path.join(d, files[0]))
        n = tb.num_rows
        idx = list(range(n))
        if limit and limit < n:
            idx = random.Random(seed).sample(idx, limit)

        for i in idx:
            inp = jload(tb.column("input")[i].as_py(), {})
            tg = jload(tb.column("targets")[i].as_py(), [])
            if not isinstance(inp, dict) or not isinstance(tg, list):
                continue
            gmap = {t.get("decision_id"): t for t in tg}
            case_id = tb.column("case_id")[i].as_py()
            group_id = tb.column("group_id")[i].as_py()
            lang = tb.column("language")[i].as_py()
            state = inp.get("state_json")
            if isinstance(state, (dict, list)):
                state = json.dumps(state, ensure_ascii=False)

            for dec in inp.get("decisions") or []:
                tgt = gmap.get(dec.get("id"))
                if not tgt:
                    continue
                crit = []
                for c in dec.get("criteria") or []:
                    cid = str(c.get("id"))
                    desc = jload(c.get("description_json"), cid)
                    crit.append((cid, str(desc)))
                ids = [str(x) for x in (tgt.get("ids") or [])]
                probs = list(tgt.get("probabilities") or [])
                if not ids:
                    ids = [c[0] for c in crit]
                if len(probs) != len(ids):
                    continue
                # 按 criteria 顺序重排 gold，保证和请求里的 key 顺序一致
                pmap = dict(zip(ids, probs))
                order = [c[0] for c in crit] if crit else ids
                if set(order) != set(ids):
                    order = ids
                    crit = [(x, x) for x in ids]
                vec = [float(pmap.get(k, 0.0)) for k in order]
                label = order[vec.index(max(vec))] if vec else None
                out.append({
                    "item_id": f"s1mb:{task}:{case_id}:{dec.get('id')}",
                    "src": "s1mb", "task": task, "group_id": group_id,
                    "type": dec.get("type") or "choice",
                    "state": state,
                    "question": {
                        "type": dec.get("type") or "choice",
                        "instructions": str(jload(dec.get("instructions_json"), "")),
                        "criteria": {k: v for k, v in crit},
                    },
                    "gold": {"ids": order, "probs": vec, "label": label,
                             "annotation": tgt.get("annotation_kind") or "unknown"},
                    "meta": {"language": lang, "n_options": len(order)},
                })
    return out


# ================================================================ jev-distill

def distill_items(root, limit, seed):
    p = os.path.join(root, "jev-distill-corpus-v3", "test.jsonl")
    rows = []
    with open(p, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                rows.append(json.loads(line))
    if limit and limit < len(rows):
        rows = random.Random(seed).sample(rows, limit)

    out = []
    for r in rows:
        opts = [str(x) for x in (r.get("options") or [])]
        probs = [float(x) for x in (r.get("target") or [])]
        if not opts or len(opts) != len(probs):
            continue
        keys = [f"c{i}" for i in range(len(opts))]
        vec = probs
        label = keys[vec.index(max(vec))]
        out.append({
            "item_id": f"distill:{r.get('id')}",
            "src": "jev-distill", "task": r.get("domain") or "unknown",
            "group_id": r.get("family") or "unknown",
            "type": r.get("kind") or "choice",
            "state": r.get("state") or "",
            "question": {"type": r.get("kind") or "choice",
                         "instructions": r.get("question") or "",
                         "criteria": {k: o for k, o in zip(keys, opts)}},
            "gold": {"ids": keys, "probs": vec, "label": label,
                     "annotation": "soft_" + str(r.get("source"))},
            "meta": {"language": "en", "n_options": len(opts),
                     "family": r.get("family")},
        })
    return out


# ================================================================ TruthfulQA
def truthfulqa_items(root, limit, seed):
    p = os.path.join(root, "TruthfulQA", "data", "v1", "mc_task.json")
    data = json.load(open(p, encoding="utf-8"))
    if limit and limit < len(data):
        data = random.Random(seed).sample(data, limit)
    out = []
    for i, r in enumerate(data):
        tgt = r.get("mc1_targets") or {}
        if not isinstance(tgt, dict) or not tgt:
            continue
        choices = list(tgt.keys())
        keys = [f"c{j}" for j in range(len(choices))]
        vec = [1.0 if tgt[c] == 1 else 0.0 for c in choices]
        if sum(vec) != 1.0:
            continue
        out.append({
            "item_id": f"truthfulqa:{i}",
            "src": "truthfulqa", "task": "truthfulqa_mc1", "group_id": "truthfulqa",
            "type": "choice",
            "state": r.get("question") or "",
            "question": {"type": "choice",
                         "instructions": "Answer the question truthfully.",
                         "criteria": {k: c for k, c in zip(keys, choices)}},
            "gold": {"ids": keys, "probs": vec,
                     "label": keys[vec.index(1.0)], "annotation": "hard_label"},
            "meta": {"language": "en", "n_options": len(keys)},
        })
    return out


# ================================================================ Sys1Cal

def sys1cal_items(root, limit, seed):
    """Sys1Cal：真值概率由程序精确给定（gold_distribution），不是标注信心。

    同时带 latent_instance_id + representation：同一道题有多种等价渲染，
    可以直接做成"等价表示一致性"的成对变体（同 make_variants --mode repr）。
    """
    p = os.path.join(root, "Sys1Cal-v1-main", "datasets", "generated",
                     "v0.1.0_tiny_cleanvars_parallel_primitives.jsonl")
    if not os.path.exists(p):
        print(f"! 找不到 {p}，跳过 sys1cal")
        return []
    rows = [json.loads(l) for l in open(p, encoding="utf-8") if l.strip()]
    if limit and limit < len(rows):
        rows = random.Random(seed).sample(rows, limit)

    out = []
    for r in rows:
        ch = (r.get("queries") or {}).get("choice") or {}
        opts = [str(x) for x in (ch.get("options") or r.get("outcomes") or [])]
        gold = r.get("gold_distribution") or {}
        if len(opts) < 2 or not gold:
            continue
        probs = [float(gold.get(o, 0.0)) for o in opts]
        if abs(sum(probs) - 1.0) > 1e-6:
            continue
        state = r.get("state")
        if isinstance(state, (dict, list)):
            state = json.dumps(state, ensure_ascii=False)
        out.append({
            "item_id": f"sys1cal:{r.get('instance_id')}",
            "src": "sys1cal", "task": r.get("family") or "sys1cal",
            "group_id": r.get("latent_instance_id") or "",
            "type": "choice",
            "state": state or "",
            "question": {"type": "choice",
                         "instructions": ch.get("question") or r.get("prompt") or "",
                         "criteria": {o: o for o in opts}},
            "gold": {"ids": opts, "probs": probs,
                     "label": opts[probs.index(max(probs))], "annotation": "exact"},
            "meta": {"language": "en", "n_options": len(opts),
                     "latent_id": r.get("latent_instance_id"),
                     "representation": r.get("representation"),
                     "difficulty": r.get("difficulty"),
                     "probability_band": r.get("probability_band"),
                     "exact": True},
        })
    return out


# ================================================================ main

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root",
                    default=r"C:\Users\18227\Desktop\中继数据\System-one_temp\DataBase")
    ap.add_argument("--out", default="eval_data")
    ap.add_argument("--sources", default="s1mb,jev-distill,truthfulqa,sys1cal")
    ap.add_argument("--tasks", default="", help="只取这些 s1mb 任务（逗号分隔）")
    ap.add_argument("--limit", type=int, default=0,
                    help="统一上限（s1mb 按任务、其余按来源）")
    ap.add_argument("--limit-s1mb", type=int, default=-1, help="s1mb 每任务条数")
    ap.add_argument("--limit-distill", type=int, default=-1, help="jev-distill 条数")
    ap.add_argument("--limit-tqa", type=int, default=-1, help="TruthfulQA 条数")
    ap.add_argument("--limit-sys1cal", type=int, default=-1, help="Sys1Cal 条数")
    ap.add_argument("--seed", type=int, default=20261110)
    a = ap.parse_args()

    srcs = [x.strip() for x in a.sources.split(",") if x.strip()]
    os.makedirs(a.out, exist_ok=True)
    all_items = []
    lim_s1 = a.limit_s1mb if a.limit_s1mb >= 0 else a.limit
    lim_di = a.limit_distill if a.limit_distill >= 0 else a.limit
    lim_tq = a.limit_tqa if a.limit_tqa >= 0 else a.limit
    lim_sy = a.limit_sys1cal if a.limit_sys1cal >= 0 else a.limit

    if "s1mb" in srcs:
        if pa is None:
            raise SystemExit("缺少 pyarrow，无法读 s1mb 的 .arrow（pip install pyarrow）")
        base = os.path.join(a.root, "s1mb_dataset")
        tasks = [x.strip() for x in a.tasks.split(",") if x.strip()] or \
                sorted(x for x in os.listdir(base) if os.path.isdir(os.path.join(base, x)))
        items = s1mb_items(a.root, tasks, lim_s1, a.seed)
        print(f"s1mb        : {len(tasks)} 个任务 → {len(items)} 个决策")
        all_items += items

    if "jev-distill" in srcs:
        items = distill_items(a.root, lim_di, a.seed)
        print(f"jev-distill : {len(items)} 个决策")
        all_items += items

    if "truthfulqa" in srcs:
        items = truthfulqa_items(a.root, lim_tq, a.seed)
        print(f"truthfulqa  : {len(items)} 个决策")
        all_items += items

    if "sys1cal" in srcs:
        items = sys1cal_items(a.root, lim_sy, a.seed)
        print(f"sys1cal     : {len(items)} 个决策（真值概率）")
        all_items += items

    path = os.path.join(a.out, "items.jsonl")
    with open(path, "w", encoding="utf-8") as f:
        for it in all_items:
            f.write(json.dumps(it, ensure_ascii=False) + "\n")

    by = Counter((i["src"], i["type"]) for i in all_items)
    ann = Counter(i["gold"]["annotation"] for i in all_items)
    tasks = Counter(i["task"] for i in all_items)
    manifest = {
        "count": len(all_items),
        "by_src_type": {f"{k[0]}/{k[1]}": v for k, v in by.items()},
        "by_annotation": dict(ann),
        "n_tasks": len(tasks),
        "sha256": hashlib.sha256(open(path, "rb").read()).hexdigest(),
    }
    json.dump(manifest, open(os.path.join(a.out, "manifest.json"), "w", encoding="utf-8"),
              ensure_ascii=False, indent=2)

    print(f"\n写出 {len(all_items)} 条 → {os.path.abspath(path)}")
    print("类型分布:", dict(by.most_common(8)))
    print("标注类型:", dict(ann.most_common(8)))
    print("任务数:", len(tasks))


if __name__ == "__main__":
    main()
